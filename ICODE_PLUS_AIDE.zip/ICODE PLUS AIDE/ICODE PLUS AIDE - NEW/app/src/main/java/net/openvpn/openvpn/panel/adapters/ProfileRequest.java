package net.openvpn.openvpn.panel.adapters;
import com.android.volley.*;
import android.annotation.*;

import java.io.*;
//import org.apache.http.client.*;
//import org.apache.http.client.methods.*;
//import org.apache.http.impl.client.*;
import org.apache.http.*;
//import org.apache.http.util.*;
import java.util.*;
import com.android.volley.toolbox.*;
import com.android.volley.*;
import org.json.*;
import java.lang.reflect.*;
import java.net.*;
//import org.apache.http.message.*;
//import org.apache.http.client.entity.*;
import android.content.*;
import android.util.*;
import com.android.volley.Response.*;
import android.annotation.*;
import android.support.annotation.*;
//import org.jetbrains.annotations.*;
public class ProfileRequest extends Request<String> {

	/** Lock to guard mListener as it is cleared on cancel() and read on delivery. */
	private final Object mLock = new Object();

	@Nullable
	private Listener<String> mListener;
	
	@Nullable
	private String muser,mpass;
	/**
	 * Creates a new request with the given method.
	 *
	 * @param method the request {@link Method} to use
	 * @param url URL to fetch the string at
	 * @param listener Listener to receive the String response
	 * @param errorListener Error listener, or null to ignore errors
	 */
	public ProfileRequest(
		int method,
		String url,String user,String pass,
		Listener<String> listener,
		@Nullable ErrorListener errorListener) {
		super(method, url, errorListener);
		mListener = listener;
		muser=user;
		mpass=pass;
	}

	/**
	 * Creates a new GET request.
	 *
	 * @param url URL to fetch the string at
	 * @param listener Listener to receive the String response
	 * @param errorListener Error listener, or null to ignore errors
	 */
	public ProfileRequest(
		String url, Listener<String> listener, @Nullable ErrorListener errorListener) {
		this(Method.GET,null,null, url,listener, errorListener);
	}

	@Override
	public void cancel() {
		super.cancel();
		synchronized (mLock) {
			mListener = null;
		}
	}

	@Override
	protected void deliverResponse(String response) {
		Response.Listener<String> listener;
		synchronized (mLock) {
			listener = mListener;
		}
		if (listener != null) {
			listener.onResponse(response);
		}
	}

	@Override
	@SuppressWarnings("DefaultCharset")
	protected Response<String> parseNetworkResponse(NetworkResponse response) {
		String parsed;
		try {
			parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
		} catch (UnsupportedEncodingException e) {
			// Since minSdkVersion = 8, we can't call
			// new String(response.data, Charset.defaultCharset())
			// So suppress the warning instead.
			parsed = new String(response.data);
		}
		return Response.success(parsed, HttpHeaderParser.parseCacheHeaders(response));
	}
	@Override
	protected Map<String, String> getParams() 
	{  
		Map<String, String>  params = new HashMap<String, String>();  
		params.put("request","account");
		params.put("fname", muser);  
		params.put("pwd", mpass);

		return params;  
	}

}
