package net.openvpn.openvpn.panel.utils;
import android.graphics.*;
import java.net.*;
import java.io.*;

public class ProfileUtils
{
	public static Bitmap getbmpfromURL(String surl){
		try {
			URL url = new URL(surl);
			HttpURLConnection urlcon = (HttpURLConnection) url.openConnection();
			urlcon.setDoInput(true);
			urlcon.connect();
			InputStream in = urlcon.getInputStream();
			Bitmap mIcon = BitmapFactory.decodeStream(in);
			return  mIcon;
		} catch (Exception e) {
			//Log.e("Error", e.getMessage());
			//e.printStackTrace();
			return null;
		}
	}
}
