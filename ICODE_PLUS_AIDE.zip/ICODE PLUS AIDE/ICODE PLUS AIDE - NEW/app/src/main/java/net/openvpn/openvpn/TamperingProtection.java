package net.openvpn.openvpn;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import android.widget.*;
import android.app.*;
import java.math.*;
import android.provider.*;

public class TamperingProtection {

    
    public static final String GOOGLE_PLAY_STORE_PACKAGE = "com.android.vending";
    
    public static final String AMAZON_APP_STORE_PACKAGE = "com.amazon.venezia";
    
    public static final String SAMSUNG_APP_STORE_PACKAGE = "com.sec.android.app.samsungapps";

    private final Context context;
    private List<String> stores = Arrays.asList();
    private List<String> packageNames = Arrays.asList();
    private List<String> signatures = Arrays.asList();
    private long[] dexCrcs = {};
    private boolean isEmulatorAvailable = true;
    private boolean isDebugAvailable = true;


    public TamperingProtection(Context context) {
        this.context = context;
    }

    
    @NonNull
    public static long getDexCRC(@NonNull Context context) throws IOException {
        ZipFile zf = new ZipFile(context.getPackageCodePath());
        ZipEntry ze = zf.getEntry("classes.dex");
        return ze.getCrc();
    }


    @NonNull
    public static String[] getSignatures(@NonNull Context context) throws PackageManager.NameNotFoundException, NoSuchAlgorithmException {
        PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES);

        if (packageInfo.signatures == null || packageInfo.signatures.length <= 0) {
            return new String[]{};
        }

        String[] md5Signatures = new String[packageInfo.signatures.length];

        for (int i = 0; i < packageInfo.signatures.length; i++) {
            Signature signature = packageInfo.signatures[i];
            if (signature == null) continue;

            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(signature.toByteArray());
            byte[] digits = md.digest();

            char[] hexArray = "0123456789ABCDEF".toCharArray();
            String md5String = "";
            for (byte digit : digits) {
                int pos = digit & 0xFF;
                md5String += "" + hexArray[pos >> 4] + hexArray[pos & 0x0f] + ":";
            }
            if (md5String.length() > 0) {
                md5String = md5String.substring(0, md5String.length() - 1);
            }

            md5Signatures[i] = md5String;
        }


        return md5Signatures;
    }

  
    public static boolean isEmulator() {
        int rating = 0;
        if (Build.PRODUCT.equals("sdk") ||
			Build.PRODUCT.equals("google_sdk") ||
			Build.PRODUCT.equals("sdk_x86") ||
			Build.PRODUCT.equals("vbox86p")) {
            rating++;
        }
        if (Build.MANUFACTURER.equals("unknown") ||
			Build.MANUFACTURER.equals("Genymotion")) {
            rating++;
        }
        if (Build.BRAND.equals("generic") ||
			Build.BRAND.equals("generic_x86")) {
            rating++;
        }
        if (Build.DEVICE.equals("generic") ||
			Build.DEVICE.equals("generic_x86") ||
			Build.DEVICE.equals("vbox86p")) {
            rating++;
        }
        if (Build.MODEL.equals("sdk") ||
			Build.MODEL.equals("google_sdk") ||
			Build.MODEL.equals("Android SDK built for x86")) {
            rating++;
        }
        if (Build.HARDWARE.equals("goldfish") ||
			Build.HARDWARE.equals("vbox86")) {
            rating++;
        }
        if (Build.FINGERPRINT.contains("generic/sdk/generic") ||
			Build.FINGERPRINT.contains("generic_x86/sdk_x86/generic_x86") ||
			Build.FINGERPRINT.contains("generic/google_sdk/generic") ||
			Build.FINGERPRINT.contains("generic/vbox86p/vbox86p")) {
            rating++;
        }
        return rating > 4;
    }

   
    public static boolean isDebug(Context context) {
        boolean isDebuggable = (0 != (context.getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE));
        return isDebuggable;
    }

   
    public static String getCurrentStore(Context context) {
        return context.getPackageManager().getInstallerPackageName(context.getPackageName());
    }

    public static String getPackageName(Context context) {
        return context.getApplicationContext().getPackageName();
    }

    public void setAcceptedStores(String... stores) {
        this.stores = Arrays.asList(stores);
    }
	public void setValidUserId(String[] list){
		String key = genkey(Settings.Secure.getString(context.getContentResolver(),Settings.Secure.ANDROID_ID)).replace("\n","");
		StringBuilder str = new StringBuilder();
		for (int i= 0;i<list.length;i++) {
			String items = list[i];
			str.append(items+" ");
			str.append("\n");
	    }
	    String r = str.toString();
		if(!r.contains(key+" ")){
			Toast.makeText(context,
						   "Invalid UserID! You are not allowed to use this app",
						   Toast.LENGTH_LONG).show();
		    invalid("Invalid UserID!","Invalid UserID! You are not allowed to use this app.");
			new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							Thread.sleep(5000);
						}
						catch (Exception e) { }
						System.exit(0);
					}
				}).start();
		}
	}
    private void invalid(String title,String message)
	{
		AlertDialog.Builder builder=new AlertDialog.Builder(context);
		builder.setCancelable(false);
		builder.setTitle(title);
		builder.setMessage(message);
		AlertDialog newbuilder= builder.create();
		newbuilder.show();
	}


	public String genkey(String data){
		String testString= data;
		String hashtext = "";
        try
		{
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] messageDigest = md.digest(testString.getBytes());
			BigInteger number = new BigInteger(1, messageDigest);
			hashtext = number.toString(36);
		}
		catch (NoSuchAlgorithmException e)
		{}
		return hashtext;
	}
    public void setAcceptedPackageNames(String... packageNames) {
        this.packageNames = Arrays.asList(packageNames);
    }

    /**
     * Md5 fingerprint of you app (or many fingerprints for release and debug keystore).<br><br>
     * For get MD5 fingerprint use command line:<br><code>
     * keytool -list -v -keystore &lt;YOU_PATH_TO_KEYSTORE&gt; -alias &lt;YOU_ALIAS&gt; -storepass &lt;YOU_STOREPASS&gt; -keypass &lt;YOU_KEYPASS&gt;
     * </code><br>
     * For get MD5 fingerprint for debug keystore:<br><code>
     * keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
     * </code>
     *
     * @param signatures - list of signatures ( <b>MD5</b> fingerprint of keystore ). Each looks like: <code>"CC:0C:FB:83:8C:88:A9:66:BB:0D:C9:C8:EB:A6:4F:32"</code>
     */
    public void setAcceptedSignatures(String... signatures) {
        this.signatures = Arrays.asList(signatures);
    }

    public void setAcceptStartOnEmulator(boolean isEmulatorAvailable) {
        this.isEmulatorAvailable = isEmulatorAvailable;
    }

    public void setAcceptStartInDebugMode(boolean isDebugAvailable) {
        this.isDebugAvailable = isDebugAvailable;
    }

    public void setAcceptedDexCrcs(long... crcs) {
        this.dexCrcs = crcs;
    }

    public boolean validateAll() {
        try {
            validateAllOrThrowException();
            return true;
        } catch (ValidationException exception) {
            return false;
        }
    }

 
    public void validateAllOrThrowException() throws ValidationException {
        validateDebugMode();
        validateEmulator();
        validatePackage();
        validateStore();
        validateSignature();
        validateDexCRC();

    }

    private void validateDebugMode() throws ValidationException {
        if (isDebugAvailable) return; // // validation success (no validation need)

        // check by ApplicationInfo
        if (isDebug(context))
            throw new ValidationException(ValidationException.ERROR_CODE_DEBUG_MODE, "Run in debug mode checked by ApplicationInfo. Flags=" + context.getApplicationInfo().flags);

        // check by BuildConfig
        if (BuildConfig.DEBUG)
            throw new ValidationException(ValidationException.ERROR_CODE_DEBUG_MODE, "Run in debug mode checked by BuildConfig.");
    }

    private void validateEmulator() throws ValidationException {
        if (isEmulatorAvailable) return; // validation success (no validation need)
        boolean isEmulator = isEmulator();


        if (isEmulator)
            throw new ValidationException(ValidationException.ERROR_CODE_RUN_ON_EMULATOR, "Device looks like emulator.\n" +
										  "Build.PRODUCT: " + Build.PRODUCT + "\n" +
										  "Build.MANUFACTURER: " + Build.MANUFACTURER + "\n" +
										  "Build.BRAND: " + Build.BRAND + "\n" +
										  "Build.DEVICE: " + Build.DEVICE + "\n" +
										  "Build.MODEL: " + Build.MODEL + "\n" +
										  "Build.HARDWARE: " + Build.HARDWARE + "\n" +
										  "Build.FINGERPRINT: " + Build.FINGERPRINT);
    }

    private void validatePackage() throws ValidationException {
        if (packageNames == null || packageNames.size() <= 0)
            return;// validation success (no validation need)
        String packageName = getPackageName(context);
        if (TextUtils.isEmpty(packageName))
            throw new ValidationException(ValidationException.ERROR_CODE_PACKAGE_NAME_IS_EMPTY, "Current package name is empty: packageName=\"" + packageName + "\";");
        for (String allowedPackageName : packageNames) {
            if (packageName.equalsIgnoreCase(allowedPackageName)) return;// validation success
        }
        throw new ValidationException(ValidationException.ERROR_CODE_PACKAGE_NAME_NOT_VALID, "Not valid package name:  CurrentPackageName=\"" + packageName + "\";  validPackageNames=" + packageNames.toString() + ";");
    }

    private void validateStore() throws ValidationException {
        if (stores == null || stores.size() <= 0) return;// validation success (no validation need)
        final String installer = getCurrentStore(context);
        if (TextUtils.isEmpty(installer))
            throw new ValidationException(ValidationException.ERROR_CODE_STORE_IS_EMPTY, "Current store is empty: store=\"" + installer + "\"; App installed by user (not by store).");
        for (String allowedStore : stores) {
            if (installer.equalsIgnoreCase(allowedStore)) return;// validation success
        }
        throw new ValidationException(ValidationException.ERROR_CODE_STORE_NOT_VALID, "Not valid store:  CurrentStore=\"" + installer + "\";  validStores=" + stores.toString() + ";");
    }

    private void validateDexCRC() throws ValidationException {
        if (dexCrcs == null || dexCrcs.length <= 0)
            return;// validation success (no validation need)
        try {
            long crc = getDexCRC(context);
            for (long allowedDexCrc : dexCrcs) {
                if (allowedDexCrc == crc) return;// validation success
            }
            throw new ValidationException(ValidationException.ERROR_CODE_CRC_NOT_VALID, "Crc code of .dex not valid. CurrentDexCrc=" + crc + "  acceptedDexCrcs=" + Arrays.toString(dexCrcs) + ";");
        } catch (IOException e) {
            e.printStackTrace();
            throw new ValidationException(ValidationException.ERROR_CODE_CRC_UNKNOWN_EXCEPTION, "Exception on .dex CNC validation.", e);
        }
    }

    private void validateSignature() throws ValidationException {
        if (signatures == null || signatures.size() <= 0)
            return;// validation success (no validation need)
        try {
            String[] md5Signatures = getSignatures(context);

            if (md5Signatures == null || md5Signatures.length <= 0) {
                throw new ValidationException(ValidationException.ERROR_CODE_SIGNATURE_IS_EMPTY, "No signatures found.");
            }
        
            for (String md5Signature : md5Signatures) {
                for (String allowedSignature : signatures) {
                    if (md5Signature.equalsIgnoreCase(allowedSignature))
                        return;// validation success
                }
            }
            throw new ValidationException(ValidationException.ERROR_CODE_SIGNATURE_NOT_VALID, "Not valid signature: CurrentSignatures=" + md5Signatures + ";  validSignatures=" + signatures.toString() + ";");
        } catch (PackageManager.NameNotFoundException exception) {
            throw new ValidationException(ValidationException.ERROR_CODE_SIGNATURE_UNKNOWN_EXCEPTION, "Exception on signature validation.", exception);
        } catch (NoSuchAlgorithmException exception) {
            throw new ValidationException(ValidationException.ERROR_CODE_SIGNATURE_UNKNOWN_EXCEPTION, "Exception on signature validation.", exception);
        }

    }

    /**
     * Exception with detailed description of validation fail reason.<br>
     * Look to {@link #getErrorCode} for get fail reason details ( and {@link #getMessage} for get text description).
     */
    public static final class ValidationException extends Exception {
        public static final int ERROR_CODE_UNKNOWN_EXCEPTION = 1;
        public static final int ERROR_CODE_DEBUG_MODE = 2;
        public static final int ERROR_CODE_RUN_ON_EMULATOR = 3;
        public static final int ERROR_CODE_PACKAGE_NAME_IS_EMPTY = 4;
        public static final int ERROR_CODE_PACKAGE_NAME_NOT_VALID = 5;
        public static final int ERROR_CODE_STORE_IS_EMPTY = 6;
        public static final int ERROR_CODE_STORE_NOT_VALID = 7;
        public static final int ERROR_CODE_SIGNATURE_IS_EMPTY = 8;
        public static final int ERROR_CODE_SIGNATURE_MULTIPLE = 9;
        public static final int ERROR_CODE_SIGNATURE_NOT_VALID = 10;
        public static final int ERROR_CODE_SIGNATURE_UNKNOWN_EXCEPTION = 11;
        public static final int ERROR_CODE_CRC_NOT_VALID = 12;
        public static final int ERROR_CODE_CRC_UNKNOWN_EXCEPTION = 13;
        private final int code;

        public ValidationException(int code, String message) {
            super(message);
            this.code = code;
        }

        public ValidationException(int code, String message, Throwable cause) {
            super(message, cause);
            this.code = code;
        }

      
        public int getErrorCode() {
            return code;
        }
    }
}
