package net.openvpn.openvpn.tools;

public class CustomAds
{
	public String api="";
	public String href="";
}
