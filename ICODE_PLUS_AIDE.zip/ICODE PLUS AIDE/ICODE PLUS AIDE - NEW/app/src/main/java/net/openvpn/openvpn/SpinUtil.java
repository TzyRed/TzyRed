package net.openvpn.openvpn;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import java.util.Arrays;
import java.util.*;
import android.view.*;
import android.widget.*;

import org.json.*;
import java.io.*;
import java.security.*;
import com.icodeplus.httpssl.*;
import com.icodeplus.httpssl.R;
import de.hdodenhof.circleimageview.*;
import net.openvpn.openvpn.myinterface.*;
import android.graphics.*;
public class SpinUtil {
	
	public static class FlagSpinnerAdapter extends ArrayAdapter<String> {
        public FlagSpinnerAdapter(Context context, ArrayList<String>strArr) {
            super(context, R.layout.list_items, strArr);
        }
		@Override
		public String getItem(int position)
		{
			// TODO: Implement this method
			return super.getItem(position);
		}
        @Override
        public View getDropDownView(int i, View view, ViewGroup viewGroup) {
            return getCustomView2(i, view, viewGroup);
        }
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            return getCustomView2(i, view, viewGroup);
        }
        
		public View getCustomView2(int i, View view, ViewGroup viewGroup) {
            View view2 = view;
            ViewGroup viewGroup2 = viewGroup;
            String item = (String) getItem(i);
            View inflate = LayoutInflater.from(getContext()).inflate(R.layout.list_items, viewGroup2, false);
            CircleImageView imageView = (CircleImageView) inflate.findViewById(R.id.spinner_icon);
            TextView title = (TextView) inflate.findViewById(R.id.spinner_textview);
			title.setText(item);
          
			
			
			imageView.setImageResource(R.drawable.random);
            if (item.endsWith("SG") || item.toLowerCase().contains("singapore")) {
                imageView.setImageResource(R.drawable.sg);
	        } else if (item.endsWith("JP")||item.toLowerCase().contains("japan")) {
                imageView.setImageResource(R.drawable.jp);
            } else if (item.endsWith("US")||item.toLowerCase().contains("us")) {
                imageView.setImageResource(R.drawable.us);
            } else if (item.endsWith("IN")||item.toLowerCase().contains("india")) {
                imageView.setImageResource(R.drawable.in);
            } else if (item.endsWith("UK")||item.toLowerCase().contains("uk")) {
                imageView.setImageResource(R.drawable.uk);
            } else if (item.endsWith("KR")||item.toLowerCase().contains("korea")) {
                imageView.setImageResource(R.drawable.kr);
            } else if (item.endsWith("DE")||item.toLowerCase().contains("denmark")) {
                imageView.setImageResource(R.drawable.de);
            } else if (item.endsWith("PH")||item.toLowerCase().contains("philippines")) {
                imageView.setImageResource(R.drawable.ph);
            } else if (item.endsWith("NL")||item.toLowerCase().contains("netherlands")) {
                imageView.setImageResource(R.drawable.nl);
            } else if (item.endsWith("FR")||item.toLowerCase().contains("france")) {
                imageView.setImageResource(R.drawable.fr);
            } else if (item.endsWith("GE")||item.toLowerCase().contains("germany")) {
                imageView.setImageResource(R.drawable.ge);
            } else if (item.endsWith("CR")||item.toLowerCase().contains("costa rica")) {
                imageView.setImageResource(R.drawable.cr);
            } else if (item.endsWith("CL")||item.toLowerCase().contains("chile")) {
                imageView.setImageResource(R.drawable.cl);
            } else if (item.endsWith("PL")||item.toLowerCase().contains("poland")) {
                imageView.setImageResource(R.drawable.pl);
            } else if (item.endsWith("RU")||item.toLowerCase().contains("russia")) {
                imageView.setImageResource(R.drawable.ru);
            } else if (item.endsWith("TR")||item.toLowerCase().contains("turkey")) {
                imageView.setImageResource(R.drawable.tr);
            } else if (item.endsWith("IT")||item.toLowerCase().contains("italy")) {
                imageView.setImageResource(R.drawable.it);
            } else if (item.endsWith("ID")||item.toLowerCase().contains("indonesia")) {
                imageView.setImageResource(R.drawable.id);
            } else if (item.endsWith("SG")||item.toLowerCase().contains("singapore")) {
                imageView.setImageResource(R.drawable.sg);
            } else if (item.endsWith("MY")||item.toLowerCase().contains("myanmar")) {
                imageView.setImageResource(R.drawable.my);
            } else if (item.endsWith("TH")||item.toLowerCase().contains("thailand")) {
                imageView.setImageResource(R.drawable.th);
            } else if (item.endsWith("HK")||item.toLowerCase().contains("hong kong")) {
                imageView.setImageResource(R.drawable.hk);
            } else if (item.endsWith("TW")||item.toLowerCase().contains("thailand")) {
                imageView.setImageResource(R.drawable.tw);
            } else if (item.endsWith("IL")||item.toLowerCase().contains("israel")) {
                imageView.setImageResource(R.drawable.il);
            } else if (item.endsWith("KE")||item.toLowerCase().contains("kenya")) {
                imageView.setImageResource(R.drawable.ke);
            } else if (item.endsWith("BR")||item.toLowerCase().contains("brazil")) {
                imageView.setImageResource(R.drawable.br);
            } else if (item.endsWith("CA")||item.toLowerCase().contains("canada")) {
                imageView.setImageResource(R.drawable.ca);
            }
            return inflate;
        }
    }
	
	
	
	public static class MethodSpinnerAdapter extends ArrayAdapter<PayloadItem>
	{

		private Context context2;
        public MethodSpinnerAdapter(Context context, ArrayList<PayloadItem> strArr) {
            super(context, R.layout.list_item2, strArr);
			this.context2 = context;
        }
        @Override
        public View getDropDownView(int i, View view, ViewGroup viewGroup) {
			View view2 = view;
            ViewGroup viewGroup2 = viewGroup;
            String item = getItem(i).getName();
            View inflate = LayoutInflater.from(getContext()).inflate(R.layout.payload_item_drop, viewGroup2, false);
			// ImageView imageView = (ImageView) inflate.findViewById(R.id.spinner_icon2);
            String name =  item.replace(" (recommended)", "").replace(" (unstable)", "").replace(" (stable)", "").replace(" (beta)", "");
			TextView m2 = (TextView) inflate.findViewById(R.id.spinner_textview2);
			m2.setText(name);
			TextView m = (TextView) inflate.findViewById(R.id.spinner_textview1);
			TextView m3 = (TextView) inflate.findViewById(R.id.spinner_rec);
			TextView m1 = (TextView) inflate.findViewById(R.id.spinner_textview3);
			m1.setText(getItem(i).getInfo());
			//m1.setText("•> "+getItem(i).getInfo())
			if (item.toLowerCase().contains(" (recommended)")) {
                m3.setText(" (recommended)");
                m3.setTextColor(Color.RED);
				
            } else if (item.toLowerCase().contains(" (unstable)")) {
                m3.setText(" (unstable)");
                m3.setTextColor(Color.GRAY);
            } else if (item.toLowerCase().contains(" (stable)")) {
                m3.setText(" (stable)");
                m3.setTextColor(getContext().getResources().getColor(R.color.green));
				
            } else if (item.toLowerCase().contains(" (beta)")) {
                m3.setText(" (beta)");
                m3.setTextColor(Color.BLUE);
				
                m3.setText("");
                m3.setTextColor(0);
            }
			//imageView.setImageResource(R.drawable.defaultflag);
			String item2 = getItem(i).getPayloadMethod();
			String item3 = getItem(i).getWS();
			
			if (item2.equals("http") && item3.equals("false")) {
				m.setText("INJECT");
				// imageView.setImageResource(R.drawable.inject);
			} else if (item2.equals("http") && item3.equals("true")) {
				m.setText("INJECT + SSL");
				// imageView.setImageResource(R.drawable.inject);
			} else if (item2.equals("ssl")) {
				m.setText("SSL/TLS");
				// imageView.setImageResource(R.drawable.ssl);
            } else if (item2.equals("direct")) {
				m.setText("DIRECT");
				// imageView.setImageResource(R.drawable.direct);
            } else if (item2.equals("udp")) {
				m.setText("UDP");
				// imageView.setImageResource(R.drawable.direct);
            }
			
            return inflate;
        }
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            return getCustomView2(i, view, viewGroup);
        }

		public View getCustomView2(int i, View view, ViewGroup viewGroup) {
            View view2 = view;
            ViewGroup viewGroup2 = viewGroup;
            String item = getItem(i).getName();
            View inflate = LayoutInflater.from(getContext()).inflate(R.layout.list_item2, viewGroup2, false);
			// ImageView imageView = (ImageView) inflate.findViewById(R.id.spinner_icon2);
            String name =  item.replace(" (recommended)", "").replace(" (unstable)", "").replace(" (stable)", "").replace(" (beta)", "");
			
			
			TextView m2 = (TextView) inflate.findViewById(R.id.spinner_textview2);
			m2.setText(name);
			
			
			TextView m = (TextView) inflate.findViewById(R.id.spinner_textview1);

			//imageView.setImageResource(R.drawable.defaultflag);
			String item2 = getItem(i).getPayloadMethod();
			String item3 = getItem(i).getWS();

			if (item2.equals("http") && item3.equals("false")) {
				m.setText("INJECT");
				// imageView.setImageResource(R.drawable.inject);
			} else if (item2.equals("http") && item3.equals("true")) {
				m.setText("INJECT + SSL");
				// imageView.setImageResource(R.drawable.inject);
			} else if (item2.equals("ssl")) {
				m.setText("SSL/TLS");
				// imageView.setImageResource(R.drawable.ssl);
            } else if (item2.equals("direct")) {
				m.setText("DIRECT");
				// imageView.setImageResource(R.drawable.direct);
            } else if (item2.equals("udp")) {
				m.setText("UDP");
				// imageView.setImageResource(R.drawable.direct);
            }
			
            return inflate;
        }
    }


	/*public static String getMethod(String a,Context c){
		try
		{
			JSONObject obj = new JSONObject(loadJSONFromAsset("raw.json",c));
			JSONArray js = obj.getJSONArray("Payloads");
			for(int i = 0; i<js.length();i++){
				JSONObject get = js.getJSONObject(i);
				String name = get.getString("friendly_name");
				if(name.equals(a)){
					return get.getString("method");
				}
			}
		}
		catch (JSONException e)
		{}
		return "";
	}
	
	

	public static String loadJSONFromAsset(String n,Context c) {
		String json = "";
		try
		{
			json = FileUtil.readAsset(c, n);
			return d(json);
		}
		catch (IOException e)
		{}


		return json;
	}*/
	
	public static class CategorySpinnerAdapter extends ArrayAdapter<String>
	{

		private Context context2;
        public CategorySpinnerAdapter(Context context, String[] strArr) {
            super(context, R.layout.list_itemsa, strArr);
			this.context2 = context;
        }
        @Override
        public View getDropDownView(int i, View view, ViewGroup viewGroup) {
            return getCustomView2(i, view, viewGroup);
        }
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            return getCustomView2(i, view, viewGroup);
        }

		public View getCustomView2(int i, View view, ViewGroup viewGroup) {
            View view2 = view;
            ViewGroup viewGroup2 = viewGroup;
            String item = getItem(i);
            View inflate = LayoutInflater.from(getContext()).inflate(R.layout.list_itemsa, viewGroup2, false);
           // ImageView imageView = (ImageView) inflate.findViewById(R.id.spinner_icona);
            TextView sptitle = (TextView) inflate.findViewById(R.id.spinner_textviewa);
			sptitle.setText(item);
			
			/*imageView.setImageResource(R.drawable.defaultflag);
			if (item.contains("FREE")) {
                imageView.setImageResource(R.drawable.free);
			} else if (item.contains("PREMIUM")) {
                imageView.setImageResource(R.drawable.premium);
            } else if (item.contains("VIP")) {
                imageView.setImageResource(R.drawable.vip);
            } else if (item.contains("PRIVATE")) {
                imageView.setImageResource(R.drawable.privat);
            } */
            return inflate;
        }
    }
	
	
	
    public static String[] get_spinner_list(Spinner spin) {
        ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
        if (aa == null) {
            return null;
        }
        int len = aa.getCount();
        String[] ret = new String[len];
        for (int i = 0; i < len; i++) {
            ret[i] = (String) aa.getItem(i);
        }
        return ret;
    }
	public static ArrayList<PayloadItem> get_payload_list(Spinner spin) {
        ArrayAdapter<PayloadItem> aa = (ArrayAdapter) spin.getAdapter();
        if (aa == null) {
            return null;
        }
        int len = aa.getCount();
        ArrayList<PayloadItem> ret = new ArrayList<PayloadItem>();
        for (int i = 0; i < len; i++) {
            ret.add(aa.getItem(i));
        }
        return ret;
    }
    public static int get_spinner_count(Spinner spin) {
        ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
        if (aa == null) {
            return 0;
        }
        return aa.getCount();
    }

    public static String get_spinner_list_item(Spinner spin, int position) {
        ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
        if (aa == null) {
            return null;
        }
        return (String) aa.getItem(position);
    }
	public static String get_spinner_list_item2(Spinner spin, int position) {
        ArrayAdapter<PayloadItem> aa = (ArrayAdapter<PayloadItem>) spin.getAdapter();
        if (aa == null) {
            return null;
        }
        return (String) aa.getItem(position).getName();
    }
	
    public static String get_spinner_selected_item(Spinner spin) {
        return (String) spin.getSelectedItem();
    }
	public static PayloadItem get_spinner_selected_item2(Spinner spin) {
        return (PayloadItem) spin.getSelectedItem();
    }
    public static void set_spinner_selected_item(Spinner spin, String selected_item) {
        if (selected_item != null) {
            String sel = get_spinner_selected_item(spin);
            if (sel == null || !selected_item.equals(sel)) {
                ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
                int len = aa.getCount();
                for (int pos = 0; pos < len; pos++) {
                    if (selected_item.equals(aa.getItem(pos))) {
                        spin.setSelection(pos);
                    }
                }
            }
        }
    }
	public static void set_spinner_selected_item2(Spinner spin, String selected_item) {
        if (selected_item != null) {
            PayloadItem sel = get_spinner_selected_item2(spin);
            if (sel == null || !selected_item.equals(sel.getName())) {
                ArrayAdapter<PayloadItem> aa = (ArrayAdapter) spin.getAdapter();
                int len = aa.getCount();
                for (int pos = 0; pos < len; pos++) {
                    if (selected_item.equals(aa.getItem(pos).getName())) {
                        spin.setSelection(pos);
                    }
                }
            }
        }
    }
    public static void show_spinner(Context context, Spinner spin, String[] content) {
        if (content != null) {
            String[] live_content = get_spinner_list(spin);
            if (live_content == null || !Arrays.equals(content, live_content)) {
                ArrayAdapter<String> aa = new ArrayAdapter(context, R.layout.list, content);
                aa.setDropDownViewResource(17367049);
                spin.setAdapter(aa);
            }
        }
    }
	public static void show_spinner2(Context context, Spinner spin, ArrayList<PayloadItem> content) {
        if (content != null) {
               ArrayList<PayloadItem> live_content = get_payload_list(spin);
			  // ArrayList arrayList3 = get_payload_list(spin);
			if (live_content == null || !live_content.equals(content)) {
                MethodSpinnerAdapter aa = new MethodSpinnerAdapter(context, content);
                aa.setDropDownViewResource(17367049);
                spin.setAdapter(aa);
            }
        }
    }
	
	
	public static String[] GetStringArray(ArrayList<String> arr) 

    {
        String str[] = new String[arr.size()]; 
        for (int j = 0; j < arr.size(); j++) {
            str[j] = arr.get(j); 
        } 
        return str; 
    } 
	
	public static String d(String str3) { 
        String str4 = ""; 
        try { 
            return IcodePH.decrypt("ywuwjwjsteyshsiwuwuwh", "ywuwjwjsteyshsiwuwuwh", str3); 
        } catch (GeneralSecurityException e) { 
            return str4; 
        } 
    } 
	
	
}
