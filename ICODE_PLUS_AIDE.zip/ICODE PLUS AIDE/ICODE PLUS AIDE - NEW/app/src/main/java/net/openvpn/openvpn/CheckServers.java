package net.openvpn.openvpn;


import android.app.*;
import android.os.*;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.icodeplus.httpssl.*;
import android.widget.*;
import android.content.*;
import java.util.*;
import android.view.*;
import android.view.View.*;
import org.json.*;
import java.io.*;
import android.graphics.*;
import java.net.*;
import net.openvpn.openvpn.CheckServers.*;
import com.facebook.shimmer.ShimmerFrameLayout;
import android.support.v4.widget.*;
import com.android.volley.toolbox.*;
import android.annotation.*;
import android.app.*;
import android.os.*;
import android.widget.*;

import java.io.*;
//import org.apache.http.client.*;
//import org.apache.http.client.methods.*;
//import org.apache.http.impl.client.*;
import org.apache.http.*;
//import org.apache.http.util.*;
import java.util.*;
import com.android.volley.toolbox.*;
import org.json.*;
import java.lang.reflect.*;
import java.net.*;
//import org.apache.http.message.*;
//import org.apache.http.client.entity.*;
import android.content.*;
import android.util.*;
import com.android.volley.Response.*;
import android.annotation.*;
import android.app.AlertDialog.*;
import android.support.annotation.*;
import java.text.*;
import java.nio.*;
import android.preference.*;
import net.openvpn.openvpn.tools.*;
//import org.jetbrains.annotations.*;

public class CheckServers extends Activity 
{
	public ParallaxListView serverlv;
	public ArrayList<String> myList;

	private AlertDialog.Builder ab;  
	private ShimmerFrameLayout mShimmerViewContainer;
	private CheckServers.ServerListAdapter myAdapter;  
	private SwipeRefreshLayout pullToRefresh;

	private android.widget.TextView active;

	private android.widget.LinearLayout back;

	private android.content.SharedPreferences prefs;

	private static int themeIds = 0;
	
	private boolean isDark(){
		return themeIds == R.style.AppTheme_NoActionBar_Dark;
	}
	
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		
		prefs = PreferenceManager.getDefaultSharedPreferences(this);

	
			setTheme(R.style.AppTheme_NoActionBar);
			setContentView(R.layout.serverlist);
			themeIds= R.style.AppTheme_NoActionBar;
		
		
		
		
        
		back = (LinearLayout)findViewById(R.id.check_back);
		back.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					finish();
				}
			});
		
		ab = new AlertDialog.Builder(CheckServers.this);
		active =(TextView) findViewById(R.id.active_users);
		serverlv = findViewById(R.id.serverlistview);
		mShimmerViewContainer = (ShimmerFrameLayout) findViewById(R.id.shimmer_view_container);
		pullToRefresh = (SwipeRefreshLayout) findViewById(R.id.pullToRefresh);
		pullToRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
				@Override
				public void onRefresh() {
					//Here you can update your data from internet or from local SQLite data
					startCheck2();
				}
			});
		
		
		startCheck2();
    }
	
	private class ServerListAdapter extends ArrayAdapter<String>
	{
		ArrayList<String> list;
		public ServerListAdapter(Context con, ArrayList<String> info)
		{
			
			super(con, R.layout.log_item,info);
			list = info;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			View v = LayoutInflater.from(getContext()).inflate(R.layout.server_list_item, parent, false);
			TextView servername = (TextView)v.findViewById(R.id.server_name);
			TextView max = (TextView)v.findViewById(R.id.server_max);
			LinearLayout bglay = v.findViewById(R.id.servlistmain);
			if(isDark()){
				bglay.setBackgroundColor(getResources().getColor(R.color.laybg_dark));
			}else{
				bglay.setBackgroundColor(getResources().getColor(R.color.laybg));
			}
			
			
			
			ProgressBar progress = (ProgressBar) v.findViewById(R.id.pbar);
			String a = list.get(position);
			String[] aa = a.split("&&&");
			servername.setText(aa[0]);
			servername.setTextColor(getResources().getColor(R.color.tint));
			if(isDark()){
				servername.setTextColor(Color.WHITE);
			    max.setTextColor(Color.LTGRAY);
			}
			
			if(aa[1].equals("0")){
				servername.setText(aa[0] + " "+"(OFFLINE)");
				servername.setTextColor(Color.RED);
				servername.setPaintFlags(servername.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
				
			}
			float users = (float) Integer.parseInt(aa[2]);
			progress.setMax(300);
		
			if(users >= 300){
			   progress.setProgress(300);
			   progress.setProgressDrawable(getResources().getDrawable(R.drawable.prog3));
				max.setText("Users : FULL"+ " | "+"Max : 300" + " | "+"Loads : 100%");
				
			  // pb.getProgressDrawable().setColorFilter(Color.RED,android.graphics.PorterDuff.Mode.MULTIPLY);
			
			}else{
				DecimalFormat twoDForm = new DecimalFormat("#.##");
				String i = twoDForm.format((users/300) * 100);
				max.setText("Users : "+(int)users+ " | "+"Max : 300"+ " | " + "Loads : "+i+"%");
				
				if(users > 150){
					progress.setProgress((int)users);
					progress.setProgressDrawable(getResources().getDrawable(R.drawable.prog2));
					
					//pb.getProgressDrawable().setColorFilter(Color.YELLOW,android.graphics.PorterDuff.Mode.MULTIPLY);
				}else{
					progress.setProgress((int)users);
					progress.setProgressDrawable(getResources().getDrawable(R.drawable.prog));
					
					//pb.getProgressDrawable().setColorFilter(Color.GREEN,android.graphics.PorterDuff.Mode.MULTIPLY);
				}
			   
			}
			return v;
		}
	}
	public ArrayList<String> loadServersJs(String jsb){
		ArrayList<String> fromList = new ArrayList<String>();
		
		try {
			JSONObject obj = new JSONObject(jsb);
			JSONArray js = obj.getJSONArray("Servers");
			int x = 0;
			for (int i = 0; i < js.length(); i++)
			{
				JSONObject get = js.getJSONObject(i);
				String name = get.getString("name");
				String stat = get.getString("status");
				String users = get.getString("users");
				fromList.add(name+"&&&"+stat+"&&&"+users);
				x=x+Integer.parseInt(users);
			}
		 
			active.setText("Active Users : "+String.valueOf(x));
			return fromList;
		} catch (JSONException e) {
			e.printStackTrace();
		}	

		return fromList;
	}

	@Override
	public void onBackPressed()
	{
		ab=null;
		finish();
		super.onBackPressed();
	}
	
	/*public String loadJSONFromDir(String n) {
		String json = "";
		StringBuilder text = new StringBuilder();
		try {
			String destinationPath = getApplicationContext().getFilesDir().getAbsolutePath() + "/" + n;
			File file = new File(destinationPath);

			BufferedReader br = new BufferedReader(new FileReader(file));  
			String line;   
			while ((line = br.readLine()) != null) {
				text.append(line);
				text.append('\n');
			} }
		catch (IOException e) {
			e.printStackTrace();        
            Toast.makeText(CheckServers.this, e.getMessage(),0).show();
			
		}
	    json = text.toString(); 
		return json;
	}*/
	
	
	private void startCheck2() {
		mShimmerViewContainer.startShimmerAnimation();
		mShimmerViewContainer.setVisibility(View.VISIBLE);
		serverlv.setVisibility(View.GONE);
		active.setVisibility(View.GONE);
		//String id = "https://macall.org/server/load.php";
		test222();
       /* MyTaskA task = new MyTaskA();
        task.execute(id);*/
    }

	/*private class MyTaskA extends AsyncTask<String, Void, Boolean> {
        @Override
        protected void onPreExecute() {
        }
        @Override
        protected Boolean doInBackground(String... params) {
			try {
				HttpURLConnection.setFollowRedirects(false);
				HttpURLConnection con =  (HttpURLConnection) new URL(params[0]).openConnection();
				con.setRequestMethod("GET");
				System.out.println(con.getResponseCode()); 
				return (con.getResponseCode() == HttpURLConnection.HTTP_OK);
			}
			catch (Exception e) {   
				e.printStackTrace();    
				return false;
			}
        }
        @Override
        protected void onPostExecute(Boolean result) {
            boolean bResponse = result;
			pullToRefresh.setRefreshing(false);
			if (bResponse==true)
			{
				test222();
			}
			else
			{           
				mShimmerViewContainer.stopShimmerAnimation();
				
			    AlertDialog.Builder ab = new AlertDialog.Builder(CheckServers.this);
				ab.setMessage("No Internet connection, Please connect your device to internet and try again.");
				ab.setNegativeButton("Ok", new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							finish();
						}
						
				 });
				 ab.show();
			}                  
        }           
    }*/
	/*private void startpayloadDownload2() {
		String serverlink = "https://macall.org/server/load.php";
        new DownloadFileservers().execute(serverlink);
    }
	class DownloadFileservers extends AsyncTask<String, String, String>
	{

		private CheckServers.ServerListAdapter myAdapter;

		private ProgressDialog pd;
		private String content = "";
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
		    
        }
        @Override
        protected String doInBackground(String... aurl) {
            int count;

            try {
                URL url = new URL(aurl[0]);
                URLConnection conexion = url.openConnection();
                conexion.connect();
                int lenghtOfFile = conexion.getContentLength();
                //Log.d("ANDRO_ASYNC", "Lenght of file: " + lenghtOfFile);
                InputStream input = new BufferedInputStream(url.openStream());
				content = convertStreamtoString(input);
				
            } catch (Exception e) {
			}
            return null;
        }
        protected void onProgressUpdate(String... progress) {
			//Log.d("ANDRO_ASYNC",progress[0]);
	    }
        @Override
        protected void onPostExecute(String unused) {
			
			//String base = loadJSONFromDir("api.json");
			if(!content.isEmpty() && content.contains("Servers")){
				mShimmerViewContainer.stopShimmerAnimation();
				mShimmerViewContainer.setVisibility(View.GONE);
				serverlv.setVisibility(View.VISIBLE);
				myList = loadServersJs(content);
				myAdapter = new ServerListAdapter(CheckServers.this, myList);
				serverlv.setAdapter(myAdapter);
				myAdapter.notifyDataSetChanged();
				serverlv.setOnScrollListener(new AbsListView.OnScrollListener() {     
						@Override   
						public void onScrollStateChanged(AbsListView view, int scrollState) {
						}    
						@Override   
						public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {     
							if(myList != null){
								int topRowVerticalPosition =        
									(serverlv == null || serverlv.getChildCount() == 0) 
									? 0 
									: serverlv.getChildAt(0).getTop();     
								pullToRefresh.setEnabled(firstVisibleItem == 0 && topRowVerticalPosition >= 0);   
							}
						} 
					}); 
			}else{
				Toast.makeText(CheckServers.this, "Failed to load servers form API",0).show();
			}
		}
    }*/
	public String convertStreamtoString(InputStream is){

		String line="";
		String data="";
		try{
			BufferedReader br=new BufferedReader(new InputStreamReader(is));
			while((line=br.readLine())!=null){

				data+=line;
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
        return  data;
	}

	@Override
	protected void onStop()
	{
		// TODO: Implement this method
		ab = null;
		super.onStop();
	}
	
	
	
	
	
	
	public void test222(){
		//String url2 = "http://hasan.uaevpn.us/userapps.php";
		String url2 = "https://phcyber.pro/api/server_load.php";

		final RequestQueue requestQueue = Volley.newRequestQueue(this);
		final StringRequest2 stringRequest = new StringRequest2(Request.Method.POST,url2,
			new Response.Listener<String>() {

				
				@Override  
				public void onResponse(String content) {  
					//hiding the progressbar after completion  
					//progressBar.setVisibility(View.INVISIBLE);  
					//tv.setText(response);
					
					pullToRefresh.setRefreshing(false);
					if(!content.isEmpty() && content.contains("Servers")){
						mShimmerViewContainer.stopShimmerAnimation();
						mShimmerViewContainer.setVisibility(View.GONE);
						serverlv.setVisibility(View.VISIBLE);
						active.setVisibility(View.VISIBLE);
						myList = loadServersJs(content);
						myAdapter = new ServerListAdapter(CheckServers.this, myList);
						serverlv.setAdapter(myAdapter);
						myAdapter.notifyDataSetChanged();
						serverlv.setOnScrollListener(new AbsListView.OnScrollListener() {     
								@Override   
								public void onScrollStateChanged(AbsListView view, int scrollState) {
								}    
								@Override   
								public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {     
									if(myList != null){
										int topRowVerticalPosition =        
											(serverlv == null || serverlv.getChildCount() == 0) 
											? 0 
											: serverlv.getChildAt(0).getTop();     
										pullToRefresh.setEnabled(firstVisibleItem == 0 && topRowVerticalPosition >= 0);   
									}
								} 
							}); 
					}else{
						if (! CheckServers.this.isFinishing()) {
							Toast.makeText(CheckServers.this, "Failed to load servers form API",0).show();
							
						}
						}
					requestQueue.getCache().clear();
				}  

			},  
			new Response.ErrorListener() {

				@Override  
				public void onErrorResponse(VolleyError error) {
				    requestQueue.getCache().clear();
					mShimmerViewContainer.stopShimmerAnimation();
					if(ab != null){
              
					ab.setMessage("No Internet connection, Please connect your device to internet and try again.");
					ab.setNegativeButton("Ok", new DialogInterface.OnClickListener(){
							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								finish();
							}

						});
					ab.show();
				    }
					//displaying the error in toast if occur  
					//Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();  
				}  
			});




        //creating a request queue  
       
        //adding the string request to request queue  
        requestQueue.add(stringRequest);  
		
	}





	public class StringRequest2 extends Request<String> {

		/** Lock to guard mListener as it is cleared on cancel() and read on delivery. */
		private final Object mLock = new Object();

		@Nullable
		private Listener<String> mListener;

		/**
		 * Creates a new request with the given method.
		 *
		 * @param method the request {@link Method} to use
		 * @param url URL to fetch the string at
		 * @param listener Listener to receive the String response
		 * @param errorListener Error listener, or null to ignore errors
		 */
		public StringRequest2(
            int method,
            String url,
            Listener<String> listener,
            @Nullable ErrorListener errorListener) {
			super(method, url, errorListener);
			mListener = listener;
		}

		/**
		 * Creates a new GET request.
		 *
		 * @param url URL to fetch the string at
		 * @param listener Listener to receive the String response
		 * @param errorListener Error listener, or null to ignore errors
		 */
		public StringRequest2(
            String url, Listener<String> listener, @Nullable ErrorListener errorListener) {
			this(Method.GET, url, listener, errorListener);
		}

		@Override
		public void cancel() {
			super.cancel();
			synchronized (mLock) {
				mListener = null;
			}
		}

		@Override
		protected void deliverResponse(String response) {
			Response.Listener<String> listener;
			synchronized (mLock) {
				listener = mListener;
			}
			if (listener != null) {
				listener.onResponse(response);
			}
		}

		@Override
		@SuppressWarnings("DefaultCharset")
		protected Response<String> parseNetworkResponse(NetworkResponse response) {
			String parsed;
			try {
				parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
			} catch (UnsupportedEncodingException e) {
				// Since minSdkVersion = 8, we can't call
				// new String(response.data, Charset.defaultCharset())
				// So suppress the warning instead.
				parsed = new String(response.data);
			}
			return Response.success(parsed, HttpHeaderParser.parseCacheHeaders(response));
		}
		/*@Override
		 protected Map<String, String> getParams() 
		 {  
		 Map<String, String>  params = new HashMap<String, String>();  
		 params.put("username", "azim11");  
		 params.put("password", "azim11");

		 return params;  
		 }*/

	}
	
	
}
