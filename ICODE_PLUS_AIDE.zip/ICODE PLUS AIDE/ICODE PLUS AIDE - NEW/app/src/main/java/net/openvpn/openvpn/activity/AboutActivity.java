package net.openvpn.openvpn.activity;

import android.os.*;

import android.widget.*;
import android.view.View.*;
import android.view.*;
import android.content.pm.*;
import android.app.*;
import com.icodeplus.httpssl.*;
import net.openvpn.openvpn.*;
import android.preference.*;
import android.content.*;
import android.net.Uri;
public class AboutActivity extends Activity
{


	private TextView name_v;
	private LinearLayout back;

	private TextView name_v2;

	private SharedPreferences prefs;

	//private ImageView ImageView1;

	//private ImageView ImageView2;

	//private ImageView ImageView3;

	
	@Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        
		prefs = PreferenceManager.getDefaultSharedPreferences(this);
		
		
			setTheme(R.style.AppTheme_NoActionBar);
			setContentView(R.layout.about_dev);
			//themeIds= R.style.AppTheme_NoActionBar;
		
		
		
		
		back = (LinearLayout)findViewById(R.id.about_back);
		back.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					finish();
				}
			});
		name_v = (TextView) findViewById(R.id.name_version);
		name_v2 = (TextView) findViewById(R.id.build_name);
		
		}
	
		//ImageView1 = (ImageView) findViewById(R.id.ImageView1);
		//ImageView2 = (ImageView) findViewById(R.id.ImageView2);
		//ImageView3 = (ImageView) findViewById(R.id.ImageView3);
	
	public void website(View m){
		startActivity(new Intent(Intent.ACTION_VIEW,
								 Uri.parse("https://icode-xcv.ml")));
	}
	public void whatsapp(View m){
		startActivity(new Intent(Intent.ACTION_VIEW,
								 Uri.parse("https://wa.me/message/T2C4HPWQ7Z7GF1")));
	}
	public void youtube(View m){
		startActivity(new Intent(Intent.ACTION_VIEW,
								 Uri.parse("https://m.youtube.com/channel/UCV1h3H4xKZYGVZYhaKCGXag")));
	}
	public void telegram(View m){
		startActivity(new Intent(Intent.ACTION_VIEW,
								 Uri.parse("https://t.me/joinchat/SnR1rctj_h3Vdc1J")));
	}
	public void facebook(View m){
		startActivity(new Intent(Intent.ACTION_VIEW,
								 Uri.parse("https://facebook.com/icodexcv")));
	
		

		try
		{
			String n = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
		    String v = String.valueOf(getPackageManager().getPackageInfo(getPackageName(), 0).versionCode);
			name_v.setText("Build v"+v);
			name_v2.setText(n + " - "+"Build v"+v);
		}
		catch (PackageManager.NameNotFoundException e)
		{}
	
		
    }
}
