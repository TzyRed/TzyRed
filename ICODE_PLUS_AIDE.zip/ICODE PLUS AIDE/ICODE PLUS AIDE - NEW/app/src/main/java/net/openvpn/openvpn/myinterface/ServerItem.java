package net.openvpn.openvpn.myinterface;

public class ServerItem
{
}