package net.openvpn.openvpn;

public interface WorkerAction {
    void runFirst();

    void runLast();
}
