package net.openvpn.openvpn;

import android.util.*;
import android.preference.*;
import android.content.*;

public class MyEditTextPreference extends EditTextPreference
{
	public MyEditTextPreference(Context context, AttributeSet attr)
	{
		super(context, attr);
	}

	@Override
	public void setSummary(CharSequence summary)
	{
		if (summary.toString().isEmpty()) {
			super.setSummary(getSummary());
		} else {
			// TODO: Implement this method
			super.setSummary(summary.toString());
		}
	}
	@Override
	public void setText(String text)
	{
		super.setText(text);
		setSummary(text);
	}
}
