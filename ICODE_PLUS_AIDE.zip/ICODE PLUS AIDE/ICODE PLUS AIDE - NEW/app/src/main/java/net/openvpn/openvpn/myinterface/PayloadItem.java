package net.openvpn.openvpn.myinterface;


public class PayloadItem {
    String method;
    String name;
	String info;
	String ws;
	
    public void setName(String str) {
        this.name = str;
    }
	public void setInfo(String str) {
        this.info = str;
    }
    public void setMethod(String str) {
        this.method = str;
    }
	
	public void setWS(String str) {
        this.ws = str;
    }

    public String getName() {
        return this.name;
    }

    public String getPayloadMethod() {
        return this.method;
    }

	
	public String getInfo() {
        return this.info;
    }
	
	public String getWS() {
        return this.ws;
    }
	
    public PayloadItem() {
        PayloadItem payloadItem = this;
    }
}

