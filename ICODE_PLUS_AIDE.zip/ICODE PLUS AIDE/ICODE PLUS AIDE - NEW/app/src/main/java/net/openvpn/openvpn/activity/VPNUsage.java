package net.openvpn.openvpn.activity;
import net.openvpn.openvpn.*;
import android.os.*;

public class VPNUsage extends OpenVPNClient
{
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
	}
	
}
