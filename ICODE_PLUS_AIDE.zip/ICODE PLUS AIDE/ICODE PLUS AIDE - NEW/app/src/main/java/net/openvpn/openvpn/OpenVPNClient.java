package net.openvpn.openvpn;
 
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityCompat.OnRequestPermissionsResultCallback;
import android.support.v4.content.ContextCompat;
import android.text.method.PasswordTransformationMethod;
import android.text.method.SingleLineTransformationMethod;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.os.Process;
import android.widget.TextView.OnEditorActionListener;
import net.openvpn.openvpn.OpenVPNService.Challenge;
import net.openvpn.openvpn.OpenVPNService.ConnectionStats;
import net.openvpn.openvpn.OpenVPNService.EventMsg;
import net.openvpn.openvpn.OpenVPNService.Profile;
import net.openvpn.openvpn.OpenVPNService.ProfileList;
import org.json.*;
import java.util.*;
import java.io.*;
import android.content.res.*;
import android.view.*;
import android.app.*;
import android.widget.*;
import android.text.method.*;

import com.icodeplus.httpssl.*;
import android.support.v7.widget.*;

import android.text.*;
import java.security.*;
import android.os.*;
import java.net.*;
import android.util.*;
import net.openvpn.openvpn.*;
import net.openvpn.openvpn.graph.*;
import android.graphics.*;
import com.github.mikephil.charting.charts.*;
import android.animation.*;
import android.net.*;
import android.widget.RadioGroup.*;
import android.graphics.drawable.*;
//import com.google.android.gms.ads.*;
//import com.google.android.gms.ads.initialization.*;
import com.icodeplus.httpssl.R;
//import com.google.android.gms.ads.formats.*;
import com.android.volley.toolbox.*;
import com.android.volley.*;
import com.android.volley.Request;
import java.io.*;
//import org.apache.http.client.*;
//import org.apache.http.client.methods.*;
//import org.apache.http.impl.client.*;
import org.apache.http.*;
//import org.apache.http.util.*;
import java.util.*;
import com.android.volley.toolbox.*;
import com.android.volley.*;
import org.json.*;
import java.lang.reflect.*;
import java.net.*;
//import org.apache.http.message.*;
//import org.apache.http.client.entity.*;
import android.content.*;
import android.util.*;
import com.android.volley.Response.*;
import android.annotation.*;
import org.jsoup.*;
import android.content.pm.PackageManager.*;
import android.content.pm.*;
import android.support.v4.widget.*;
import net.openvpn.openvpn.panel.*;
import net.openvpn.openvpn.panel.utils.*;
import android.widget.AdapterView.*;
import com.facebook.shimmer.*;
import net.openvpn.openvpn.panel.adapters.*;
import net.openvpn.openvpn.activity.*;
import android.support.annotation.*;
import android.view.animation.*;

import java.text.*;
import net.openvpn.openvpn.OpenVPNService.LogMsg;
import net.openvpn.openvpn.OpenVPNClient.*;
import com.qingmei2.library.*;

import android.opengl.*;
import com.pbuild.mushroom.injector.prince.ssl.*;
import me.wangyuwei.flipshare.FlipShareView;
import me.wangyuwei.flipshare.ShareItem;
import java.util.concurrent.Semaphore;
import android.content.SharedPreferences.Editor;
import android.provider.Settings;






public class OpenVPNClient extends OpenVPNClientBase implements OnRequestPermissionsResultCallback, OnClickListener, OnTouchListener, OnItemSelectedListener, OnEditorActionListener,ExpireDate.ExpireDateListener
{

	private String clink = "https://pastegen.com/raw/yEKXLHxPqs";




    private static final int REQUEST_IMPORT_PKCS12 = 3;
    private static final int REQUEST_IMPORT_PROFILE = 2;
    private static final int REQUEST_VPN_ACTOR_RIGHTS = 1;
    private static final boolean RETAIN_AUTH = false;
    private static final int S_BIND_CALLED = 1;
    private static final int S_ONSTART_CALLED = 2;
    private static final String TAG = "OpenVPNClient";
    private static final int UIF_PROFILE_SETTING_FROM_SPINNER = 262144;
    private static final int UIF_REFLECTED = 131072;
    private static final int UIF_RESET = 65536;
    private static final boolean UI_OVERLOADED = false;
    private String autostart_profile_name;
    private View button_group;
    private TextView bytes_in_view;
    private TextView bytes_out_view;
    private TextView challenge_view;
    private View conn_details_group;
    private Button connect_button;
    private View cr_group;
    private FinishOnConnect delayed_finish_on_connect = FinishOnConnect.DISABLED;
    private TextView details_more_less;
    private Button disconnect_button;
    private TextView duration_view;
    private FinishOnConnect finish_on_connect = FinishOnConnect.DISABLED;
    private View info_group;
    private boolean last_active = RETAIN_AUTH;
    private TextView last_pkt_recv_view;
    private ScrollView main_scroll_view;
    private EditText password_edit;
    private View password_group;
    private CheckBox password_save_checkbox;
    private EditText pk_password_edit;
    private View pk_password_group;
    private CheckBox pk_password_save_checkbox;
    private View post_import_help_blurb;
    public static PrefUtil prefs;
    private ImageButton profile_edit;
    private View profile_group;
    private Spinner profile_spin;
    private ProgressBar progress_bar;
    private ImageButton proxy_edit;
    private View proxy_group;

    private PasswordUtil pwds;
    private EditText response_edit;
    private View server_group;
    private Spinner server_spin;
    private int startup_state = 0;
    private View stats_expansion_group;
    private View stats_group;
    private Handler stats_timer_handler = new Handler();
    private Runnable stats_timer_task = new Runnable() {
        public void run() {
            OpenVPNClient.this.show_stats();
            OpenVPNClient.this.schedule_stats();
        }
    };
    private ImageView status_icon_view;
    private TextView status_view;
    private boolean stop_service_on_client_exit = RETAIN_AUTH;
    private View[] textgroups;
    private TextView[] textviews;
    private Handler ui_reset_timer_handler = new Handler();
    private Runnable ui_reset_timer_task = new Runnable() {
        public void run() {
            if (!OpenVPNClient.this.is_active()) {
                OpenVPNClient.this.ui_setup(OpenVPNClient.RETAIN_AUTH, OpenVPNClient.UIF_RESET, null);
            }
        }
    };
    private EditText username_edit;
    private View username_group;

	private SharedPreferences myPrefs;
	
	
	private boolean setServerBool = true;

	private Spinner payload_spin;

	private Spinner servers_spin;

	private Spinner category_spin;

	private RadioButton rinject;

	private RadioButton rssl;

	private RadioButton rdirect;

	private LinearLayout gotopaygen;

	private TextView payloadtitle;

	private EditText sni;

	private CheckBox googledns;

	private LinearLayout ploadlay;

	private CheckBox custom_payload;

	private FrameLayout payloadspinnerlay;

	private TextView bytesview;

	private CheckBox usebackq;

	private EditText custombq;

	private LineChart mChart;


	private int prevout=0;

	private AnimatorSet mSetRightOut;

	private AnimatorSet mSetLeftIn;

	private String du= "stop";

	private int previn=0;

	private boolean loadProfile = true;

	private static boolean isClose = false;





	public static boolean isLoaded = false;

    public static int themeId;
	private String myname;

	private ProgressDialog mProgressDialog1;

	private ImageView imageview1ss;

	private SharedPreferences.Editor editor;

	private TextView mExpireDate;
	public void createConnectShortcut(String prof_name, String toString)
	{
		// TODO: Implement this method
	}

    private enum FinishOnConnect {
        DISABLED,
        ENABLED,
        ENABLED_ACROSS_ONSTART,
        PENDING
		}

    private enum ProfileSource {
        UNDEF,
        SERVICE,
        PRIORITY,
        PREFERENCES,
        SPINNER,

        LIST0
		}


    private boolean mIsBackVisible = false;
    private View mCardFrontLayout;
    private View mCardBackLayout;
	public static String free_servers = "Free_servers";
	public static String premium_servers = "Premium_servers";
	public static String vip_servers = "Vip_servers";
	public static String private_servers = "Private_servers";
	private DataTransferGraph.GraphData graphdata;
	private GraphHelper graph;
	
	
	String a = new String(new byte[]{73,67,79,68,69,32,80,76,85,83});


	private final SimpleDateFormat dateFormat = new SimpleDateFormat("[hh:mm aa]");
	private String bb = this.dateFormat.format(new Date());
	private String sp = " ";
	private String lv = bb + "   " + "Application version:"+sp+"1.0.0"+sp+"Build v1.0";
	private String lb = bb + "   " + "Running on" + sp + Build.BRAND + sp + Build.DEVICE + sp +"( Android API "+ Build.VERSION.SDK_INT+" )" ;


	public String getBuildVersion(){
		try
		{
			String n = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
		    //String v = String.valueOf(getPackageManager().getPackageInfo(getPackageName(), 0).versionCode);
			return n;
			//name_v2.setText(n + " - "+"Build v"+v);
		}
		catch (PackageManager.NameNotFoundException e)
		{
			return "";
		}
	}
	public String getBuildCode(){
		try
		{
			//String n = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
		    String v = String.valueOf(getPackageManager().getPackageInfo(getPackageName(), 0).versionCode);
			return v;
			//name_v2.setText(n + " - "+"Build v"+v);
		}
		catch (PackageManager.NameNotFoundException e)
		{
			return "";
		}
	}
	public void speedtest(View m){
		startActivity(new Intent(Intent.ACTION_VIEW,
								 Uri.parse("https://icodeph.speedtestcustom.com/")));
	}
	public void github(View m){
		startActivity(new Intent(Intent.ACTION_VIEW,
								 Uri.parse("https://github.com/")));
	}
	public void privacy(View m){
		startActivity(new Intent(Intent.ACTION_VIEW,
								 Uri.parse("https://sites.google.com/view/jhanzvpn-privacy-policy")));
	}
	public void updt(View v){
		linkUp(true);
	}
	public void help(View v){
		about();
	}

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        String str = TAG;
        Object[] objArr = new Object[S_BIND_CALLED];
        objArr[0] = intent.toString();
        Log.d(str, String.format("CLI: onCreate intent=%s", objArr));
        this.prefs = new PrefUtil(PreferenceManager.getDefaultSharedPreferences(this));
        this.pwds = new PasswordUtil(PreferenceManager.getDefaultSharedPreferences(this));
        init_default_preferences(this.prefs);
        Thread.setDefaultUncaughtExceptionHandler(new ErrorHandler(this));
		isLoaded = true;
		extractJson3("server.json");
		
			setTheme(R.style.AppTheme_NoActionBar);
			setContentView(R.layout.form);
			themeId= R.style.AppTheme_NoActionBar;
			load_all();
		

			
		myPrefs = PreferenceManager.getDefaultSharedPreferences(this);
		editor = myPrefs.edit();
		
        TextView confVersion = findViewById(R.id.configversion);
		linkUp(true);
		confVersion.setText("Config Version : "+ getJsVersion3(loadJSONFromDir("server.json")));

    }


	public void load_all(){
		doBindService();
		load_ui_elements();

        warn_app_expiration(this.prefs);

		//showExpireDate();
		mExpireDate = (TextView)findViewById(R.id.expiryview);
		
		imageview1ss =(ImageView) findViewById(R.id.btn_right_top);
		imageview1ss.setOnClickListener(this);

		if(getTitle().equals(a))
		{

		}else
		{
			new AlertDialog.Builder(OpenVPNClient.this)

				.setCancelable(false)
				.setIcon(R.drawable.ic_launcher)
				.setTitle("Warning!")
				.setMessage("1.) You're not allowed to modify this app."+"\n"+"\n2.) Please install the original application version.")
				.setPositiveButton("OK", new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						// TODO: Implement this method
						new Semaphore(0, true).release();
						android.os.Process.killProcess(android.os.Process.myPid());
						System.exit(0);
					}
				})
				.create().show();
		}
		

		this.lv = bb + "   " + "Application version:"+sp+getBuildVersion()+sp+"Build v"+getBuildCode();
		this.lb = bb + "   " + "Running on" + sp + Build.BRAND + sp + Build.DEVICE + sp +"( Android API "+ Build.VERSION.SDK_INT+" )" ;

		
		graphdata = new DataTransferGraph.GraphData();
		//Utility.checkAndExtract(this);
		this.sni = (EditText) findViewById(R.id.sni);
		rinject = (RadioButton) findViewById(R.id.rinject);
		rssl = (RadioButton) findViewById(R.id.rssl);
		rdirect = (RadioButton) findViewById(R.id.rdirect);
		rinject.setChecked(prefs.get_boolean("isHttp",true));
		rssl.setChecked(prefs.get_boolean("isSSL",true));
		rdirect.setChecked(prefs.get_boolean("isDirect",true));
		this.payloadtitle = (TextView) findViewById(R.id.payloadtitle);

		custombq = (EditText) findViewById(R.id.customquery);
		usebackq = (CheckBox) findViewById(R.id.usebackq);
		usebackq.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					if(usebackq.isChecked()){
						prefs.set_boolean("isBackq",true);
						custombq.setEnabled(true);
					}else{
						prefs.set_boolean("isBackq",false);
						custombq.setEnabled(false);
					}

				}
			});
		usebackq.setChecked(prefs.get_boolean("isBackq",false));
		custombq.setText(prefs.get_string("custombq"));
		custombq.setEnabled(prefs.get_boolean("isBackq",false));

		if(prefs.get_boolean("isHttp",true)){
			sni.setHint("[method] [host_port] [protocol][crlf][crlf]");

			sni.setText(prefs.get_string("http"));
			payloadtitle.setText("Custom Payload:");
			usebackq.setVisibility(View.GONE);
			custombq.setVisibility(View.GONE);
		}
		if(prefs.get_boolean("isSSL",true)){
			sni.setHint("www.example.com");

			sni.setText(prefs.get_string("ssl"));
			payloadtitle.setText("SNI:");
			usebackq.setVisibility(View.GONE);
			custombq.setVisibility(View.GONE);
		}
		if(prefs.get_boolean("isDirect",true)){
			sni.setHint("http-proxy-option CUSTOM-HEADER");
			sni.setText(prefs.get_string("direct"));
			payloadtitle.setText("Custom Header:");
			usebackq.setVisibility(View.VISIBLE);
			custombq.setVisibility(View.VISIBLE);
		}
		LinearLayout gotopaygen = (LinearLayout) findViewById(R.id.httppaygen);
		gotopaygen.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					paygen();
				}		
			});
		if(prefs.get_boolean("isHttp",true)){
			gotopaygen.setVisibility(View.VISIBLE);
		}else{
			gotopaygen.setVisibility(View.GONE);
		}
		this.payloadspinnerlay = (FrameLayout) findViewById(R.id.payloadspinnerlay);

		ploadlay = (LinearLayout) findViewById(R.id.ploadlay);
		custom_payload = (CheckBox) findViewById(R.id.custom_payload_checkbox);
		custom_payload.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					if(custom_payload.isChecked()){
						ploadlay.setVisibility(View.VISIBLE);
						prefs.set_boolean("isCustomPayload",true);
						payload_spin.setEnabled(false);
					    payloadspinnerlay.setVisibility(View.GONE);
						rinject.setClickable(true);
						rssl.setClickable(true);
						rdirect.setClickable(true);
						//Toast.makeText(OpenVPNClient.this,"Inject, SSL and Direct method selection is enabled",Toast.LENGTH_LONG).show();
					}else{
						payloadspinnerlay.setVisibility(View.VISIBLE);
						ploadlay.setVisibility(View.GONE);

						prefs.set_boolean("isCustomPayload",false);
						payload_spin.setEnabled(true);
						ProxyList proxy_list = get_proxy_list();
						if (proxy_list != null) {
							if(proxy_list.get_enabled_item().method != null){
								String method = proxy_list.get_enabled_item().method;
								if(method.equals("http")){
									rinject.setClickable(true);
									rinject.callOnClick();
								}
								if(method.equals("ssl")){
									rssl.setClickable(true);
									rssl.callOnClick();
								}
								if(method.equals("direct")){
									rdirect.setClickable(true);
									rdirect.callOnClick();
								}
							}
						}
					   	rinject.setClickable(false);
						rssl.setClickable(false);
						rdirect.setClickable(false);
						if(prefs.get_boolean("isCustomProxy",false)){
							customProxyW();
						}
					}
				}
			});


		custom_payload.setChecked(prefs.get_boolean("isCustomPayload",false));



		googledns = (CheckBox) findViewById(R.id.googledns);
		googledns.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					if(googledns.isChecked()){

						prefs.set_boolean("google_dns_fallback",true);


					}else{

						prefs.set_boolean("google_dns_fallback",false);

					}
				}
			});


		googledns.setChecked(prefs.get_boolean("google_dns_fallback",false));
		final ImageView showpass = (ImageView) findViewById(R.id.showpass);
		showpass.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

					if(password_edit.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
						password_edit.setTransformationMethod(HideReturnsTransformationMethod.getInstance());		
						RotateAnimation rotate = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
						rotate.setDuration(300);
						rotate.setInterpolator(new LinearInterpolator());
						ImageView image= (ImageView) findViewById(R.id.showpass);
						image.startAnimation(rotate);
						showpass.setImageResource(R.drawable.hidebtn);
						if(!password_edit.getText().toString().isEmpty()){
							password_edit.setSelection(password_edit.getText().length());
						}
				    }
					else{
						password_edit.setTransformationMethod(PasswordTransformationMethod.getInstance());
						RotateAnimation rotate = new RotateAnimation(0, -360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
						rotate.setDuration(300);
						rotate.setInterpolator(new LinearInterpolator());
						ImageView image= (ImageView) findViewById(R.id.showpass);
						image.startAnimation(rotate);


						if(!password_edit.getText().toString().isEmpty()){
							password_edit.setSelection(password_edit.getText().length());
						}
					}
				}
			});

		//Utility.stop();

		if(prefs.get_boolean("isCustomPayload",false)){
			//payloadspinnerlay.setVisibility(View.GONE);
			ploadlay.setVisibility(View.VISIBLE);
			rinject.setClickable(true);
			rssl.setClickable(true);
			rdirect.setClickable(true);
		}else{
			//payloadspinnerlay.setVisibility(View.VISIBLE);
			ploadlay.setVisibility(View.GONE);
			rinject.setClickable(false);
			rssl.setClickable(false);
			rdirect.setClickable(false);
		}



		String shutdown = getFiletextFromDir("test.dat", "").replace("\n", "");
		if(shutdown.toString().equals("true")){
			System.exit(0);
			finish();
		}

		//testapp();


		mChart = (LineChart) findViewById(R.id.chart1);
		graph = GraphHelper.getHelper().with(this).color(Color.parseColor(getString(R.color.tint2))).chart(mChart);
	    findViews();
        loadAnimations();
        changeCameraDistance();







		username_edit.setOnFocusChangeListener(new View.OnFocusChangeListener(){

				@Override
				public void onFocusChange(View p1, boolean p2)
				{
					if(p2){
						RotateAnimation rotate = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
						rotate.setDuration(300);
						rotate.setInterpolator(new LinearInterpolator());
						ImageView image= (ImageView) findViewById(R.id.user_icon);
						image.startAnimation(rotate);
					}
				}


			});

		password_edit.setOnFocusChangeListener(new View.OnFocusChangeListener(){

				@Override
				public void onFocusChange(View p1, boolean p2)
				{
					ImageView image= (ImageView) findViewById(R.id.pass_icon);

					if(p2){
						RotateAnimation rotate = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
						rotate.setDuration(300);
						rotate.setInterpolator(new LinearInterpolator());
						image.startAnimation(rotate);
					}else{

					}
				}


			});








		ImageView pay_icon= (ImageView) findViewById(R.id.payload_icon);

		pay_icon.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					payload_spin.performClick();
					// TODO: Implement this method
				}


			});
		
		
		setServer(free_servers);
	}





	public void customProxyW(){
		AlertDialog.Builder ab = new AlertDialog.Builder(this);
		ab.setMessage("Custom Proxy is enabled, Do you want to turn off?");
		ab.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface p1, int p2)
				{

					prefs.set_boolean("isCustomProxy",false);

				}
			});
		ab.setNegativeButton("No", new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface p1, int p2)
				{

				}
			});
		ab.show();
	}


	public void dummyDialog(){

	    LinearLayout v = new LinearLayout(this);
		v.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
		v.setOrientation(LinearLayout.HORIZONTAL);
		v.setGravity(Gravity.CENTER);
		v.setPaddingRelative(30,10,30,0);
		RadioButton r1 = new RadioButton(this);
		r1.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT,1.0f));
		r1.setText("OpenVPN");
		r1.setId(1);
		RadioButton r2 = new RadioButton(this);
		r2.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT,1.0f));
		r2.setText("SSHTunnel");
		r2.setId(2);
		v.addView(r1);
		v.addView(r2);
		AlertDialog.Builder ab = new AlertDialog.Builder(this);
		ab.setTitle("Tunnel Mode");
		ab.setView(v);
		ab.setPositiveButton("Done", new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface p1, int p2)
				{

				}
			});

		ab.show();
	}


	public void startGraph(){

		StoredData.downloadList.clear();
		StoredData.uploadList.clear();
		StoredData.setZero();
		du = "start";

	}
	public void stopGraph(){

		du = "stop";
		graph.stop();


	}



	public void storedData(Long mDownload, Long mUpload)
	{

        StoredData.downloadSpeed = mDownload;
        StoredData.uploadSpeed = mUpload;

        if (StoredData.isSetData)
		{
            StoredData.downloadList.remove(0);
            StoredData.uploadList.remove(0);

            StoredData.downloadList.add(mDownload);
            StoredData.uploadList.add(mUpload);
        }


    }
    protected void onNewIntent(Intent intent) {
        String str = TAG;
        Object[] objArr = new Object[S_BIND_CALLED];
        objArr[0] = intent.toString();
        Log.d(str, String.format("CLI: onNewIntent intent=%s", objArr));
        setIntent(intent);
    }

    protected void post_bind() {
        Log.d(TAG, "CLI: post bind");
        this.startup_state |= S_BIND_CALLED;
        process_autostart_intent(is_active());
        render_last_event();
		//refresh_log_view();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    public void event(EventMsg ev) {
        render_event(ev, RETAIN_AUTH, is_active(), RETAIN_AUTH);
    }

    private void render_last_event() {
        boolean active = is_active();
        EventMsg ev = get_last_event();
        if (ev != null) {
            render_event(ev, true, active, true);
        } else if (n_profiles_loaded() > 0) {
            render_event(EventMsg.disconnected(), true, active, true);
        } else {
            hide_status();
            ui_setup(active, UIF_RESET, null);
            show_progress(0, active);
        }
        EventMsg pev = get_last_event_prof_manage();
        if (pev != null) {
            render_event(pev, true, active, true);
        }
    }

    private boolean show_conn_info_field(String text, int field_id, int row_id) {
        int i = 0;
        boolean vis = text.length() > 0 ? true : RETAIN_AUTH;
        TextView tv = (TextView) findViewById(field_id);
        View row = findViewById(row_id);
        tv.setText(text);
        if (!vis) {
            i = 8;
        }
        row.setVisibility(i);
        return vis;
    }

    private void reset_conn_info() {
        show_conn_info(new ClientAPI_ConnectionInfo());
    }
	
	
	private void showExpireDate()
	{
		//https://riyavpn.com/api/auth.php?username=USERNAME&password=PASSWORD&device_id=DEVICEID&device_model=DEVICEMODEL
		String format = "https://riyavpn.com/api/auth.php?username=%s&password=%s&device_id=%s&device_model=%s";
		String user = username_edit.getText().toString();
		String pass = password_edit.getText().toString();
		if (user.isEmpty() || pass.isEmpty()) {
			return;
		}

		String model = Build.MODEL;
		String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
		/*ExpireDate ed = new ExpireDate(this);
		 ed.setUrl(String.format(format, user, pass, id, model));
		 ed.setExpireDateListener(this);
		 try {
		 ed.start();
		 } catch (Exception e) {
		 showToast("Expire Date: " + e.getMessage());
		 //Snackbar.make("Expire Date: " + e.getMessage() Snackbar.LENGTH_LONG).show();
		 // TODO: Implement this method
		 }*/
		String jsonUrl = String.format(format, user, pass, id, model);

		StringRequest req = new StringRequest(jsonUrl,
			new Response.Listener<String>() {
				@Override
				public void onResponse(String response) {

					try {
						//showToast(response);
						JSONObject js = new JSONObject(response);
						if (js.getString("device_match").equals("none")) {
							onAuthFailed("Authentication Failed");
							flipCard3();
							//showToast("Authentication Failed");
							//jomarabbout(button);
							return;
						}
						if (js.getString("device_match").equals("false")) {
							onDeviceNotMatch("This pin is use in another device");
							flipCard3();
							//showToast("This pin is use in another device");
							//jomarabbout(button);
							return;
						}
						onExpireDate(js.getString("expiry"));
					} catch (Exception e) {
						//onError(e.getClass().getSimpleName() + ": " +e.getMessage());
					}
				}
			},   new Response.ErrorListener() {
				@Override
				public void onErrorResponse(VolleyError error) {
					onError(error.getClass().getName() + ": "+ error.getMessage());
				}

			});
		RequestQueue requestQueue = Volley.newRequestQueue(this);
		requestQueue.add(req);
		// TODO: Implement this method
	}
	@Override
	public void onExpireDate(String expiry)
	{
		if (mExpireDate == null) {
			return;
		}
		if (expiry.equals("none")) {
			mExpireDate.setText("none");
		} else {
			mExpireDate.setText(getDaysLeft(expiry));
			editor.putString("ExpireDate", getDaysLeft(expiry)).apply();
		}
		// TODO: Implement this method
	}

	@Override
	public void onDeviceNotMatch(String message)
	{
		submitDisconnectIntent(RETAIN_AUTH);
		//Snackbar.make(email, message, Snackbar.LENGTH_LONG).show();
		// TODO: Implement this method
	}
	private String getDaysLeft(String thatDate)
	{
		if (thatDate.contains(" ")) {
			thatDate = thatDate.split(" ")[0];
		}
		String[] split = thatDate.split("-");
		Calendar instance = Calendar.getInstance();
		instance.set(Integer.valueOf(split[0]).intValue(), Integer.valueOf(split[1]).intValue() - 1, Integer.valueOf(split[2]).intValue());
		return String.format("%s Days Left", new Object[]{(instance.getTimeInMillis() - Calendar.getInstance().getTimeInMillis()) / ((long) 86400000)});
	}

	@Override
	public void onAuthFailed(String message)
	{
		submitDisconnectIntent(RETAIN_AUTH);
		//Snackbar.make(email, message, Snackbar.LENGTH_LONG).show();
		// TODO: Implement this method
	}
	@Override
	public void onError(String error)
	{
		//showExpireDate(); 
		//Snackbar.make(vpn_username,  error, Snackbar.LENGTH_SHORT).show();
		// TODO: Implement this method
	}


	private void about(){
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setIcon(R.drawable.ic_icode_dev);
		builder.setTitle("Support");
		builder.setView(getLayoutInflater().inflate(R.layout.about_dev,null));
		builder.setCancelable(true);
		builder.setPositiveButton("ok", null);
		builder.show();
	}
	


	
    private void show_conn_info(ClientAPI_ConnectionInfo ci) {
        this.info_group.setVisibility((((((((RETAIN_AUTH | show_conn_info_field(ci.getVpnIp4(), R.id.ipv4_addr, R.id.ipv4_addr_row)) | show_conn_info_field(ci.getVpnIp6(), R.id.ipv6_addr, R.id.ipv6_addr_row)) | show_conn_info_field(ci.getUser(), R.id.user, R.id.user_row)) | show_conn_info_field(ci.getClientIp(), R.id.client_ip, R.id.client_ip_row)) | show_conn_info_field(ci.getServerHost(), R.id.server_host, R.id.server_host_row)) | show_conn_info_field(ci.getServerIp(), R.id.server_ip, R.id.server_ip_row)) | show_conn_info_field(ci.getServerPort(), R.id.server_port, R.id.server_port_row)) | show_conn_info_field(ci.getServerProto(), R.id.server_proto, R.id.server_proto_row) ? 0 : 8);
        set_visibility_stats_expansion_group();
    }

    private void set_visibility_stats_expansion_group() {
        int i = 0;
        boolean expand_stats = this.prefs.get_boolean("expand_stats", RETAIN_AUTH);
        View view = this.stats_expansion_group;
        if (!expand_stats) {
            i = 8;
        }
        view.setVisibility(i);
        this.details_more_less.setText(expand_stats ? R.string.touch_less : R.string.touch_more);
    }

    private void render_event(EventMsg ev, boolean reset, boolean active, boolean cached) {
        int flags = ev.flags;
        if (ev.is_reflected(this)) {
            flags |= UIF_REFLECTED;
        }
        if (reset || (flags & 8) != 0 || ev.profile_override != null) {
            ui_setup(active, UIF_RESET | flags, ev.profile_override);
        } else if (ev.res_id == R.string.core_thread_active) {
            active = true;
            ui_setup(true, flags, null);
        } else if (ev.res_id == R.string.core_thread_inactive) {
            active = RETAIN_AUTH;
            ui_setup(RETAIN_AUTH, flags, null);
        }
        switch (ev.res_id) {
            case R.string.connected /*2131034168*/:
                this.main_scroll_view.fullScroll(33);
                break;
            case R.string.info_msg /*2131034237*/:
                if (ev.info.startsWith("OPEN_URL:")) {
                    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(ev.info.substring(9)));
                    intent.putExtra("com.android.browser.application_id", getPackageName());
                    if (intent.resolveActivity(getPackageManager()) != null) {
                        startActivity(intent);
                        break;
                    }
                }
                break;
            case R.string.tap_not_supported /*2131034362*/:
                if (!cached) {
                    ok_dialog(resString(R.string.tap_unsupported_title), resString(R.string.tap_unsupported_error));
                    break;
                }
                break;
            case R.string.tun_iface_create /*2131034371*/:
                if (!cached) {
					//load_all();
					//Toast.makeText(this,"R",0).show();
					if(mProgressDialog1!=null){
						if(mProgressDialog1.isShowing()){
							mProgressDialog1.dismiss();
						}
					}
					this.recreate();
					//finish();
					//load_ui_elements();
					//ok_dialog(resString(R.string.tun_ko_title), resString(R.string.tun_ko_error));
                    break;
                }
                break;
            case R.string.warn_msg /*2131034390*/:
                this.delayed_finish_on_connect = FinishOnConnect.PENDING;
                final Activity self = this;
                ok_dialog(resString(R.string.warning_title), ev.info, new Runnable() {
						public void run() {
							if (!(OpenVPNClient.this.delayed_finish_on_connect == FinishOnConnect.PENDING || OpenVPNClient.this.delayed_finish_on_connect == FinishOnConnect.DISABLED)) {
								self.finish();
							}
							OpenVPNClient.this.delayed_finish_on_connect = FinishOnConnect.DISABLED;
						}
					});
                break;
        }
        if (ev.priority >= S_BIND_CALLED) {
            if (ev.icon_res_id >= 0) {
                show_status_icon(ev.icon_res_id);
            }
            if (ev.res_id == R.string.connected) {
				//showExpireDate();
                show_status(ev.res_id);
                if (ev.conn_info != null) {
                    show_conn_info(ev.conn_info);
                }
            } else if (ev.info.length() > 0) {
                Object[] objArr = new Object[S_ONSTART_CALLED];
                objArr[0] = resString(ev.res_id);
                objArr[S_BIND_CALLED] = ev.info;
                show_status(String.format("%s : %s", objArr));
            } else {
                show_status(ev.res_id);
            }
        }
        show_progress(ev.progress, active);
        show_stats();
        if (ev.res_id == R.string.connected && this.finish_on_connect != FinishOnConnect.DISABLED) {
            if (this.prefs.get_boolean("autostart_finish_on_connect", RETAIN_AUTH)) {
                final OpenVPNClient self = this;
                if (this.delayed_finish_on_connect == FinishOnConnect.PENDING)
				{
                    this.delayed_finish_on_connect = this.finish_on_connect;
                    return;
                }
                new Handler().postDelayed(new Runnable() {
						public void run() {
							if (OpenVPNClient.this.finish_on_connect != FinishOnConnect.DISABLED) {
								self.finish();
							}
						}
					}, 1000);
                return;
            }
            this.finish_on_connect = FinishOnConnect.DISABLED;
        }
    }

	private void ok_dialog(String resString, String info, Object run)
	{
		// TODO: Implement this method
	}

    private void stop_service() {
        submitDisconnectIntent(true);
    }

    private void stop() {
        //cancel_stats();
        doUnbindService();
        if (this.stop_service_on_client_exit) {
            Log.d(TAG, "CLI: stopping service");
            stop_service();
        }
    }

    protected void onStop() {
        Log.d(TAG, "CLI: onStop");
		// cancel_stats();
        super.onStop();
    }

    protected void onStart() {
        super.onStart();
        Log.d(TAG, "CLI: onStart");
        this.startup_state |= S_ONSTART_CALLED;
        if (this.finish_on_connect == FinishOnConnect.ENABLED) {
            this.finish_on_connect = FinishOnConnect.ENABLED_ACROSS_ONSTART;
        }
        boolean active = is_active();
        if (active) {
            schedule_stats();
        }
        if (process_autostart_intent(active)) {
            ui_setup(active, UIF_RESET, null);
        }
    }

    protected void onDestroy() {
        stop();
		isClose = true;
		/*if (nativeAd != null) {
		 nativeAd.destroy();
		 }*/
        Log.d(TAG, "CLI: onDestroy called");
        super.onDestroy();
    }

    private boolean process_autostart_intent(boolean active) {
        if ((this.startup_state & REQUEST_IMPORT_PKCS12) == REQUEST_IMPORT_PKCS12) {
            Intent intent = getIntent();
            String apn_key = "net.openvpn.openvpn.AUTOSTART_PROFILE_NAME";
            String apn = intent.getStringExtra(apn_key);
            if (apn != null) {
                this.autostart_profile_name = null;
                String str = TAG;
                Object[] objArr = new Object[S_BIND_CALLED];
                objArr[0] = apn;
                Log.d(str, String.format("CLI: autostart: %s", objArr));
                intent.removeExtra(apn_key);
                if (!active) {
                    ProfileList proflist = profile_list();
                    if (proflist == null || proflist.get_profile_by_name(apn) == null) {
                        ok_dialog(resString(R.string.profile_not_found), apn);
                    } else {
                        this.autostart_profile_name = apn;
                        return true;
                    }
                } else if (!current_profile().get_name().equals(apn)) {
                    this.autostart_profile_name = apn;
                    submitDisconnectIntent(RETAIN_AUTH);
                }
            }
        }
        return RETAIN_AUTH;
    }

    private void cancel_ui_reset() {
        this.ui_reset_timer_handler.removeCallbacks(this.ui_reset_timer_task);
    }

    private void schedule_ui_reset(long delay) {
        cancel_ui_reset();
        this.ui_reset_timer_handler.postDelayed(this.ui_reset_timer_task, delay);
    }

    private void hide_status() {
        this.status_view.setVisibility(8);
    }

    private void show_status(String text) {
        this.status_view.setVisibility(0);
        this.status_view.setText(text);
    }

    private void show_status(int res_id) {
        this.status_view.setVisibility(0);
        this.status_view.setText(getResources().getString(res_id));
    }

    private void show_status_icon(int res_id) {
        this.status_icon_view.setImageResource(res_id);
    }

    private void show_progress(int progress, boolean active) {
        if (progress <= 0 || progress >= 99) {
            this.progress_bar.setVisibility(8);
            return;
        }
        this.progress_bar.setVisibility(0);
        this.progress_bar.setProgress(progress);
    }

    private void cancel_stats() {
        this.stats_timer_handler.removeCallbacks(this.stats_timer_task);
    }

    private void schedule_stats() {
        cancel_stats();
        this.stats_timer_handler.postDelayed(this.stats_timer_task, 1000);
    }

    private static String render_bandwidth(long bw) {
        String postfix;
        float div;
        Object[] objArr;
        float bwf = (float) bw;
        if (bwf >= 1.0E12f) {
            postfix = "TB";
            div = 1.0995116E12f;
        } else if (bwf >= 1.0E9f) {
            postfix = "GB";
            div = 1.0737418E9f;
        } else if (bwf >= 1000000.0f) {
            postfix = "MB";
            div = 1048576.0f;
        } else if (bwf >= 1000.0f) {
            postfix = "KB";
            div = 1024.0f;
        } else {
            objArr = new Object[S_BIND_CALLED];
            objArr[0] = Float.valueOf(bwf);
            return String.format("%.0f", objArr);
        }
        objArr = new Object[S_ONSTART_CALLED];
        objArr[0] = Float.valueOf(bwf / div);
        objArr[S_BIND_CALLED] = postfix;
        return String.format("%.2f %s", objArr);
    }

    private String render_last_pkt_recv(int sec) {
        if (sec >= 3600) {
            return resString(R.string.lpr_gt_1_hour_ago);
        }
        String resString;
        Object[] objArr;
        if (sec >= 120) {
            resString = resString(R.string.lpr_gt_n_min_ago);
            objArr = new Object[S_BIND_CALLED];
            objArr[0] = Integer.valueOf(sec / 60);
            return String.format(resString, objArr);
        } else if (sec >= S_ONSTART_CALLED) {
            resString = resString(R.string.lpr_n_sec_ago);
            objArr = new Object[S_BIND_CALLED];
            objArr[0] = Integer.valueOf(sec);
            return String.format(resString, objArr);
        } else if (sec == S_BIND_CALLED) {
            return resString(R.string.lpr_1_sec_ago);
        } else {
            if (sec == 0) {
                return resString(R.string.lpr_lt_1_sec_ago);
            }
            return BuildConfig.FLAVOR;
        }
    }

    private void show_stats() {
        if (is_active()) {
            ConnectionStats stats = get_connection_stats();
			//getData();
			ClientAPI_TransportStats ct = new ClientAPI_TransportStats();

			if(prefs.get_boolean("isGraph",true)){
				//graphdata.setDown((int)stats.bytes_in,(int)stats.bytes_in-previn);
				//graphdata.setUp((int)stats.bytes_out,(int)stats.bytes_out-prevout);
				storedData(stats.bytes_in-previn,stats.bytes_out-prevout);
				if(previn != (int)stats.bytes_in){
					previn = (int)stats.bytes_in;
				}
				if(prevout != (int)stats.bytes_out){
					prevout = (int)stats.bytes_out;
				}
				graph.start();
				graph.refreshGraph();
			}
            this.last_pkt_recv_view.setText(render_last_pkt_recv(stats.last_packet_received));
            this.duration_view.setText(OpenVPNClientBase.render_duration(stats.duration));
            this.bytes_in_view.setText(render_bandwidth(stats.bytes_in));
            this.bytes_out_view.setText(render_bandwidth(stats.bytes_out));

			String stat = "⬇"+render_bandwidth(stats.bytes_in) + "  -  " +"⬆"+render_bandwidth(stats.bytes_out);

			/*if(!bytesview.isShown()){
			 bytesview.setVisibility(View.VISIBLE);
			 }
			 bytesview.setText(stat);
			 */

			//StatService.updatenotif(stat);
			//startService(new Intent(this, StatService.class).putExtra("notif_content",stat));
        }else{
			if(bytesview.isShown()){
				bytesview.setVisibility(View.GONE);	
			}
			//stopService(new Intent(this, StatService.class).putExtra("notif_content",""));

		}
    }


    private void clear_stats() {
        this.last_pkt_recv_view.setText(BuildConfig.FLAVOR);
        this.duration_view.setText(BuildConfig.FLAVOR);
        this.bytes_in_view.setText(BuildConfig.FLAVOR);
        this.bytes_out_view.setText(BuildConfig.FLAVOR);
        reset_conn_info();
    }

    private int n_profiles_loaded() {
        ProfileList proflist = profile_list();
        if (proflist != null) {
            return proflist.size();
        }
        return 0;
    }

    private String selected_profile_name() {
        String ret = null;
        ProfileList proflist = profile_list();
        if (proflist != null && proflist.size() > 0) {
            ret = proflist.size() == S_BIND_CALLED ? ((Profile) proflist.get(0)).get_name() : SpinUtil.get_spinner_selected_item(this.profile_spin);
        }
        if (ret == null) {
            return "UNDEFINED_PROFILE";
        }
        return ret;
    }

    private Profile selected_profile() {
        ProfileList proflist = profile_list();
        if (proflist != null) {
            return proflist.get_profile_by_name(selected_profile_name());
        }
        return null;
    }

    private void clear_auth() {
		/*  this.username_edit.setText(BuildConfig.FLAVOR);
		 this.pk_password_edit.setText(BuildConfig.FLAVOR);
		 this.password_edit.setText(BuildConfig.FLAVOR);
		 this.response_edit.setText(BuildConfig.FLAVOR);
		 */
    }

    private void ui_setup(boolean active, int flags, String profile_override) {
        boolean orig_active = active;
        boolean autostart = RETAIN_AUTH;
        cancel_ui_reset();
        if (!((UIF_RESET & flags) == 0 && orig_active == this.last_active)) {
            clear_auth();
            if (!(active || this.autostart_profile_name == null)) {
                autostart = true;
                profile_override = this.autostart_profile_name;
                this.autostart_profile_name = null;
            }
            ProfileList proflist = profile_list();
            Profile prof = null;
            if (proflist == null || proflist.size() <= 0) {
                this.profile_group.setVisibility(8);
            } else {
                ProfileSource ps = ProfileSource.UNDEF;
                SpinUtil.show_spinner(this, this.profile_spin, proflist.profile_names());
                if (active) {
                    ps = ProfileSource.SERVICE;
                    prof = current_profile();
                }
                if (prof == null && profile_override != null) {
                    ps = ProfileSource.PRIORITY;
                    prof = proflist.get_profile_by_name(profile_override);
                    if (prof == null) {
                        Log.d(TAG, "CLI: profile override not found");
                        autostart = RETAIN_AUTH;
                    }
                }
                if (prof == null) {
                    if ((UIF_PROFILE_SETTING_FROM_SPINNER & flags) != 0) {
                        ps = ProfileSource.SPINNER;
                        prof = proflist.get_profile_by_name(SpinUtil.get_spinner_selected_item(this.profile_spin));
                    } else {
                        ps = ProfileSource.PREFERENCES;
                        prof = proflist.get_profile_by_name(this.prefs.get_string("profile"));
                    }
                }
                if (prof == null) {
                    ps = ProfileSource.LIST0;
                    prof = (Profile) proflist.get(0);
                }
                if (ps != ProfileSource.PREFERENCES && (UIF_REFLECTED & flags) == 0) {
                    this.prefs.set_string("profile", prof.get_name());
                    gen_ui_reset_event(true);
                }
                if (ps != ProfileSource.SPINNER) {
                    SpinUtil.set_spinner_selected_item(this.profile_spin, prof.get_name());
                }



                if(prefs.get_boolean("isCustomPayload",false)){
					rinject = (RadioButton) findViewById(R.id.rinject);
					rssl = (RadioButton) findViewById(R.id.rssl);
					rdirect = (RadioButton) findViewById(R.id.rdirect);
					rdirect.setClickable(!active ? true : RETAIN_AUTH);
					rinject.setClickable(!active ? true : RETAIN_AUTH);
					rssl.setClickable(!active ? true : RETAIN_AUTH);
					this.payload_spin.setEnabled(false);
				}else{
					rdirect.setClickable(false);
					rinject.setClickable(false);
					rssl.setClickable(false);
					this.payload_spin.setEnabled(!active ? true : RETAIN_AUTH);
				}
				OpenVPNPrefs.isEnabled = !is_active();
				LinearLayout gotopaygen = (LinearLayout) findViewById(R.id.httppaygen);
				gotopaygen.setClickable(!active ? true : RETAIN_AUTH);
				this.custom_payload.setClickable(!active ? true : RETAIN_AUTH);
				this.googledns.setClickable(!active ? true : RETAIN_AUTH);
				this.category_spin.setEnabled(!active ? true : RETAIN_AUTH);
				this.servers_spin.setEnabled(!active ? true : RETAIN_AUTH);
				this.usebackq.setClickable(!active ? true : RETAIN_AUTH);
				if(usebackq.isChecked()){
					this.custombq.setEnabled(!active ? true : RETAIN_AUTH);
				}
				prefs.set_boolean("splash",!active ? true : RETAIN_AUTH);

				this.username_edit.setEnabled(!active ? true : RETAIN_AUTH);
				this.password_edit.setEnabled(!active ? true : RETAIN_AUTH);
				//this.method.setEnabled(!active ? true : RETAIN_AUTH);
				this.sni.setEnabled(!active ? true : RETAIN_AUTH);
                this.profile_spin.setEnabled(!active ? true : RETAIN_AUTH);
				this.profile_edit.setVisibility(active ? 8 : 0);
				ImageView net_icon= (ImageView) findViewById(R.id.net_icon);
				ImageView pay_icon= (ImageView) findViewById(R.id.payload_icon);
				net_icon.setClickable(!active ? true : RETAIN_AUTH);
				pay_icon.setClickable(!active ? true : RETAIN_AUTH);



            }
            if (prof != null) {
                if ((UIF_RESET & flags) != 0) {
                    prof.reset_dynamic_challenge();
                }
                EditText focus = null;
                if (!active && (flags & 32) != 0) {
                    this.post_import_help_blurb.setVisibility(0);
                } else if (active) {
                    this.post_import_help_blurb.setVisibility(8);
                }
                ProxyList proxy_list = get_proxy_list();
                if (active || proxy_list.size() <= 0) {
                    this.proxy_group.setVisibility(8);
                } else {
                    SpinUtil.show_spinner2(this, this.payload_spin, proxy_list.get_name_list2(false));
                    String name = proxy_list.get_enabled(false);
                    if (name != null) {
                        SpinUtil.set_spinner_selected_item2(this.payload_spin, name);
                    }
					if (prefs.contains_key("selected_payload")) {
						SpinUtil.set_spinner_selected_item2(this.payload_spin, prefs.get_string("selected_payload"));
                    }

                    this.proxy_group.setVisibility(0);
                }
                if (active || !prof.server_list_defined()) {
                    this.server_group.setVisibility(8);
                } else {
                    SpinUtil.show_spinner(this, this.server_spin, prof.get_server_list().display_names());
                    String server = this.prefs.get_string_by_profile(prof.get_name(), "server");
                    if (server != null) {
                        SpinUtil.set_spinner_selected_item(this.server_spin, server);
                    }
                    this.server_group.setVisibility(0);
                }
                if (active) {
                    this.username_group.setVisibility(8);
                    this.pk_password_group.setVisibility(8);
                    this.password_group.setVisibility(8);
                } else {
                    boolean is_pwd_save;
                    String saved_pwd;
                    boolean udef = prof.userlocked_username_defined();
                    boolean autologin = prof.get_autologin();
                    boolean pk_pwd_req = prof.get_private_key_password_required();
                    boolean dynamic_challenge = prof.is_dynamic_challenge();
                    if ((!autologin || (autologin && udef)) && !dynamic_challenge) {
                        if (udef) {
                            this.username_edit.setText(prof.get_userlocked_username());
                            set_enabled(this.username_edit, RETAIN_AUTH);
                        } else {
                            set_enabled(this.username_edit, true);
                            String pref_username = this.prefs.get_string_by_profile(prof.get_name(), "username");
                            if (pref_username != null) {
                                this.username_edit.setText(pref_username);
                            } else if (null == null) {
                                focus = this.username_edit;
                            }
                        }
                        this.username_group.setVisibility(0);
                    } else {
                        this.username_group.setVisibility(8);
                    }
                    if (pk_pwd_req) {
                        is_pwd_save = this.prefs.get_boolean_by_profile(prof.get_name(), "pk_password_save", RETAIN_AUTH);
                        saved_pwd = null;
                        this.pk_password_group.setVisibility(0);
                        this.pk_password_save_checkbox.setChecked(is_pwd_save);
                        if (is_pwd_save) {
                            saved_pwd = this.pwds.get("pk", prof.get_name());
                        }
                        if (saved_pwd != null) {
                            this.pk_password_edit.setText(saved_pwd);
                        } else if (focus == null) {
                            focus = this.pk_password_edit;
                        }
                    } else {
                        this.pk_password_group.setVisibility(8);
                    }
                    if (autologin || dynamic_challenge) {
                        this.password_group.setVisibility(8);
                    } else {
                        boolean is_auth_pw_save = prof.get_allow_password_save();
                        is_pwd_save = (is_auth_pw_save && this.prefs.get_boolean_by_profile(prof.get_name(), "auth_password_save", RETAIN_AUTH)) ? true : RETAIN_AUTH;
                        saved_pwd = null;
                        this.password_group.setVisibility(0);
                        this.password_save_checkbox.setEnabled(is_auth_pw_save);
                        this.password_save_checkbox.setChecked(is_pwd_save);
                        if (is_pwd_save) {
                            saved_pwd = this.pwds.get("auth", prof.get_name());
                        }
                        if (saved_pwd != null) {
                            this.password_edit.setText(saved_pwd);
                        } else if (focus == null) {
                            focus = this.password_edit;
                        }
                    }
                }
                if (active || prof.get_autologin() || !prof.challenge_defined()) {
                    this.cr_group.setVisibility(8);
                } else {
                    this.cr_group.setVisibility(0);
                    Challenge chal = prof.get_challenge();
                    this.challenge_view.setText(chal.get_challenge());
                    this.challenge_view.setVisibility(0);
                    if (chal.get_response_required()) {
                        if (chal.get_echo()) {
                            this.response_edit.setTransformationMethod(SingleLineTransformationMethod.getInstance());
                        } else {
                            this.response_edit.setTransformationMethod(PasswordTransformationMethod.getInstance());
                        }
                        this.response_edit.setVisibility(0);
                        if (focus == null) {
                            focus = this.response_edit;
                        }
                    } else {
                        this.response_edit.setVisibility(8);
                    }
                    if (prof.is_dynamic_challenge()) {
                        schedule_ui_reset(prof.get_dynamic_challenge_expire_delay());
                    }
                }
                this.button_group.setVisibility(0);
                if (orig_active) {
                    this.conn_details_group.setVisibility(0);
                    this.connect_button.setVisibility(8);
                    this.disconnect_button.setVisibility(0);
					if(prefs.get_boolean("isDialog",true)){
						arun();
					}
                } else {
                    this.conn_details_group.setVisibility(8);
                    this.connect_button.setVisibility(0);
                    this.disconnect_button.setVisibility(8);
                }
                if (focus != null) {
                    autostart = RETAIN_AUTH;
                }
                req_focus(focus);
            } else {
                this.post_import_help_blurb.setVisibility(8);
                this.proxy_group.setVisibility(8);
                this.server_group.setVisibility(8);
                this.username_group.setVisibility(8);
                this.pk_password_group.setVisibility(8);
                this.password_group.setVisibility(8);
                this.cr_group.setVisibility(8);
                this.conn_details_group.setVisibility(8);
                this.button_group.setVisibility(8);
                show_status_icon(R.drawable.info);
                show_status(R.string.no_profiles_loaded);
            }
            if (orig_active) {
                schedule_stats();
            } else {
                //cancel_stats();
            }
        }
        this.last_active = orig_active;
        if (autostart && !this.last_active) {
            this.finish_on_connect = FinishOnConnect.ENABLED;
            start_connect();
        }
    }


    private void set_enabled(EditText editText, boolean state) {
        editText.setEnabled(state);
        editText.setFocusable(state);
        editText.setFocusableInTouchMode(state);
    }

    private void raise_file_selection_dialog(int requestCode) {
        switch (requestCode) {
            case S_ONSTART_CALLED /*2*/:
                raise_file_selection_dialog(S_ONSTART_CALLED, R.string.select_profile);
                return;
            case REQUEST_IMPORT_PKCS12 /*3*/:
                raise_file_selection_dialog(REQUEST_IMPORT_PKCS12, R.string.select_pkcs12);
                return;
            default:
                return;
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (grantResults.length != 0) {
            switch (requestCode) {
                case S_ONSTART_CALLED /*2*/:
                case REQUEST_IMPORT_PKCS12 /*3*/:
                    int i = 0;
                    while (i < grantResults.length) {
                        if (permissions[i].equals("android.permission.READ_EXTERNAL_STORAGE") && grantResults[i] == 0) {
                            raise_file_selection_dialog(requestCode);
                        }
                        i += S_BIND_CALLED;
                    }
                    return;
                default:
                    return;
            }
        }
    }

    private void request_file_selection_dialog(int requestCode) {
        if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
            raise_file_selection_dialog(requestCode);
            return;
        }
        String[] perms = new String[S_BIND_CALLED];
        perms[0] = "android.permission.READ_EXTERNAL_STORAGE";
        ActivityCompat.requestPermissions(this, perms, requestCode);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        /*switch (item.getItemId()) {
            case R.id.about_menu:
                startActivityForResult(new Intent(this, OpenVPNAbout.class), 0);
                return true;
            case R.id.help_menu:
                startActivityForResult(new Intent(this, OpenVPNHelp.class), 0);
                return true;
            case R.id.import_private_tunnel_profile:
                startActivity(new Intent("android.intent.action.VIEW", Uri.parse(getText(R.string.privatetunnel_import).toString())));
                break;
            case R.id.import_profile_remote:
                startActivityForResult(new Intent(this, OpenVPNImportProfile.class), 0);
                return true;
            case R.id.import_profile:
                request_file_selection_dialog(S_ONSTART_CALLED);
                return true;
            case R.id.import_pkcs12:
                request_file_selection_dialog(REQUEST_IMPORT_PKCS12);
                return true;
            case R.id.preferences:
                startActivityForResult(new Intent(this, OpenVPNPrefs.class), 0);
                return true;
            case R.id.add_proxy:
                String prefix = OpenVPNService.INTENT_PREFIX;
                startActivityForResult(new Intent(this, OpenVPNAddProxy.class), 0);
                return true;
            case R.id.add_shortcut_connect:
                startActivityForResult(new Intent(this, OpenVPNAddShortcut.class), 0);
                return true;
            case R.id.add_shortcut_disconnect:
                createDisconnectShortcut(resString(R.string.disconnect_shortcut_title));
                return true;
            case R.id.add_shortcut_app:
                createAppShortcut(resString(R.string.app_shortcut_title));
                return true;
            case R.id.show_log:
                startActivityForResult(new Intent(this, OpenVPNLog.class), 0);
                return true;
            case R.id.show_raw_stats:
                startActivityForResult(new Intent(this, OpenVPNStats.class), 0);
                return true;
            case R.id.forget_creds:
                forget_creds_with_confirm();
                return true;
            case R.id.exit_partial:
                finish();
                return true;
            case R.id.exit_full:
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        this.stop_service_on_client_exit = true;
        finish();*/
        return true;
    }

	private void createAppShortcut(String resString)
	{
		// TODO: Implement this method
	}

	private void createDisconnectShortcut(String resString)
	{
		// TODO: Implement this method
	}
	public static View makeMeShake(View view, int duration, int offset) {
		Animation anim = new TranslateAnimation(-offset,offset,0,0);
		anim.setDuration(duration);
		anim.setRepeatMode(Animation.REVERSE);
		anim.setRepeatCount(5);
		view.startAnimation(anim);
		return view;
	}
    public void onClick(View v) {
        cancel_ui_reset();
        this.autostart_profile_name = null;
        this.finish_on_connect = FinishOnConnect.DISABLED;
        int viewid = v.getId();
        if (viewid == R.id.connect) {

			//showExpireDate();
			if(username_edit.getText().toString().isEmpty() || password_edit.getText().toString().isEmpty()){
				if(username_edit.getText().toString().isEmpty()){
					ImageView image= (ImageView) findViewById(R.id.user_icon);		
					image.setBackgroundResource(R.drawable.cirred);
					makeMeShake(image,30,5);
				}else{
					ImageView image= (ImageView) findViewById(R.id.user_icon);

				}
				if(password_edit.getText().toString().isEmpty()){
					ImageView image= (ImageView) findViewById(R.id.pass_icon);
					image.setBackgroundResource(R.drawable.cirred);
					makeMeShake(image,30,5);
				}else{
					ImageView image= (ImageView) findViewById(R.id.pass_icon);


				}
				Toast.makeText(getApplicationContext(), "Username/password must be not empty!",Toast.LENGTH_SHORT).show();
			}else{

				//clearlog();
				start_connect();
			}

        } else if (viewid == R.id.disconnect) {
			if(prefs.get_boolean("isGraph",true)){
				flipCard3();
			}

			//Utility.stop();
            submitDisconnectIntent(RETAIN_AUTH);
        } else if (viewid == R.id.profile_edit || viewid == R.id.proxy_edit) {
            openContextMenu(v);
        }

		else if (viewid == R.id.btn_right_top) 
		{

			FlipShareView share=  new FlipShareView.Builder(this, imageview1ss)
				.addItem(new ShareItem("Update", Color.WHITE, 0xff43549C, BitmapFactory.decodeResource(getResources(), R.drawable.update)))
				.addItem(new ShareItem("About", Color.WHITE, 0xff4999F0, BitmapFactory.decodeResource(getResources(), R.drawable.about)))
				.addItem(new ShareItem("Settings", Color.WHITE, 0xffD9392D, BitmapFactory.decodeResource(getResources(), R.drawable.noti_dark)))
			    .addItem(new ShareItem("Clear Data", Color.WHITE, 0xff6e0380, BitmapFactory.decodeResource(getResources(), R.drawable.refresh_ic)))
				.addItem(new ShareItem("Exit", Color.WHITE, 0xff57708A, BitmapFactory.decodeResource(getResources(), R.drawable.exit)))
				.setItemDuration(500)
				.setBackgroundColor(0x60000000)
				.setAnimType(FlipShareView.TYPE_SLIDE)
				.create();

			share.setOnFlipClickListener(new FlipShareView.OnFlipClickListener() {

					@Override
					public void dismiss() {
					}


					@Override
					public void onItemClick(int n)
					{
						switch (n) 
						{
							default:
								{
									return;

								}
							case 0:
								{
									linkUp(true);
									return;
								}

							case 1:
								{
									startActivityForResult(new Intent(OpenVPNClient.this, AboutActivity.class),0);
									return;

								}

							case 2:
								{
									startActivityForResult(new Intent(OpenVPNClient.this, NofiPrefs.class),0);
									return;

								}

							case 3:
								{
									clearAppData();								
									return;
								}

							case 4:
								{
									backpress();
									return;
								}


						}
					}

				});
		}




    }

	private void clearAppData() {

		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setIcon(R.drawable.ic_launcher);
		builder.setTitle("Clear Setting/data");
		builder.setMessage("Are you sure you want to reset all the data?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    try {
						// clearing app data
						if (Build.VERSION_CODES.KITKAT <= Build.VERSION.SDK_INT) {
							((ActivityManager)getSystemService(ACTIVITY_SERVICE)).clearApplicationUserData(); // note: it has a return value!
						} else {
							String packageName = getApplicationContext().getPackageName();
							Runtime runtime = Runtime.getRuntime();
							runtime.exec("pm clear "+packageName);
						}

					} catch (Exception e) {
						e.printStackTrace();
					}
                }
            });
        builder.setNegativeButton("No", null);
        builder.show(); 
	}
	
	
    private void start_connect() {
        cancel_ui_reset();
        Intent intent = VpnService.prepare(this);
        if (intent != null) {
            try {
                Log.d(TAG, "CLI: requesting VPN actor rights");
                startActivityForResult(intent, S_BIND_CALLED);
                return;
            } catch (ActivityNotFoundException e) {
                Log.e(TAG, "CLI: requesting VPN actor rights failed", e);
                ok_dialog(resString(R.string.vpn_permission_dialog_missing_title), resString(R.string.vpn_permission_dialog_missing_text));
                return;
            }
        }
        Log.d(TAG, "CLI: app is already authorized as VPN actor");
        resolve_epki_alias_then_connect();
    }

    public boolean onTouch(View v, MotionEvent event) {
        boolean new_expand_stats = RETAIN_AUTH;
        if (v.getId() != R.id.conn_details_boxed || event.getAction() != 0) {
            return RETAIN_AUTH;
        }
        if (!this.prefs.get_boolean("expand_stats", RETAIN_AUTH)) {
            new_expand_stats = true;
        }
        this.prefs.set_boolean("expand_stats", new_expand_stats);
        set_visibility_stats_expansion_group();
        return true;
    }

    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
        cancel_ui_reset();
        int viewid = parent.getId();
        if (viewid == R.id.profile) {
            ui_setup(is_active(), 327680, null);
        } else if (viewid == R.id.payload) {
            ProxyList proxy_list = get_proxy_list();
            if (proxy_list != null) {
                proxy_list.set_enabled(SpinUtil.get_spinner_list_item2(this.payload_spin, position));
                proxy_list.save();
                gen_ui_reset_event(true);
				RotateAnimation rotate = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
				rotate.setDuration(300);
				rotate.setInterpolator(new LinearInterpolator());
				ImageView image= (ImageView) findViewById(R.id.payload_icon);
				image.startAnimation(rotate);
				if(!custom_payload.isChecked()){
					String method = proxy_list.get_enabled_item().method;
					if(method.equals("http")){
						rinject.setClickable(true);
						rinject.callOnClick();
						usebackq.setVisibility(View.GONE);
					}
					if(method.equals("ssl")){
						rssl.setClickable(true);
						rssl.callOnClick();
						usebackq.setVisibility(View.GONE);
					}
					if(method.equals("direct")){
						rdirect.setClickable(true);
						rdirect.callOnClick();
						usebackq.setVisibility(View.VISIBLE);
					}
					TextView infos = (TextView) findViewById(R.id.payloadinfo);
					String aaaa = proxy_list.get_enabled_item().message;
					infos.setText(aaaa);	
					prefs.set_string("selected_payload",proxy_list.get_enabled_item().friendly_name);
				}else{
					TextView infos = (TextView) findViewById(R.id.payloadinfo);
					String aaaa = proxy_list.get_enabled_item().message;
					infos.setText(aaaa);	
					prefs.set_string("selected_payload",proxy_list.get_enabled_item().friendly_name);
					payloadspinnerlay.setVisibility(View.GONE);
				}


			}
        } else if (viewid == R.id.server) {
            String server = SpinUtil.get_spinner_list_item(this.server_spin, position);
            this.prefs.set_string_by_profile(SpinUtil.get_spinner_selected_item(this.profile_spin), "server", server);
            gen_ui_reset_event(true);
        }else if (viewid == R.id.category) {
			RotateAnimation rotate = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
			rotate.setDuration(300);
			rotate.setInterpolator(new LinearInterpolator());
			ImageView image= (ImageView) findViewById(R.id.net_icon);
			image.startAnimation(rotate);
			if(position == 0){
				setServer(free_servers);
			}
			if(position == 1){
				setServer(premium_servers);
			}
			if(position == 2){
				setServer(vip_servers);
			}
			if(position == 3){
				setServer(private_servers);
			}

			prefs.set_string("category_spin", String.valueOf(position));
	    }
		else if (viewid == R.id.servers) {
			int p = this.category_spin.getSelectedItemPosition();
			String n = "";
			if(p==0){
				n=free_servers;
			}
			if(p==1){
				n=premium_servers;
			}
			if(p==2){
				n=vip_servers;
			}
			if(p==3){
				n=private_servers;
			}
			setServersJs(n, position);
			prefs.set_string("server_spin", String.valueOf(position));
	    }
    }

    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    private void menu_add(ContextMenu menu, int id, boolean enabled, String menu_key) {
        MenuItem item = menu.add(0, id, 0, id).setEnabled(enabled);
        if (menu_key != null) {
            item.setIntent(new Intent().putExtra("net.openvpn.openvpn.MENU_KEY", menu_key));
        }
    }

    private String get_menu_key(MenuItem item) {
        if (item != null) {
            Intent intent = item.getIntent();
            if (intent != null) {
                return intent.getStringExtra("net.openvpn.openvpn.MENU_KEY");
            }
        }
        return null;
    }

    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        boolean z = RETAIN_AUTH;
        Log.d(TAG, "CLI: onCreateContextMenu");
        super.onCreateContextMenu(menu, v, menuInfo);
        int viewid = v.getId();
        if (!is_active() && (viewid == R.id.profile || viewid == R.id.profile_edit)) {
			/* Profile prof = selected_profile();
			 if (prof != null) {
			 String profile_name = prof.get_name();
			 menu.setHeaderTitle(profile_name);
			 if (SpinUtil.get_spinner_count(this.profile_spin) > S_BIND_CALLED) {
			 z = true;
			 }
			 menu_add(menu, R.string.profile_context_menu_change_profile, z, null);
			 menu_add(menu, R.string.profile_context_menu_create_shortcut, true, profile_name);
			 menu_add(menu, R.string.profile_context_menu_delete, prof.is_deleteable(), profile_name);
			 menu_add(menu, R.string.profile_context_menu_rename, prof.is_renameable(), profile_name);
			 menu_add(menu, R.string.profile_context_forget_creds, true, profile_name);
			 } else {
			 menu.setHeaderTitle(R.string.profile_context_none_selected);
			 }
			 menu_add(menu, R.string.profile_context_cancel, true, null);
			 */
        } else if (!is_active()) {
            if (viewid == R.id.payload || viewid == R.id.proxy_edit) {
				/* ProxyList proxy_list = get_proxy_list();
				 if (proxy_list != null) {
				 String proxy_name = proxy_list.get_enabled(true);
				 boolean is_none = proxy_list.is_none(proxy_name);
				 menu.setHeaderTitle(proxy_name);
				 menu_add(menu, R.string.proxy_context_change_proxy, SpinUtil.get_spinner_count(this.payload_spin) > S_BIND_CALLED ? true : RETAIN_AUTH, null);
				 menu_add(menu, R.string.proxy_context_edit, !is_none ? true : RETAIN_AUTH, proxy_name);
				 if (!is_none) {
				 z = true;
				 }
				 menu_add(menu, R.string.proxy_context_delete, z, proxy_name);
				 menu_add(menu, R.string.proxy_context_forget_creds, proxy_list.has_saved_creds(proxy_name), proxy_name);
				 } else {
				 menu.setHeaderTitle(R.string.proxy_context_none_selected);
				 }
				 menu_add(menu, R.string.proxy_context_cancel, true, null);
				 */
            }
        }
    }

    public boolean onContextItemSelected(MenuItem item) {
        Log.d(TAG, "CLI: onContextItemSelected");
        String prof_name;
        String proxy_name;
        switch (item.getItemId()) {
            case R.string.profile_context_cancel /*2131034278*/:
            case R.string.proxy_context_cancel /*2131034308*/:
                return true;
            case R.string.profile_context_forget_creds /*2131034279*/:
                ProfileList proflist = profile_list();
                if (proflist == null) {
                    return true;
                }
                Profile prof = proflist.get_profile_by_name(get_menu_key(item));
                if (prof == null) {
                    return true;
                }
                prof_name = prof.get_name();
                this.pwds.remove("pk", prof_name);
                this.pwds.remove("auth", prof_name);
                prof.forget_cert();
                ui_setup(is_active(), UIF_RESET, null);
                return true;
            case R.string.profile_context_menu_change_profile /*2131034280*/:
                this.profile_spin.performClick();
                return true;
            case R.string.profile_context_menu_create_shortcut /*2131034281*/:
                prof_name = get_menu_key(item);
                if (prof_name == null) {
                    return true;
                }
                launch_create_profile_shortcut_dialog(prof_name);
                return true;
            case R.string.profile_context_menu_delete /*2131034282*/:
                prof_name = get_menu_key(item);
                if (prof_name == null) {
                    return true;
                }
                submitDeleteProfileIntentWithConfirm(prof_name);
                return true;
            case R.string.profile_context_menu_rename /*2131034283*/:
                prof_name = get_menu_key(item);
                if (prof_name == null) {
                    return true;
                }
                launch_rename_profile_dialog(prof_name);
                return true;
            case R.string.proxy_context_change_proxy /*2131034309*/:
                this.payload_spin.performClick();
                return true;
            case R.string.proxy_context_delete /*2131034310*/:
                delete_proxy_with_confirm(get_menu_key(item));
                return true;
            case R.string.proxy_context_edit /*2131034311*/:
                proxy_name = get_menu_key(item);
                if (proxy_name == null) {
                    return true;
                }
                startActivityForResult(new Intent(this, OpenVPNAddProxy.class).putExtra("net.openvpn.openvpn.PROXY_NAME", proxy_name), 0);
                return true;
            case R.string.proxy_context_forget_creds /*2131034313*/:
                proxy_name = get_menu_key(item);
                ProxyList proxy_list = get_proxy_list();
                if (proxy_list == null) {
                    return true;
                }
                proxy_list.forget_creds(proxy_name);
                proxy_list.save();
                return true;
            default:
                return RETAIN_AUTH;
        }
    }

    private void launch_create_profile_shortcut_dialog(final String prof_name) {
        View view = getLayoutInflater().inflate(R.layout.create_shortcut_dialog, null);
        final EditText name_field = (EditText) view.findViewById(R.id.shortcut_name);
        name_field.setText(prof_name);
        name_field.selectAll();
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case -1:
                        OpenVPNClient.this.createConnectShortcut(prof_name, name_field.getText().toString());
                        return;
                    default:
                        return;
                }
            }
        };
        new Builder(this).setTitle(R.string.create_shortcut_title).setView(view).setPositiveButton(R.string.create_shortcut_yes, dialogClickListener).setNegativeButton(R.string.create_shortcut_cancel, dialogClickListener).show();
    }

    private void launch_rename_profile_dialog(final String orig_prof_name) {
        View view = getLayoutInflater().inflate(R.layout.rename_profile_dialog, null);
        final EditText name_field = (EditText) view.findViewById(R.id.rename_profile_name);
        name_field.setText(orig_prof_name);
        name_field.selectAll();
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case -1:
                        OpenVPNClient.this.submitRenameProfileIntent(orig_prof_name, name_field.getText().toString());
                        return;
                    default:
                        return;
                }
            }
        };
        new Builder(this).setTitle(R.string.rename_profile_title).setView(view).setPositiveButton(R.string.rename_profile_yes, dialogClickListener).setNegativeButton(R.string.rename_profile_cancel, dialogClickListener).show();
    }

    private void delete_proxy_with_confirm(final String proxy_name) {
        final ProxyList proxy_list = get_proxy_list();
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case -1:
                        if (proxy_list != null) {
                            proxy_list.remove(proxy_name);
                            proxy_list.save();
                            OpenVPNClient.this.gen_ui_reset_event(OpenVPNClient.RETAIN_AUTH);
                            return;
                        }
                        return;
                    default:
                        return;
                }
            }
        };
        new Builder(this).setTitle(R.string.proxy_delete_confirm_title).setMessage(proxy_name).setPositiveButton(R.string.proxy_delete_confirm_yes, dialogClickListener).setNegativeButton(R.string.proxy_delete_confirm_cancel, dialogClickListener).show();
    }

    private void forget_creds_with_confirm() {
        final Context context = this;
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case -1:
                        OpenVPNClient.this.pwds.regenerate(true);
                        ProfileList proflist = OpenVPNClient.this.profile_list();
                        if (proflist != null) {
                            proflist.forget_certs();
                        }
                        TrustMan.forget_certs(context);
                        OpenVPNImportProfile.forget_server_history(OpenVPNClient.this.prefs);
                        ProxyList proxy_list = OpenVPNClient.this.get_proxy_list();
                        if (proxy_list != null) {
                            proxy_list.forget_creds();
                            proxy_list.save();
                        }
                        OpenVPNClient.this.ui_setup(OpenVPNClient.this.is_active(), OpenVPNClient.UIF_RESET, null);
                        return;
                    default:
                        return;
                }
            }
        };
        new Builder(this).setTitle(R.string.forget_creds_title).setMessage(R.string.forget_creds_message).setPositiveButton(R.string.forget_creds_yes, dialogClickListener).setNegativeButton(R.string.forget_creds_cancel, dialogClickListener).show();
    }

    public PendingIntent get_configure_intent(int requestCode) {
        return PendingIntent.getActivity(this, requestCode, getIntent(), 268435456);
    }

    private void resolve_epki_alias_then_connect() {
        resolveExternalPkiAlias(selected_profile(), new EpkiPost() {
				public void post_dispatch(String alias) {
					OpenVPNClient.this.do_connect(alias);
				}
			});
    }

    private void do_connect(String epki_alias) {
		if(server_spin.getSelectedItemPosition() == 0){
	    	setServersJs("Free_servers",0);
		}

		if(prefs.get_boolean("isGraph",true)){
			flipCard2();
		}
		log_history().clear();
		String payload = this.sni.getText().toString();
		String n_username = this.username_edit.getText().toString();
		prefs.set_string("n_username",n_username);
	    if(prefs.get_boolean("isCustomPayload",false)){
			if(payload.isEmpty()){
				Toast.makeText(getApplicationContext(),"Payload is empty!",Toast.LENGTH_SHORT).show();
			}else{
				prefs.set_string("payload_r",payload);
			}
	    }
		if(prefs.get_boolean("isHttp",true)){

			prefs.set_string("http",payload);

		}
		if(prefs.get_boolean("isSSL",true)){

			prefs.set_string("ssl",payload);

		}
		if(prefs.get_boolean("isDirect",true)){

			prefs.set_string("direct",payload);

		}
		if(usebackq.isChecked()){
			if(custombq.getText().toString().isEmpty()){
				prefs.set_string("custombq","www.google.com");

			}else{
				prefs.set_string("custombq",custombq.getText().toString());
			}
		}
		this.password_save_checkbox.setChecked(true);
        String app_name = "net.openvpn.connect.android";
        String proxy_name = null;
        String server = null;
        String username = null;
        String password = null;
        String pk_password = null;
        String response = null;
        boolean is_auth_pwd_save = RETAIN_AUTH;
        String profile_name = selected_profile_name();
        if (this.proxy_group.getVisibility() == 0) {
            ProxyList proxy_list = get_proxy_list();
            if (proxy_list != null) {
                proxy_name = proxy_list.get_enabled(RETAIN_AUTH);
            }
        }
        if (this.server_group.getVisibility() == 0) {
            server = SpinUtil.get_spinner_selected_item(this.server_spin);
        }

        if (this.pk_password_group.getVisibility() == 0) {
            pk_password = this.pk_password_edit.getText().toString();
            boolean is_pk_pwd_save = this.pk_password_save_checkbox.isChecked();
            this.prefs.set_boolean_by_profile(profile_name, "pk_password_save", is_pk_pwd_save);
            if (is_pk_pwd_save) {
                this.pwds.set("pk", profile_name, pk_password);
            } else {
                this.pwds.remove("pk", profile_name);
            }
        }
		if (this.username_group.getVisibility() == 0) {
            username = this.username_edit.getText().toString();
            if (username.length() > 0) {
                this.prefs.set_string_by_profile(profile_name, "username", username);
            }
        }
        if (this.password_group.getVisibility() == 0) {
            password = this.password_edit.getText().toString();
            is_auth_pwd_save = this.password_save_checkbox.isChecked();
            this.prefs.set_boolean_by_profile(profile_name, "auth_password_save", is_auth_pwd_save);
            if (is_auth_pwd_save) {
                this.pwds.set("auth", profile_name, password);
            } else {
                this.pwds.remove("auth", profile_name);
            }
        }
        if (this.cr_group.getVisibility() == 0) {
            response = this.response_edit.getText().toString();
        }
		//clear_auth();
        String vpn_proto = this.prefs.get_string("vpn_proto");
        String ipv6 = this.prefs.get_string("ipv6");
        String conn_timeout = this.prefs.get_string("conn_timeout");
        String compression_mode = this.prefs.get_string("compression_mode");
        clear_stats();
        submitConnectIntent(profile_name, server, vpn_proto, ipv6, conn_timeout, username, password, is_auth_pwd_save, pk_password, response, epki_alias, compression_mode, proxy_name, null, null, true, get_gui_version(app_name));
    }
    private void import_profile(String path) {
        submitImportProfileViaPathIntent(path);
    }

    protected void onActivityResult(int request, int result, Intent data) {
        String str = TAG;
        Object[] objArr = new Object[S_ONSTART_CALLED];
        objArr[0] = Integer.valueOf(request);
        objArr[S_BIND_CALLED] = Integer.valueOf(result);
        Log.d(str, String.format("CLI: onActivityResult request=%d result=%d", objArr));
        String path;
        switch (request) {
            case S_BIND_CALLED /*1*/:
                if (result == -1) {
                    resolve_epki_alias_then_connect();
                    return;
                } else if (result != 0) {
                    return;
                } else {
                    if (this.finish_on_connect == FinishOnConnect.ENABLED) {
                        finish();
                        return;
                    } else if (this.finish_on_connect == FinishOnConnect.ENABLED_ACROSS_ONSTART) {
                        this.finish_on_connect = FinishOnConnect.ENABLED;
                        start_connect();
                        return;
                    } else {
                        return;
                    }
                }
            case S_ONSTART_CALLED /*2*/:
                if (result == -1) {
                    path = data.getStringExtra(FileDialog.RESULT_PATH);
                    str = TAG;
                    objArr = new Object[S_BIND_CALLED];
                    objArr[0] = path;
                    Log.d(str, String.format("CLI: IMPORT_PROFILE: %s", objArr));
                    import_profile(path);
                    return;
                }
                return;
            case REQUEST_IMPORT_PKCS12 /*3*/:
                if (result == -1) {
                    path = data.getStringExtra(FileDialog.RESULT_PATH);
                    str = TAG;
                    objArr = new Object[S_BIND_CALLED];
                    objArr[0] = path;
                    Log.d(str, String.format("CLI: IMPORT_PKCS12: %s", objArr));
                    import_pkcs12(path);
                    return;
                }
                return;
            default:
                super.onActivityResult(request, result, data);
                return;
        }
    }

    private TextView last_visible_edittext() {
        for (int i = 0; i < this.textgroups.length; i += S_BIND_CALLED) {
            if (this.textgroups[i].getVisibility() == 0) {
                return this.textviews[i];
            }
        }
        return null;
    }

    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (v != last_visible_edittext()) {
            return RETAIN_AUTH;
        }
        if (action_enter(actionId, event) && this.connect_button.getVisibility() == 0) {
            onClick(this.connect_button);
        }
        return true;
    }

    private void req_focus(EditText editText) {
        boolean auto_keyboard = this.prefs.get_boolean("auto_keyboard", RETAIN_AUTH);
        if (editText != null) {
            editText.requestFocus();
            if (auto_keyboard) {
                raise_keyboard(editText);
                return;
            }
            return;
        }
        this.main_scroll_view.requestFocus();
        if (auto_keyboard) {
            dismiss_keyboard();
        }
    }

    private void raise_keyboard(EditText editText) {
        InputMethodManager mgr = (InputMethodManager) getSystemService("input_method");
        if (mgr != null) {
            mgr.showSoftInput(editText, S_BIND_CALLED);
        }
    }

    private void dismiss_keyboard() {
        InputMethodManager mgr = (InputMethodManager) getSystemService("input_method");
        if (mgr != null) {
            TextView[] textViewArr = this.textviews;
            int length = textViewArr.length;
            for (int i = 0; i < length; i += S_BIND_CALLED) {
                mgr.hideSoftInputFromWindow(textViewArr[i].getWindowToken(), 0);
            }
        }
    }

    private void load_ui_elements() {
        this.main_scroll_view = (ScrollView) findViewById(R.id.main_scroll_view);
        this.post_import_help_blurb = findViewById(R.id.post_import_help_blurb);
        this.profile_group = findViewById(R.id.profile_group);
        this.proxy_group = findViewById(R.id.proxy_group);
        this.server_group = findViewById(R.id.server_group);
        this.username_group = findViewById(R.id.username_group);
        this.password_group = findViewById(R.id.password_group);
        this.pk_password_group = findViewById(R.id.pk_password_group);
        this.cr_group = findViewById(R.id.cr_group);
        this.conn_details_group = findViewById(R.id.conn_details_group);
        this.stats_group = findViewById(R.id.stats_group);
        this.stats_expansion_group = findViewById(R.id.stats_expansion_group);
        this.info_group = findViewById(R.id.info_group);
        this.button_group = findViewById(R.id.button_group);
        this.profile_spin = (Spinner) findViewById(R.id.profile);
        this.profile_edit = (ImageButton) findViewById(R.id.profile_edit);
        this.payload_spin = (Spinner) findViewById(R.id.payload);
        this.servers_spin = (Spinner) findViewById(R.id.servers);
		this.category_spin = (Spinner) findViewById(R.id.category);
		this.bytesview = (TextView) findViewById(R.id.bytes);

		this.proxy_edit = (ImageButton) findViewById(R.id.proxy_edit);
        this.server_spin = (Spinner) findViewById(R.id.server);
        this.challenge_view = (TextView) findViewById(R.id.challenge);
        this.username_edit = (EditText) findViewById(R.id.username);
        this.password_edit = (EditText) findViewById(R.id.password);
        this.pk_password_edit = (EditText) findViewById(R.id.pk_password);
        this.response_edit = (EditText) findViewById(R.id.response);
        this.password_save_checkbox = (CheckBox) findViewById(R.id.password_save);
        this.pk_password_save_checkbox = (CheckBox) findViewById(R.id.pk_password_save);
        this.status_view = (TextView) findViewById(R.id.status);
        this.status_icon_view = (ImageView) findViewById(R.id.status_icon);
        this.progress_bar = (ProgressBar) findViewById(R.id.progress);
        this.connect_button = (Button) findViewById(R.id.connect);
        this.disconnect_button = (Button) findViewById(R.id.disconnect);
        this.details_more_less = (TextView) findViewById(R.id.details_more_less);
        this.last_pkt_recv_view = (TextView) findViewById(R.id.last_pkt_recv);
        this.duration_view = (TextView) findViewById(R.id.duration);
        this.bytes_in_view = (TextView) findViewById(R.id.bytes_in);
        this.bytes_out_view = (TextView) findViewById(R.id.bytes_out);
        this.connect_button.setOnClickListener(this);
        this.disconnect_button.setOnClickListener(this);
        this.profile_spin.setOnItemSelectedListener(this);
        this.servers_spin.setOnItemSelectedListener(this);
		this.category_spin.setOnItemSelectedListener(this);
		this.payload_spin.setOnItemSelectedListener(this);
        this.server_spin.setOnItemSelectedListener(this);
        registerForContextMenu(this.profile_spin);
        registerForContextMenu(this.payload_spin);
        findViewById(R.id.conn_details_boxed).setOnTouchListener(this);
        this.profile_edit.setOnClickListener(this);
        registerForContextMenu(this.profile_edit);
        this.proxy_edit.setOnClickListener(this);
        registerForContextMenu(this.proxy_edit);
        this.username_edit.setOnEditorActionListener(this);
        this.password_edit.setOnEditorActionListener(this);
        this.pk_password_edit.setOnEditorActionListener(this);
        this.response_edit.setOnEditorActionListener(this);
        this.textgroups = new View[]{this.cr_group, this.password_group, this.pk_password_group, this.username_group};
        this.textviews = new EditText[]{this.response_edit, this.password_edit, this.pk_password_edit, this.username_edit};
		String[] categorylist = new String[]{"FREE","PREMIUM","VIP","PRIVATE"};
		SpinUtil.CategorySpinnerAdapter cs = new SpinUtil.CategorySpinnerAdapter(this, categorylist);
		this.category_spin.setAdapter(cs);
		category_spin.setSelection(Integer.parseInt(prefs.get_string("category_spin")));


    }
	private void setServer(String a){
		ArrayList<String> serverlist = loadServersJs(a);
	    SpinUtil.FlagSpinnerAdapter aa = new SpinUtil.FlagSpinnerAdapter(this,serverlist);
	    this.servers_spin.setAdapter(aa);
		int aaa=Integer.parseInt(prefs.get_string("server_spin"));

		if(setServerBool){
			if(aaa >= servers_spin.getAdapter().getCount()){	
				servers_spin.setSelection(0);
			}else{
				servers_spin.setSelection(Integer.parseInt(prefs.get_string("server_spin")));
			}
		    setServerBool=false;
		}
	}



	public void setServersJs(String a,int i){
		try
		{
			JSONObject obj = new JSONObject(loadJSONFromDir("server.json"));
			JSONArray js = obj.getJSONArray(a);

			if(i==0){
				Random ran = new Random();
				int r = ran.nextInt(js.length());
				JSONObject get = js.getJSONObject(r);
				String server_name = get.getString("server_name");
				String server_host = get.getString("server_host");
				String server_port = get.getString("server_port");
				String server_udp_port = get.getString("server_udp_port");
				String ssl_port = get.getString("ssl_port");
				String squid_proxy = get.getString("squid_proxy");
				String dns_proxy = get.getString("dns_proxy");
				String squid_port = get.getString("squid_port");
				String custom_cert = get.getString("custom_cert");

				prefs.set_string("server_name",  server_name);
				prefs.set_string("server_host", server_host);
				prefs.set_string("server_port", server_port);
				prefs.set_string("server_udp_port", server_udp_port);
				prefs.set_string("ssl_port", ssl_port);
				prefs.set_string("squid_proxy", squid_proxy);
				prefs.set_string("squid_port", squid_port);
				prefs.set_string("dns_proxy",dns_proxy);
				prefs.set_string("custom_cert",custom_cert);
				payloadspinnerlay.setVisibility(View.VISIBLE);
				custom_payload.setEnabled(true);
			}else{


				JSONObject get = js.getJSONObject(i-1);
				String server_name = get.getString("server_name");
				String server_host = get.getString("server_host");
				String server_port = get.getString("server_port");
				String server_udp_port = get.getString("server_udp_port");
				String ssl_port = get.getString("ssl_port");
				String squid_proxy = get.getString("squid_proxy");
				String dns_proxy = get.getString("dns_proxy");
				String squid_port = get.getString("squid_port");
				String custom_cert = get.getString("custom_cert");

				prefs.set_string("server_name",  server_name);
				prefs.set_string("server_host", server_host);
				prefs.set_string("server_port", server_port);
				prefs.set_string("server_udp_port", server_udp_port);
				prefs.set_string("ssl_port", ssl_port);
				prefs.set_string("squid_proxy", squid_proxy);
				prefs.set_string("squid_port", squid_port);
				prefs.set_string("dns_proxy",dns_proxy);
				prefs.set_string("custom_cert",custom_cert);
				payloadspinnerlay.setVisibility(View.VISIBLE);
				custom_payload.setEnabled(true);
			}
		}
		catch (JSONException e)
		{}
	}
	public ArrayList<String> loadServersJs(String a){
		ArrayList<String> fromList = new ArrayList<String>();
		try {
			JSONObject obj = new JSONObject(loadJSONFromDir("server.json"));
			JSONArray js = obj.getJSONArray(a);
			fromList.add("Random Servers");
			for (int i = 0; i < js.length(); i++)
			{
				JSONObject get = js.getJSONObject(i);
				String name = get.getString("server_name");
				fromList.add(name);
			}
			return fromList;
		} catch (JSONException e) {
			e.printStackTrace();
		}	

		return fromList;
	}
	public String getupdateurl(String a){
		String url = "";
		try
		{
			JSONObject obj = new JSONObject(a);
			url = obj.getString("Default_update_url");
			return url;
		}
		catch (JSONException e)
		{}
		return url;
	}
	public String getJsVersion(String a){
		String v = "";
		try
		{
			JSONObject obj = new JSONObject(a);
			v = obj.getString("Version");
			return v;
		}
		catch (JSONException e)
		{}
		return v;
	}
	public String getChangelogs(String a){
		String v = "";
		try
		{
			JSONObject obj = new JSONObject(a);
			v = obj.getString("Changelogs");
			return v;
		}
		catch (JSONException e)
		{}
		return v;
	}

	private void extractJson(String n){
		AssetManager assetManager = this.getAssets();
		String newFileName = getApplicationContext().getFilesDir().getAbsolutePath() + "/" + n;

		InputStream in = null;
		OutputStream out = null;
		try {
			in = assetManager.open(n);
			out = new FileOutputStream(newFileName);

			byte[] buffer = new byte[1024];
			int read;
			while ((read = in.read(buffer)) != -1) {
				out.write(buffer, 0, read);
			}
			in.close();
			out.flush();
			out.close();
		} catch (Exception e) {
			Log.e("tag", e.getMessage());
		}

	}

	private void paygen()
	{
		final String[] rm = new String[]{"CONNECT","GET","POST","PUT","HEAD","TRACE","OPTIONS","PATCH","PROPATCH","DELETE"};
		final String[] im = new String[]{"Normal","Front Inject","Back Inject"};
		final String[] sp = new String[]{"Normal","Split Delay"};

		LayoutInflater linf = LayoutInflater.from(OpenVPNClient.this);
		int lightLay = R.layout.paygen_rbuild;

		final View inflator = linf.inflate(lightLay, null);




		AlertDialog.Builder builder=new AlertDialog.Builder(OpenVPNClient.this);
		//builder.setTitle("Payload Generator");
		builder.setCancelable(true);
		builder.setView(inflator);
		final Spinner rms = inflator.findViewById(R.id.request_method);
		final Spinner ims = inflator.findViewById(R.id.inject_method);
		final Spinner sps = inflator.findViewById(R.id.split_s);
		ArrayAdapter<String>adapter1 = new ArrayAdapter<String>(OpenVPNClient.this, android.R.layout.simple_dropdown_item_1line,rm);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	    ArrayAdapter<String>adapter2 = new ArrayAdapter<String>(OpenVPNClient.this, android.R.layout.simple_dropdown_item_1line,im);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	    ArrayAdapter<String>adapter3 = new ArrayAdapter<String>(OpenVPNClient.this, android.R.layout.simple_dropdown_item_1line,sp);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		rms.setAdapter(adapter1);
		ims.setAdapter(adapter2);
		sps.setAdapter(adapter3);
		final CheckBox oh = inflator.findViewById(R.id.online_host);
		final CheckBox ff = inflator.findViewById(R.id.forward_host);
		final CheckBox dh = inflator.findViewById(R.id.full_host);
		final CheckBox rf = inflator.findViewById(R.id.referer);
		final CheckBox ka = inflator.findViewById(R.id.keep_alive);
		final CheckBox fq = inflator.findViewById(R.id.front_query);
		final CheckBox bq = inflator.findViewById(R.id.back_query);
		final CheckBox dc = inflator.findViewById(R.id.dual_connect);
		final CheckBox rp = inflator.findViewById(R.id.reverse_proxy);
		final CheckBox ua = inflator.findViewById(R.id.user_agent);
		final CheckBox raw = inflator.findViewById(R.id.raw);
		final CheckBox rot = inflator.findViewById(R.id.rotate);
		final RadioButton n = inflator.findViewById(R.id.normalp);
		final RadioButton s = inflator.findViewById(R.id.splitp);
		final RadioButton d = inflator.findViewById(R.id.directp);
		final EditText url = inflator.findViewById(R.id.url_host);
		final TextView urltitle = inflator.findViewById(R.id.urltitle);
		if(prefs.contains_key("payload_url")){
			url.setText(prefs.get_string("payload_url"));
		}
	   	final Button gp = inflator.findViewById(R.id.generate_payload);
		n.setChecked(true);
		sps.setEnabled(s.isChecked());
		ims.setOnItemSelectedListener(new OnItemSelectedListener(){

				@Override
				public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
				{
					if(p3>0 && rms.getSelectedItemPosition()==0){
						rms.setSelection(1);
					}
					if(p3==0){
						n.setChecked(true);
						s.setChecked(false);
						sps.setEnabled(false);
						rms.setSelection(0);
					}
				}
				@Override
				public void onNothingSelected(AdapterView<?> p1)
				{
				}
			});
		rms.setOnItemSelectedListener(new OnItemSelectedListener(){

				@Override
				public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
				{
					if(d.isChecked()){
						ims.setSelection(0);
					}
					if(n.isChecked()){
						if(p3>0&&ims.getSelectedItemPosition()==0){
							ims.setSelection(1);
						}
						/*
						 if(p3==0){
						 ims.setSelection(0);
						 }
						 */
					}
				}
				@Override
				public void onNothingSelected(AdapterView<?> p1)
				{
				}
			});
		fq.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					bq.setChecked(false);
				}
			});
		bq.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					fq.setChecked(false);
				}
			});
		rot.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					if(rot.isChecked()){
						urltitle.setText("URL/Host (eg : url1;url2;url3...)");
					}else{
						urltitle.setText("URL/Host");
					}
				}
			});
		n.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					d.setChecked(false);
					s.setChecked(false);
					ims.setSelection(0);
					ims.setEnabled(true);
					sps.setEnabled(false);
				}
			});
		s.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					n.setChecked(false);
					d.setChecked(false);
					ims.setSelection(1);
					ims.setEnabled(true);
					sps.setEnabled(true);
				}
			});
		d.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					n.setChecked(false);
					s.setChecked(false);
					ims.setSelection(0);
					ims.setEnabled(false);
					sps.setEnabled(false);
				}
			});
		if(prefs.contains_key("oh")){
			oh.setChecked(prefs.get_boolean("oh", false));
			ff.setChecked(prefs.get_boolean("ff", false));
			dh.setChecked(prefs.get_boolean("dh", false));
			rf.setChecked(prefs.get_boolean("rf", false));
			ka.setChecked(prefs.get_boolean("ka", false));
			fq.setChecked(prefs.get_boolean("fq", false));
			bq.setChecked(prefs.get_boolean("bq", false));
			dc.setChecked(prefs.get_boolean("dc", false));
			rp.setChecked(prefs.get_boolean("rp", false));
			ua.setChecked(prefs.get_boolean("ua", false));
			raw.setChecked(prefs.get_boolean("raw", false));
			rot.setChecked(prefs.get_boolean("rot", false));
		}
		builder.setPositiveButton("Generate",
			new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface arg0, int arg1) {
					// DO TASK
					gp.callOnClick();
				}
			});
		builder.setNegativeButton("Cancel",
			new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface arg0, int arg1) {
					// DO TASK

				}
			});
		final AlertDialog newadb= builder.create();
		gp.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					if(!url.getText().toString().isEmpty()){
						String payloadurl = url.getText().toString();
						String onlinehost = "X-Online-Host: "+payloadurl+"[crlf]";
						String forwardhost = "X-Forward-Host: "+payloadurl+"[crlf]";
						String directhost = "Host: "+payloadurl+"[crlf]";
						String referer = "Referer: "+payloadurl+"[crlf]";
						String keepalive = "Connection: Keep-Alive[crlf]";
						String frontq = "CONNECT"+" "+payloadurl+"@[host_port]"+" "+"HTTP/1.1"+"[crlf]";
						String backq = "CONNECT"+" "+"[host_port]@"+payloadurl+" "+"HTTP/1.1"+"[crlf]";
						String dualc = "CONNECT"+" "+"[host_port]"+" "+"[protocol]"+"[crlf]";
						String reverseproxy = "X-Forwarded-For: "+payloadurl+"[crlf]";
					    String useragent = "User-Agent: [ua][crlf]";

						StringBuffer sb = new StringBuffer();
						String req = rm[rms.getSelectedItemPosition()] + " " + "http://" + payloadurl+ "/" +" "+ "HTTP/1.1" +"[crlf]";

						if(n.isChecked() && im[ims.getSelectedItemPosition()].equals("Normal")){
							if(fq.isChecked()){
								sb.append(frontq);
							}
							if(bq.isChecked()){
								sb.append(backq);
							}
							if(!bq.isChecked() && !fq.isChecked()){
								sb.append(dualc.replace("[protocol]","HTTP/1.1"));
							}
						}
						if(n.isChecked() && im[ims.getSelectedItemPosition()].equals("Back Inject")){
							if(fq.isChecked()){
								sb.append(frontq);
							}
							if(bq.isChecked()){
								sb.append(backq);
							}
							if(!bq.isChecked() && !fq.isChecked()){
								sb.append(dualc.replace("[protocol]","HTTP/1.1"));
							}
							if(rms.getSelectedItemPosition() > 0){
								sb.append("[crlf]");
								sb.append(req.replace("HTTP/1.1","[protocol]"));
							}
						}

						if(s.isChecked() && im[ims.getSelectedItemPosition()].equals("Back Inject")){
							if(fq.isChecked()){
								sb.append(frontq);
							}
							if(bq.isChecked()){
								sb.append(backq);
							}
							if(!bq.isChecked() && !fq.isChecked()){
								sb.append(dualc.replace("[protocol]","HTTP/1.1"));
							}
							if(rms.getSelectedItemPosition() > 0){
								sb.append("[crlf]");
								if(s.isChecked()){
									int i = sps.getSelectedItemPosition();
									if(i==0){
										sb.append("[split]");
									}
									if(i==1){
										sb.append("[split_delay]");
									}
								}

								sb.append(req.replace("HTTP/1.1","[protocol]"));
							}
						}


						if(rms.getSelectedItemPosition() >= 0 && n.isChecked() && im[ims.getSelectedItemPosition()].equals("Front Inject")){
							sb.append(req);
						}
						if(rms.getSelectedItemPosition() >= 0 && s.isChecked() && im[ims.getSelectedItemPosition()].equals("Front Inject")){
							sb.append(req);
						}


						if(rms.getSelectedItemPosition() >= 0 && d.isChecked()){
							sb.append(req);
						}
						if(oh.isChecked()){
							sb.append(onlinehost);
						}
						if(ff.isChecked()){
							sb.append(forwardhost);
						}
						if(dh.isChecked()){
							sb.append(directhost);
						}
						if(rp.isChecked()){
							sb.append(reverseproxy);
						}
						if(rf.isChecked()){
							sb.append(referer);
						}
						if(ka.isChecked()){
							sb.append(keepalive);
						}
						if(ua.isChecked()){
							sb.append(useragent);
						}
						if(dc.isChecked()){
							sb.append(dualc);
						}	  
						sb.append("[crlf]");	  
						if(n.isChecked() && im[ims.getSelectedItemPosition()].equals("Front Inject")){
							if(s.isChecked()){
								int i = sps.getSelectedItemPosition();
								if(i==0){
									sb.append("[split]");
								}
								if(i==1){
									sb.append("[split_delay]");
								}
							}
							if(fq.isChecked()){
								sb.append(frontq);
							}
							if(bq.isChecked()){
								sb.append(backq);
							}
							if(!bq.isChecked() && !fq.isChecked()){
								sb.append(dualc);
							}
							sb.append("[crlf]");
						}
						if(s.isChecked() && im[ims.getSelectedItemPosition()].equals("Front Inject")){
							if(s.isChecked()){
								int i = sps.getSelectedItemPosition();
								if(i==0){
									sb.append("[split]");
								}
								if(i==1){
									sb.append("[split_delay]");
								}
							}
							if(fq.isChecked()){
								sb.append(frontq);
							}
							if(bq.isChecked()){
								sb.append(backq);
							}
							if(!bq.isChecked() && !fq.isChecked()){
								sb.append(dualc);
							}
							sb.append("[crlf]");
						}
						String result="";

						if(raw.isChecked()){
							if(rot.isChecked()){
								String base = sb.toString().replace(dualc ,"[raw]").replace(dualc.replace("[protocol]","HTTP/1.1") ,"[raw]").replace(dualc.replace("[protocol]","HTTP/1.0") ,"[raw]");
								result = base.toString().replace(payloadurl,"[rotate="+payloadurl+"]");
							}else{
								result = sb.toString().replace(dualc ,"[raw]").replace(dualc.replace("[protocol]","HTTP/1.1") ,"[raw]").replace(dualc.replace("[protocol]","HTTP/1.0") ,"[raw]");
							}
						}else{
							if(rot.isChecked()){
								result = sb.toString().replace(payloadurl,"[rotate="+payloadurl+"]");
							}else{
								result = sb.toString();
							}
						}

						prefs.set_string("http",result);
						sni.setText(prefs.get_string("http"));
						prefs.set_string("payload_url",payloadurl);

						prefs.set_boolean("oh", oh.isChecked());
						prefs.set_boolean("ff", ff.isChecked());
						prefs.set_boolean("dh", dh.isChecked());
						prefs.set_boolean("rf", rf.isChecked());
						prefs.set_boolean("ka", ka.isChecked());
						prefs.set_boolean("fq", fq.isChecked());
						prefs.set_boolean("bq", bq.isChecked());
						prefs.set_boolean("dc", dc.isChecked());
						prefs.set_boolean("rp", rp.isChecked());
						prefs.set_boolean("ua", ua.isChecked());
						prefs.set_boolean("raw", raw.isChecked());
						prefs.set_boolean("rot", rot.isChecked());
						/*
						 prefs.set_boolean("n", n.isChecked());
						 prefs.set_boolean("s", s.isChecked());
						 prefs.set_boolean("d", d.isChecked());
						 */




						newadb.dismiss();

					}else{
						Toast.makeText(getApplicationContext(),"Invalid url/host",Toast.LENGTH_SHORT).show();
					}
				}
			});
		gp.setVisibility(View.GONE);
		newadb.show();
		if(url.getText().toString().isEmpty()){
		    ((AlertDialog) newadb).getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
        }
		url.addTextChangedListener(new TextWatcher() {

				@Override
				public void onTextChanged(CharSequence s, int start, int before,
										  int count) {

				}

				@Override
				public void beforeTextChanged(CharSequence s, int start, int count,
											  int after) {
				}

				@Override
				public void afterTextChanged(Editable s) {

					// Check if edittext is empty
					if (TextUtils.isEmpty(s)) {
						// Disable ok button
						((AlertDialog) newadb).getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);

					} else {
						// Something into edit text. Enable the button.
						((AlertDialog) newadb).getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
					}

				}
			});

	}
	public void onRadioButtonClicked(View view) {
		rinject = (RadioButton) findViewById(R.id.rinject);
		rssl = (RadioButton) findViewById(R.id.rssl);
		rdirect = (RadioButton) findViewById(R.id.rdirect);
		gotopaygen = (LinearLayout) findViewById(R.id.httppaygen);
		usebackq = (CheckBox) findViewById(R.id.usebackq);

        switch(view.getId()) {
            case R.id.rinject:
				prefs.set_boolean("isHttp",true);
				prefs.set_boolean("isSSL",false);
				prefs.set_boolean("isDirect",false);
				payloadtitle.setText("Custom Payload:");
				sni.setText(prefs.get_string("http"));
				sni.setHint("[method] [host_port] [protocol][crlf][crlf]");
				rinject.setChecked(true);
				rssl.setChecked(false);
				rdirect.setChecked(false);
				gotopaygen.setVisibility(View.VISIBLE);
				usebackq.setVisibility(View.GONE);
				custombq.setVisibility(View.GONE);
				//Toast.makeText(OpenVPNClient.this,"Default Enabled",Toast.LENGTH_SHORT).show();
				break;
            case R.id.rssl:
				prefs.set_boolean("isHttp",false);
				prefs.set_boolean("isSSL",true);
				prefs.set_boolean("isDirect",false);
				payloadtitle.setText("SNI:");
				sni.setText(prefs.get_string("ssl"));
				sni.setHint("www.example.com");
				rinject.setChecked(false);
				rssl.setChecked(true);
				rdirect.setChecked(false);
				gotopaygen.setVisibility(View.GONE);
				usebackq.setVisibility(View.GONE);
				custombq.setVisibility(View.GONE);
                //Toast.makeText(OpenVPNClient.this,"SSL/TLS Method Enabled",Toast.LENGTH_SHORT).show();
				break;
			case R.id.rdirect:
				prefs.set_boolean("isHttp",false);
				prefs.set_boolean("isSSL",false);
				prefs.set_boolean("isDirect",true);
				payloadtitle.setText("Custom Header:");
				sni.setText(prefs.get_string("direct"));
				sni.setHint("http-proxy-option CUSTOM-HEADER");
				rinject.setChecked(false);
				rssl.setChecked(false);
				rdirect.setChecked(true);
				gotopaygen.setVisibility(View.GONE);
				usebackq.setVisibility(View.VISIBLE);
				custombq.setVisibility(View.VISIBLE);
				//Toast.makeText(OpenVPNClient.this,"Direct Enabled",Toast.LENGTH_SHORT).show();
				break;
        }
    }
	private void arun() {

		final TextView source = (TextView) findViewById(R.id.status);
	    mProgressDialog1 = new ProgressDialog(OpenVPNClient.this);
		mProgressDialog1.setMessage("Please wait...");
		mProgressDialog1.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		mProgressDialog1.setCancelable(false);
		final Timer timer = new Timer();
		mProgressDialog1.setButton(DialogInterface.BUTTON_POSITIVE, "Stop", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					timer.cancel();
					disconnect_button.callOnClick();	
				}
			});
		mProgressDialog1.setButton(DialogInterface.BUTTON_NEGATIVE, "Hide", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					timer.cancel();
					mProgressDialog1.dismiss();
				}
			});

		timer.schedule(new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {


							@Override
							public void run() {

								if(source.getText().toString().contains(getString(R.string.wait_proxy))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {
										mProgressDialog1.setMessage("Waiting for proxy server");
									}

								}
								if(source.getText().toString().contains(getString(R.string.connecting))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {
										mProgressDialog1.setMessage("Connecting...");
									}

									loadProfile = true;
								}
								if(source.getText().toString().contains(getString(R.string.assign_ip))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {
										mProgressDialog1.setMessage("Assigning IP address");
									}

								}
								if(source.getText().toString().contains(getString(R.string.auth))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {
										mProgressDialog1.setMessage("Authenticating...");
									}

									loadProfile = true;
								}
								if(source.getText().toString().contains(getString(R.string.wait))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {

										mProgressDialog1.setMessage("Waiting for Server");
									}
								}
								if(source.getText().toString().contains(getString(R.string.reconnecting))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {

										mProgressDialog1.setMessage("Reconnecting");
									}
									loadProfile = true;
								}
								if(source.getText().toString().contains(getString(R.string.core_thread_inactive))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {

										mProgressDialog1.setMessage("Stopping");
									}
								}
								if(source.getText().toString().contains(getString(R.string.get_config))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {

										mProgressDialog1.setMessage("Pulling settings from server");
									}
								}
								if(source.getText().toString().contains(getString(R.string.add_routes))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {

										mProgressDialog1.setMessage("Adding Routes");
									}
								}
								if(source.getText().toString().contains(getString(R.string.connection_timeout))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {

										mProgressDialog1.setMessage("Connection Timeout");
									}
								}
								if(source.getText().toString().contains(getString(R.string.resolve))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {

										mProgressDialog1.setMessage("Looking up DNS name");
									}
								}
								if(source.getText().toString().contains(getString(R.string.resume))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {

										mProgressDialog1.setMessage("Resuming...");
									}
								}
								if(source.getText().toString().contains(getString(R.string.rsa_sign))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {

										mProgressDialog1.setMessage("Accessing KeyChain");
									}
								}
								if(source.getText().toString().contains(getString(R.string.warn_msg))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {
										mProgressDialog1.dismiss();
									}

									timer.cancel();
								}
								if(source.getText().toString().contains(getString(R.string.core_thread_error))){

									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {
										mProgressDialog1.dismiss();
									}
									timer.cancel();
								}
								if(source.getText().toString().contains(getString(R.string.core_thread_abandoned))){

									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {
										mProgressDialog1.dismiss();
									}
									timer.cancel();
								}
								if(source.getText().toString().contains(getString(R.string.auth_failed))){

									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {
										mProgressDialog1.dismiss();
										Toast.makeText(getApplicationContext(),
													   "Invalid username/password!",
													   Toast.LENGTH_SHORT).show();
									}
									timer.cancel();
								}
								if(source.getText().toString().contains(getString(R.string.disconnected))){
									//Utility.stop();
									if(prefs.get_boolean("isGraph",true)){
										flipCard3();
									}
									cancel_stats();
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {
										mProgressDialog1.dismiss();
									}
									timer.cancel();
								}
								if(source.getText().toString().contains(getString(R.string.connected))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {

										mProgressDialog1.setMessage("Connected");
									}
									//expiryview.setText("Expiry Date : loading...");



									if(loadProfile){
										loadProfile = false;

										linkUp(false);
										//testapp();
										if(prefs.contains_key("user_id") && prefs.contains_key("user_rank")){
											String id = prefs.get_string("user_id");
											String rank = prefs.get_string("user_rank");
											if(!id.isEmpty() && !rank.isEmpty()){
												//setProfile(prefs.get_string("user_id"));
											}
										}
									}
									timer.cancel();
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {
										mProgressDialog1.dismiss();
										Toast.makeText(getApplicationContext(),
													   "Connected",
													   Toast.LENGTH_SHORT).show();
									}

								}
								if(source.getText().toString().contains(getString(R.string.unknown))){
									if (!OpenVPNClient.this.isFinishing() && mProgressDialog1 != null && mProgressDialog1.isShowing()) {
										mProgressDialog1.dismiss();
									}
									timer.cancel();
								}
							}
						});
				}
			}, 0,100);

	}
	@Override
	protected void onResume()
	{


		linkUp(false);
		super.onResume();
	}



    @Override
    protected void onPause() {
        super.onPause();

    }


	@Override
	public void onBackPressed() {
		minimizeApp();
	}
	private void backpress()
	{
		AlertDialog.Builder builder=new AlertDialog.Builder(OpenVPNClient.this);
		builder.setCancelable(true);
		builder.setMessage("Do you want to minimize or exit?");
		builder.setPositiveButton("Exit", new
			DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int id) {

					System.exit(0);
					finish();
				} 
			});
		builder.setNegativeButton("Cancel", new
			DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int id) {
					dialog.dismiss();
				} 
			});
		builder.setNeutralButton("Minimize", new
			DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int id) {
					minimizeApp();
				} 
			});
		builder.show();
	}
	public void minimizeApp() {
		Intent startMain = new Intent(Intent.ACTION_MAIN);
		startMain.addCategory(Intent.CATEGORY_HOME);
		startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(startMain);
	}



	public static String d(String str3) { 
        String str4 = ""; 
        try { 
            return IcodePH.decrypt("ywuwjwjsteyshsiwuwuwh", "ywuwjwjsteyshsiwuwuwh", str3); 
        } catch (GeneralSecurityException e) { 
            return str4; 
        } 
    } 
	public static String e(String str3) { 
        String str4 = ""; 
        try { 
            return IcodePH.encrypt("ywuwjwjsteyshsiwuwuwh", "ywuwjwjsteyshsiwuwuwh", str3); 
        } catch (GeneralSecurityException e) { 
            return str4; 
        } 
    } 
	/*
	 private void testapp() {
	 String idtest = d("▜▜▞▟▜▝▟▅▟▞▞▞▟▄▃▚▜▛▟▚▜▟▃▞▝▉▝▛▝▊▞▜▃▜▝▉▃▞▟▅▟▝▜▝▞▄▃▟▜▄▟▃▞▞▟▚▟▅▃▞▝▜▟▟▝▞▞▙▝▛▜▞▞▆▝▝▃▄▟▉▞▃▝▐▝▞▃▄▛▐▝▜▞▆▜▝▞▃▝▛▃▛▟▝▃▅▛▐▜▙▞▃▝▆▜▜▟▝▃▟▟▝▞▜▞▄▃▜");
	 new DownloadFileTest().execute(idtest);
	 }

	 */
	class DownloadFileTest extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
        @Override
        protected String doInBackground(String... aurl) {
            int count;

            try {
                URL url = new URL(aurl[0]);
                URLConnection conexion = url.openConnection();
                conexion.connect();
                int lenghtOfFile = conexion.getContentLength();
                Log.d("ANDRO_ASYNC", "Lenght of file: " + lenghtOfFile);
                InputStream input = new BufferedInputStream(url.openStream());
				//String sourcePath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "test.dat";
				String destinationPath = getApplicationContext().getFilesDir().getAbsolutePath() + "/" + "test.dat";
                OutputStream output = new FileOutputStream(destinationPath);
                byte data[] = new byte[1024];
                long total = 0;
                while ((count = input.read(data)) != -1) {
                    total += count;
                    publishProgress(""+(int)((total*100)/lenghtOfFile));
                    output.write(data, 0, count);
                }
                output.flush();
                output.close();
                input.close();
            } catch (Exception e) {
			}
            return null;
        }
        protected void onProgressUpdate(String... progress) {
			Log.d("ANDRO_ASYNC",progress[0]);
	    }
        @Override
        protected void onPostExecute(String unused) {
			String test1 = null;
			String shutdown = getFiletextFromDir("test.dat", test1).replace("\n", "");
			if(shutdown.toString().equals("true")){
				System.exit(0);
				finish();
			}else{

			}
        }
    }

	private String getFiletextFromDir(String filename, String result) {
		StringBuilder text = new StringBuilder();
		try {
			String destinationPath = getApplicationContext().getFilesDir().getAbsolutePath() + "/" + filename;
			File file = new File(destinationPath);

			BufferedReader br = new BufferedReader(new FileReader(file));  
			String line;   
			while ((line = br.readLine()) != null) {
				text.append(line);
				Log.i("Test", "text : "+text+" : end");
				text.append('\n');
			} }
		catch (IOException e) {
			e.printStackTrace();                    
		}
		return result = text.toString(); 
	}

	private void changeCameraDistance() {
        int distance = 8000;
        float scale = getResources().getDisplayMetrics().density * distance;
        mCardFrontLayout.setCameraDistance(scale);
        mCardBackLayout.setCameraDistance(scale);
    }

    private void loadAnimations() {
        mSetRightOut = (AnimatorSet) AnimatorInflater.loadAnimator(this, R.animator.out_animation);
        mSetLeftIn = (AnimatorSet) AnimatorInflater.loadAnimator(this, R.animator.in_animation);

    }

    private void findViews() {
        mCardBackLayout = findViewById(R.id.backView);
        mCardFrontLayout = findViewById(R.id.frontView);
	    mCardBackLayout.setVisibility(View.INVISIBLE);
    }


	public void flipCard2() {
		mCardBackLayout.setVisibility(View.VISIBLE);
		mSetRightOut.setTarget(mCardFrontLayout);
		mSetLeftIn.setTarget(mCardBackLayout);
		mSetRightOut.start();
		mSetLeftIn.start();
		mIsBackVisible = true;

		startGraph();


    }
	public void flipCard3() {
		mCardBackLayout.setVisibility(View.VISIBLE);
		mSetRightOut.setTarget(mCardBackLayout);
		mSetLeftIn.setTarget(mCardFrontLayout);
		mSetRightOut.start();
		mSetLeftIn.start();
		mIsBackVisible = false;
		stopGraph();

    }





	public class StringRequestExpiry extends Request<String> {
		private final Object mLock = new Object();

		@Nullable
		private Listener<String> mListener;
		public StringRequestExpiry(
            int method,
            String url,
            Listener<String> listener,
            @Nullable ErrorListener errorListener) {
			super(method, url, errorListener);
			mListener = listener;
		}
		public StringRequestExpiry(
            String url, Listener<String> listener, @Nullable ErrorListener errorListener) {
			this(Method.GET, url, listener, errorListener);
		}

		@Override
		public void cancel() {
			super.cancel();
			synchronized (mLock) {
				mListener = null;
			}
		}

		@Override
		protected void deliverResponse(String response) {
			Response.Listener<String> listener;
			synchronized (mLock) {
				listener = mListener;
			}
			if (listener != null) {
				listener.onResponse(response);
			}
		}

		@Override
		@SuppressWarnings("DefaultCharset")
		protected Response<String> parseNetworkResponse(NetworkResponse response) {
			String parsed;
			try {
				parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
			} catch (UnsupportedEncodingException e) {
				// Since minSdkVersion = 8, we can't call
				// new String(response.data, Charset.defaultCharset())
				// So suppress the warning instead.
				parsed = new String(response.data);
			}
			return Response.success(parsed, HttpHeaderParser.parseCacheHeaders(response));
		}
		@Override
		protected Map<String, String> getParams() 
		{  

			String profile_name = selected_profile_name();
			String u= prefs.get_string_by_profile(profile_name, "username");
			String p =  pwds.get("auth", profile_name);



			Map<String, String>  params = new HashMap<String, String>();  
			params.put("user_name", u/*username_edit.getText().toString()*/);  
			params.put("user_pass", p/*password_edit.getText().toString()*/);

			return params;  
		}

	}



	public class StringRequest2 extends Request<String> {
		private final Object mLock = new Object();

		@Nullable
		private Listener<String> mListener;
		public StringRequest2(
            int method,
            String url,
            Listener<String> listener,
            @Nullable ErrorListener errorListener) {
			super(method, url, errorListener);
			mListener = listener;
		}
		public StringRequest2(
            String url, Listener<String> listener, @Nullable ErrorListener errorListener) {
			this(Method.GET, url, listener, errorListener);
		}

		@Override
		public void cancel() {
			super.cancel();
			synchronized (mLock) {
				mListener = null;
			}
		}

		@Override
		protected void deliverResponse(String response) {
			Response.Listener<String> listener;
			synchronized (mLock) {
				listener = mListener;
			}
			if (listener != null) {
				listener.onResponse(response);
			}
		}

		@Override
		@SuppressWarnings("DefaultCharset")
		protected Response<String> parseNetworkResponse(NetworkResponse response) {
			String parsed;
			try {
				parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
			} catch (UnsupportedEncodingException e) {
				parsed = new String(response.data);
			}
			return Response.success(parsed, HttpHeaderParser.parseCacheHeaders(response));
		}
	}



	private String getFiletextFromDir(String filename) {
		StringBuilder text = new StringBuilder();
		try {
			String destinationPath = "/data/data/"+getPackageName()+"/files" + "/" + filename;

			File file = new File(destinationPath);

			BufferedReader br = new BufferedReader(new FileReader(file));  
			String line;   
			while ((line = br.readLine()) != null) {
				text.append(line);
				//Log.i("Test", "text : "+text+" : end");
				text.append('\n');
			} }
		catch (IOException e) {
			e.printStackTrace();                    
		}
		return text.toString(); 
	}




	public class StringRequestProf extends Request<String> {

		/** Lock to guard mListener as it is cleared on cancel() and read on delivery. */
		private final Object mLock = new Object();

		@Nullable
		private Listener<String> mListener;
		public StringRequestProf(
            int method,
            String url,
            Listener<String> listener,
            @Nullable ErrorListener errorListener) {
			super(method, url, errorListener);
			mListener = listener;
		}
		public StringRequestProf(
            String url, Listener<String> listener, @Nullable ErrorListener errorListener) {
			this(Method.GET, url, listener, errorListener);
		}

		@Override
		public void cancel() {
			super.cancel();
			synchronized (mLock) {
				mListener = null;
			}
		}

		@Override
		protected void deliverResponse(String response) {
			Response.Listener<String> listener;
			synchronized (mLock) {
				listener = mListener;
			}
			if (listener != null) {
				listener.onResponse(response);
			}
		}

		@Override
		@SuppressWarnings("DefaultCharset")
		protected Response<String> parseNetworkResponse(NetworkResponse response) {
			String parsed;
			try {
				parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
			} catch (UnsupportedEncodingException e) {
				parsed = new String(response.data);
			}
			return Response.success(parsed, HttpHeaderParser.parseCacheHeaders(response));
		}
		@Override
		protected Map<String, String> getParams() 
		{  
			Map<String, String>  params = new HashMap<String, String>();  
			params.put("key","eac661eeeb7758433d6f49b2affee203");

			return params;  
		}

	}


	




	public static boolean setListViewHeightBasedOnItems(ListView listView) {

        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter != null) {

            int numberOfItems = listAdapter.getCount();

            // Get total height of all items.
            int totalItemsHeight = 0;
            for (int itemPos = 0; itemPos < numberOfItems; itemPos++) {
                View item = listAdapter.getView(itemPos, null, listView);
                item.measure(0, 0);
                totalItemsHeight += item.getMeasuredHeight();
            }

            // Get total height of all item dividers.
            int totalDividersHeight = listView.getDividerHeight() *
				(numberOfItems - 1);

            // Set list height.
            ViewGroup.LayoutParams params = listView.getLayoutParams();
            params.height = totalItemsHeight + totalDividersHeight;
            listView.setLayoutParams(params);
            listView.requestLayout();

            return true;

        } else {
            return false;
        }

    }





	public String getJsVersion3(String a){
		String v = "0";
		try
		{
			JSONObject obj = new JSONObject(a);
			v = obj.getString("Version");
			return v;
		}
		catch (JSONException e)
		{}
		return v;
	}
	public String readAssetsJson(String inFile) {
        String tContents = "";

		try {
			InputStream stream = getAssets().open(inFile);

			int size = stream.available();
			byte[] buffer = new byte[size];
			stream.read(buffer);
			stream.close();
			tContents = new String(buffer);
		} catch (IOException e) {
			// Handle exceptions here
		}

		return tContents;

	}
	public String loadJSONFromAsset(String n) {
		String json = "";
		try
		{
			json = FileUtil.readAsset(this, n);
			return d(json);
		}
		catch (IOException e)
		{}


		return json;
	}
	public String loadJSONFromDir(String n) {
		String json = "";
		StringBuilder text = new StringBuilder();
		try {
			String destinationPath = getApplicationContext().getFilesDir().getAbsolutePath() + "/" + n;
			File file = new File(destinationPath);

			BufferedReader br = new BufferedReader(new FileReader(file));  
			String line;   
			while ((line = br.readLine()) != null) {
				text.append(line);
				text.append('\n');
			} }
		catch (IOException e) {
			e.printStackTrace();                    
		}
	    json = text.toString(); 
		return d(json);
	}
	private void extractJson3(String n){
		AssetManager assetManager = this.getAssets();
		String newFileName = getApplicationContext().getFilesDir().getAbsolutePath() + "/" + n;
        File f = new File(newFileName);
		if(!f.exists()){
			InputStream in = null;
			OutputStream out = null;
			try {
				in = assetManager.open(n);
				out = new FileOutputStream(newFileName);

				byte[] buffer = new byte[1024];
				int read;
				while ((read = in.read(buffer)) != -1) {
					out.write(buffer, 0, read);
				}
				in.close();
				out.flush();
				out.close();
			} catch (Exception e) {
				//Log.e("tag", e.getMessage());
			}
		}else{
			String as = d(readAssetsJson(n));
			String dr = loadJSONFromDir(n);
			if(as.contains("Version") && dr.contains("Version")){
				String assets = getJsVersion3(as).replace("VERSION ","");
				String dir = getJsVersion3(dr).replace("VERSION ","");
				float a = Float.parseFloat(assets);
				float d = Float.parseFloat(dir);

				if(a > d){
					//	String newFileName = getApplicationContext().getFilesDir().getAbsolutePath() + "/" + "raw.json";

					File f1 = new File(newFileName);

					try {
						FileWriter fw = new FileWriter(f1);
						fw.write(readAssetsJson(n));
						fw.close();

					} catch (IOException iox) {
						iox.printStackTrace();
					}
				}else{

				}
			}
		}
	}

	public void linkUp(final boolean abc){

		final RequestQueue requestQueue = Volley.newRequestQueue(this);  

		StringRequest stringRequest = new StringRequest(Request.Method.GET,clink,
			new Response.Listener<String>() {


				@Override  
				public void onResponse(String content) {  
					String as = d(content);
					String dr = loadJSONFromDir("server.json");
					if(as.contains("Version") && dr.contains("Version")){
						String assets = getJsVersion3(as).replace("VERSION ","");
						String dir = getJsVersion3(dr).replace("VERSION ","");
						float a = Float.parseFloat(assets);
						float d = Float.parseFloat(dir);

						if(a > d){
							String newFileName = getApplicationContext().getFilesDir().getAbsolutePath() + "/" + "server.json";

							File f = new File(newFileName);

							try {
								FileWriter fw = new FileWriter(f);
								fw.write(content);
								fw.close();

							} catch (IOException iox) {
								iox.printStackTrace();
							}
							String cha = getChangelogs(loadJSONFromDir("server.json"));
							AlertDialog.Builder ab = new AlertDialog.Builder(OpenVPNClient.this);
							ab.setTitle("Auto Update Successful!");
							ab.setMessage("Please restart application to refresh data. Thank you!"+"\n"+"\n"+"Changelogs:"+"\n"+cha);
							ab.setCancelable(false);
							ab.setPositiveButton("Restart", new DialogInterface.OnClickListener(){

									@Override
									public void onClick(DialogInterface p1, int p2)
									{
										/*System.exit(8);
										 finish();*/
										doRestart(OpenVPNClient.this);
										// TODO: Implement this method
									}


								});
							ab.setNegativeButton("Later", new DialogInterface.OnClickListener(){

									@Override
									public void onClick(DialogInterface p1, int p2)
									{
										// TODO: Implement this method
									}


								});
							ab.show();

						}else{
							if(abc){
								Toast.makeText(OpenVPNClient.this, "No Update Available!",0).show();
							}
						}
					}else{
						if(abc){
							Toast.makeText(OpenVPNClient.this, "Update Error!",0).show();
						}
					}
					requestQueue.getCache().clear();
					requestQueue.stop();
				}  

			},  
			new Response.ErrorListener() {  
				@Override  
				public void onErrorResponse(VolleyError error) {  
					requestQueue.getCache().clear();

					requestQueue.stop();
					//displaying the error in toast if occur  
					//Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();  
				}  
			});




        //creating a request queue  

        //adding the string request to request queue  
        requestQueue.add(stringRequest);  
    }

	public static void doRestart(Context context) {
		PackageManager packageManager = context.getPackageManager();
		Intent intent = packageManager.getLaunchIntentForPackage(context.getPackageName());
		ComponentName componentName = intent.getComponent();
		Intent mainIntent = Intent.makeRestartActivityTask(componentName);
		context.startActivity(mainIntent);
		Runtime.getRuntime().exit(0);
	}
}
