package net.openvpn.openvpn;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import net.openvpn.openvpn.OpenVPNService.LogMsg;
import com.icodeplus.httpssl.*;
import android.widget.*;
import android.text.*;
import android.view.*;
import android.content.*;
import java.util.*;
import android.os.*;
import java.text.*;

public class OpenVPNLog extends OpenVPNClientBase {
    private static final String TAG = "OpenVPNClientLog";
    private ListView logList;
	private ArrayList<Spanned> arrayLog;
	private ArrayAdapter<Spanned> mylogadapter;
	private final SimpleDateFormat dateFormat = new SimpleDateFormat("[hh:mm aa]");
	private String bb = this.dateFormat.format(new Date());
	private String sp = " ";
	private String lv = bb + "   " + "Application version:"+sp+"1.0.0"+sp+"Build v1.0";
	private String lb = bb + "   " + "Running on" + sp + Build.BRAND + sp + Build.DEVICE + sp +"( Android API "+ Build.VERSION.SDK_INT+" )" ;

	private Menu mMenuItem;
	
	
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.log);
		arrayLog = new ArrayList<Spanned>();
		mylogadapter = new LogAdapter(this, arrayLog);
	    if(arrayLog.isEmpty()){
			addLog(lb);
			addLog(lv);
		}
		logList = (ListView)findViewById(R.id.logList);
		logList.setAdapter(mylogadapter);
		//addLog(mString.replace("\n",""));
		//addLog(ee.replace("\n",""));
		
         doBindService();
    }

    private void addLog(String str)
	{
		arrayLog.add(Html.fromHtml(str));
		mylogadapter.notifyDataSetChanged();
		// TODO: Implement this method
	}
	private class LogAdapter extends ArrayAdapter<Spanned>
	{
		public LogAdapter(Context con, ArrayList<Spanned> logMsg)
		{
			super(con, R.layout.log_item,logMsg);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			View v = LayoutInflater.from(getContext()).inflate(R.layout.log_item, parent, false);
			TextView tv = (TextView)v.findViewById(R.id.log_item_text);
			Spanned item = getItem(position);
			tv.setText(item);
			// TODO: Implement this method
			return v;
		}

	}
    private void scroll_textview_to_bottom() {
        
		logList.post(new Runnable() {
				public void run() {
					logList.setSelection(mylogadapter.getCount() - 1);

					//OpenVPNClient.this.mScrollView.smoothScrollTo(0, OpenVPNClient.this.mTextView.getBottom());
				}
			});
    }
    private void refresh_log_view() {
        ArrayDeque<LogMsg> hist = log_history();
        if (hist != null) {
         
            Iterator it = hist.iterator();

            while (it.hasNext()) {
				addLog(((LogMsg) it.next()).line);
                //builder.append(((LogMsg) it.next()).line);
            }

            
            scroll_textview_to_bottom();
        }
    }
	private void clearlog() {
		    ArrayDeque<LogMsg> hist = log_history();
			hist.clear();
			arrayLog.clear();
			mylogadapter.notifyDataSetChanged();
		    addLog(lb);
		    addLog(lv);
			Toast.makeText(getApplicationContext(),
						   "Logs Cleared!",
						   Toast.LENGTH_SHORT).show();
		
	}

    public void log(LogMsg lm) {
      
			addLog(lm.line);
            
            scroll_textview_to_bottom();
            return;
        
    }

    protected void onDestroy() {
        Log.d(TAG, "LOG: onDestroy");
        stop();
        super.onDestroy();
    }

    private void stop() {
        doUnbindService();
    }

    protected void post_bind() {
        Log.d(TAG, "LOG: post_bind");
        refresh_log_view();
        
    }
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.logs_menu, menu);
		
		mMenuItem = menu;
		//mMenuItem.getItem(0).setIcon(R.drawable.icon); 
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public void invalidateOptionsMenu() {
		super.invalidateOptionsMenu();
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()){

			case R.id.clear_logs:
				clearlog();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
