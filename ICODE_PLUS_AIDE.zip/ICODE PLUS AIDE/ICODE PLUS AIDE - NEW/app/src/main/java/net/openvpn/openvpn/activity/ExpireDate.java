package net.openvpn.openvpn.activity;

import android.os.*;
import java.net.*;
import java.io.*;
import org.json.*;
import android.content.*;
import java.util.concurrent.*;
import com.android.volley.toolbox.*;
import com.android.volley.*;

public class ExpireDate extends AsyncTask<String, String, String>
{

	private ExpireDate.ExpireDateListener listener;

	private String urlString;
	private URL mURL;
	private HttpURLConnection con;
	private Context context;

	
	private Response response;
	public interface ExpireDateListener
	{
		void onExpireDate(String expire_date);
		void onDeviceNotMatch(String message);
		void onAuthFailed(String message);
		void onError(String error);
	}
	public ExpireDate(Context context)
	{
		this.context = context;
		
	}
	public void setUrl(String urlString)
	{
		this.urlString = urlString;
	}
	public void setExpireDateListener(ExpireDateListener ExpireDateListener)
	{
		listener = ExpireDateListener;
	}
	public void start()
	{
		execute(urlString);
	}
	@Override
	protected String doInBackground(String[] p1)
	{
		String result = null;
		return result;
		// TODO: Implement this method
	}

	@Override
	protected void onPreExecute()
	{
		// TODO: Implement this method
		super.onPreExecute();
	}

	@Override
	protected void onPostExecute(String result)
	{
		if (result != null) {
			if (result.startsWith("error")) {
				listener.onError(result);
			} else {
				try {
					JSONObject js = new JSONObject(result);
					if (js.getString("device_match").equals("none")) {
						listener.onAuthFailed("Authentication Failed");
						return;
					}
					if (js.getString("device_match").equals("false")) {
						listener.onDeviceNotMatch("This pin is use in another device");
						return;
					}
					listener.onExpireDate(js.getString("expiry"));
				} catch (Exception e) {
					listener.onError("Expire Date: "+e.getMessage());
				}
			}
		}
		// TODO: Implement this method
		super.onPostExecute(result);

	}
}
