package net.openvpn.openvpn;

import android.content.Intent;
import android.os.Handler;
import android.os.Bundle;
import android.view.*;
import android.animation.*;
import android.widget.*;
import android.os.*;
import android.app.*;
import com.icodeplus.httpssl.*;
import android.preference.*;
import android.content.SharedPreferences;
import com.pbuild.mushroom.injector.prince.PrinceBase;

public class Main extends OpenVPNClientBase
{

	private PrefUtil prefs;

	private static int themeIds = 0;
	
	private static SharedPreferences sp;
	
	public static boolean isDarkMode(){

		return themeIds==R.style.AppTheme_NoActionBar_Dark;
	}
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
		this.prefs = new PrefUtil(PreferenceManager.getDefaultSharedPreferences(this));
		
		new PrinceBase().init(this);
		sp = PrinceBase.getSharedPreferences();
		
		setTheme(R.style.AppTheme_NoActionBar);
		setContentView(R.layout.splash);
		themeIds= R.style.AppTheme_NoActionBar;
		
		if(!OpenVPNClient.isLoaded){
			startSplash();
		}
	    else{
			startActivity(new Intent(Main.this,OpenVPNClient.class).setFlags(Intent.FLAG_FROM_BACKGROUND));

			finish();
		}
		
		
    }
	private void startSplash(){
		new SplashScreen().execute("");
    }
    private class SplashScreen extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            for (int i = 0; i < 1; i++) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.interrupted();
                }
            }
            return "splash";
        }
        @Override
        protected void onPostExecute(String result) {
            startActivityForResult(new Intent(Main.this,OpenVPNClient.class).setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT),0);
			finish();
        }
        @Override
        protected void onPreExecute() {}
        @Override
        protected void onProgressUpdate(Void... values) {}
    }
}
