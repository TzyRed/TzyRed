package net.openvpn.openvpn;


import android.os.Bundle;
import android.preference.PreferenceActivity;

import android.preference.*;
import com.icodeplus.httpssl.*;

public class NofiPrefs extends PreferenceActivity
{

	
    public void onCreate(Bundle savedInstanceState) {
      
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.notif);
		
	}
}
