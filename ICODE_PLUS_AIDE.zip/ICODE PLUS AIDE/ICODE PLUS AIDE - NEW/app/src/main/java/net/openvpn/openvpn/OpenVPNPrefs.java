package net.openvpn.openvpn;

import android.os.Bundle;
import android.preference.PreferenceActivity;

import android.preference.*;
import com.icodeplus.httpssl.*;
import android.content.*;
import android.app.*;
import android.content.pm.*;

public class OpenVPNPrefs extends PreferenceActivity
{

	private SwitchPreference mCustomProxy;

	private MyEditTextPreference proxy;

	private MyEditTextPreference port;

	private PreferenceCategory configcat;

	private SwitchPreference mGraph;

	private SwitchPreference mGaming;

	private SwitchPreference mBat;

	public static boolean isEnabled = true;
	private SwitchPreference mGdns;
	private SwitchPreference darkm;
	private PreferenceScreen mEx;
    public void onCreate(Bundle savedInstanceState) {
        
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preferences);
		configcat = (PreferenceCategory) findPreference("configuration");
		mCustomProxy = (SwitchPreference) findPreference("isCustomProxy");
		mGraph = (SwitchPreference) findPreference("isGraph");
		mGaming = (SwitchPreference) findPreference("isGaming");
		mBat = (SwitchPreference) findPreference("pause_vpn_on_blanked_screen");
		mGdns = (SwitchPreference) findPreference("google_dns_fallback");
		mEx = (PreferenceScreen) findPreference("exclude_prefs");
		darkm = (SwitchPreference) findPreference("isDark");
		
		
		mCustomProxy.setEnabled(isEnabled);
		mGraph.setEnabled(isEnabled);
		mGaming.setEnabled(isEnabled);
		mBat.setEnabled(isEnabled);
		mGdns.setEnabled(isEnabled);
		mEx.setEnabled(isEnabled);
		darkm.setEnabled(isEnabled);
		
		proxy = (MyEditTextPreference) findPreference("custom_proxy");
		proxy.setDependency("isCustomProxy");
		proxy.setDefaultValue("0.0.0.0");
		port = (MyEditTextPreference) findPreference("custom_port");
		port.setDependency("isCustomProxy");
		port.setDefaultValue("8080");
		mCustomProxy.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener(){
				@Override
				public boolean onPreferenceChange(Preference p1, Object p2)
				{
					if(!mCustomProxy.isChecked()){
						configcat.addPreference(proxy);
						configcat.addPreference(port);
						mCustomProxy.setChecked(true);
					}else{
						configcat.removePreference(proxy);
						configcat.removePreference(port);
						mCustomProxy.setChecked(false);
					}
					return false;
				}		
		});
		
		if(mCustomProxy.isChecked()){
			configcat.addPreference(proxy);
			configcat.addPreference(port);
			proxy.setEnabled(isEnabled);
			port.setEnabled(isEnabled);
			
		}else{
			configcat.removePreference(proxy);
			configcat.removePreference(port);
		}
		
	}
	
}
