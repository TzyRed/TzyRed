package com.pbuild.mushroom.injector.prince.ssl;

import java.io.*;
import java.net.*;
import java.nio.channels.*;
import java.util.*;
import java.util.regex.*;
import android.os.*;
import android.content.*;
import net.openvpn.openvpn.PrefUtil;
import android.widget.Toast;
import android.preference.PreferenceManager;
import com.pbuild.mushroom.injector.prince.PrinceUtil;
import com.pbuild.mushroom.injector.prince.PrinceConfig;
import com.pbuild.mushroom.injector.prince.PrinceBase;

public class HTTPSupport
{
	private Socket incoming;
	private String netDataString;
	private String[] bugHostRotate;
    private String[] bugHostRotate2;
    private String[] bugHostRotate3;
    private int countRotate = 0;
    private int countRotate2 = 0;
    private int countRotate3 = 0;
	private Random mRandom = new Random();
	private int k = 0;
	private int h = 0;
	private int i = 0;
	private Context mContext;
	private Socket mSocket;
	private PrinceConfig util;
	
	public HTTPSupport(Socket in){
		util = PrinceBase.getUtils();
		incoming = in;
	}

	public HTTPSupport(Context c){
        mContext = c;
    }
	
	public String getUa()
	{
		String property = System.getProperty("http.agent");
        return property == null ? "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.130 Safari/537.36" : property;
	}
	
	public Socket socket() {
        String trim;
		Socket socket = null;
        String remote = util.getProxyHost() + ":" + util.getProxyPort();
        String[] split = remote.trim().split(":");
        int i = 80;
        if (split.length > 1) {
            trim = split[0].trim();
            try {
                i = Integer.parseInt(split[1].trim());
            } catch (NumberFormatException e) {
                i = 80;
            }
        } else {
            trim = split[0].trim();
        }
        try {
			String str;
			String replace;
            Matcher matcher;
            String str2;
            String str3;
            socket = new Socket(trim, i);
            OutputStream outputStream = socket.getOutputStream();
            Reader reader = new InputStreamReader(incoming.getInputStream());
            BufferedReader bufferedReader = new BufferedReader(reader);
            String readLine = bufferedReader.readLine();
            String str4 = readLine;
            if (readLine != null) {
                str4 = new StringBuffer().append(str4).append("").toString();
            }
            String[] split2 = str4.split(" ");
            String str5 = "80";
            if (split2[1].startsWith("http") || split2[1].indexOf(":") <= 0) {
                str = split2[1];
            } else {
                str = split2[1].split(":")[0];
                str5 = split2[1].split(":")[1];
            }
            netDataString = util.getPayload().replace("realData", "netData");
            int indexOf = netDataString.indexOf("netData");
            if (indexOf < 0) {
                replace = netDataString.replace("[METHOD]", split2[0]).replace("[method]", split2[0]).replace("[SSH]", split2[1]).replace("[IP_PORT]", split2[1]).replace("[ip_port]", split2[1]).replace("[IP]", str).replace("[ip]", str).replace("[PORT]", str5).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", split2[2]).replace("[host]", str).replace("[port]", str5).replace("[host_port]", split2[1]).replace("[ssh]", split2[1]).replace("[ua]", getUa()).replace("[raw]", new StringBuffer().append(str4).append("\r\n\r\n").toString()).replace("[real_raw]", new StringBuffer().append(str4).append("\r\n\r\n").toString()).replace("[auth]", auth()).replace("\\r", "\r").replace("\\n", "\n");
            } else if (netDataString.substring(indexOf + 7, (indexOf + 7) + 1).equals("@")) {
                matcher = Pattern.compile("\\[.*?@(.*?)\\]").matcher(netDataString);
                str2 = "";
                if (matcher.find()) {
                    str2 = matcher.group(1);
                }
                str3 = netDataString;
                String r28 = new StringBuffer().append(new StringBuffer().append("[netData@").append(str2.trim()).toString()).append("]").toString();
                replace = str3.replace(r28, new StringBuffer().append(split2[0]).append(" ").append(split2[1]).append("@").append(str2.trim()).append(" ").append(split2[2])).replace("[METHOD]", split2[0]).replace("[method]", split2[0]).replace("[SSH]", split2[1]).replace("[IP_PORT]", split2[1]).replace("[ip_port]", split2[1]).replace("[IP]", str).replace("[ip]", str).replace("[PORT]", str5).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", split2[2]).replace("[host]", str).replace("[port]", str5).replace("[host_port]", split2[1]).replace("[ssh]", split2[1]).replace("[ua]", getUa()).replace("[raw]", new StringBuffer().append(str4).append("\r\n\r\n").toString()).replace("[real_raw]", new StringBuffer().append(str4).append("\r\n\r\n").toString()).replace("[auth]", auth()).replace("\\r", "\r").replace("\\n", "\n");
            } else {
                if (indexOf == 0) {
                    indexOf = 1;
                }
                matcher = Pattern.compile("\\[(.*?)@.*?\\]").matcher(netDataString);
                str2 = "";
                if (matcher.find()) {
                    str2 = matcher.group(1);
                }
                if (netDataString.substring(indexOf - 1, indexOf).equals("@")) {
                    str3 = netDataString;
                    String r28 = new StringBuffer().append("[").append(str2.trim()).append("@netData]").toString();
                    replace = str3.replace(r28, new StringBuffer().append(split2[0]).append(" ").append(str2.trim()).append("@").append(split2[1]).append(" ").append(split2[2])).replace("[METHOD]", split2[0]).replace("[method]", split2[0]).replace("[SSH]", split2[1]).replace("[IP_PORT]", split2[1]).replace("[ip_port]", split2[1]).replace("[IP]", str).replace("[ip]", str).replace("[PORT]", str5).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", split2[2]).replace("[host]", str).replace("[port]", str5).replace("[host_port]", split2[1]).replace("[ssh]", split2[1]).replace("[ua]", getUa()).replace("[raw]", new StringBuffer().append(str4).append("\r\n\r\n").toString()).replace("[real_raw]", new StringBuffer().append(str4).append("\r\n\r\n").toString())
						.replace("[auth]", auth()).replace("\\r", "\r").replace("\\n", "\n");
                } else {
                    replace = netDataString.replace("[netData]", str4).replace("[METHOD]", split2[0]).replace("[method]", split2[0]).replace("[SSH]", split2[1]).replace("[IP_PORT]", split2[1]).replace("[ip_port]", split2[1]).replace("[IP]", str).replace("[ip]", str).replace("[PORT]", str5).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", split2[2]).replace("[host]", str).replace("[port]", str5).replace("[host_port]", split2[1]).replace("[ssh]", split2[1]).replace("[ua]", getUa()).replace("[raw]", new StringBuffer().append(str4).append("\r\n\r\n").toString()).replace("[real_raw]", new StringBuffer().append(str4).append("\r\n\r\n").toString()).replace("[auth]", auth()).replace("\\r", "\r").replace("\\n", "\n");
                }
            }
            matcher = Pattern.compile(".*?\\[rotation_method=(.*?)\\].*?").matcher(replace);
            while (matcher.find()) {
                str2 = matcher.group(1);
                bugHostRotate2 = str2.split(";");
                if (countRotate2 + 1 > bugHostRotate2.length)
				{
                    countRotate2 = 0;
                }
                str3 = replace;
                replace = str3.replace(new StringBuffer().append("[rotation_method=").append(str2).append("]").toString(), bugHostRotate2[countRotate2]);
            }
            Matcher matcher2 = Pattern.compile(".*?\\[rotation=(.*?)\\].*?").matcher(replace);
            while (matcher2.find()) {
                String group = matcher2.group(1);
                bugHostRotate = group.split(";");
                if (countRotate + 1 > bugHostRotate.length) {
                    countRotate = 0;
                }
                str3 = replace;
                replace = str3.replace(new StringBuffer().append("[rotation=").append(group).append("]").toString(), bugHostRotate[countRotate]);
            }
            Matcher matcher3 = Pattern.compile(".*?\\[rotate=(.*?)\\].*?").matcher(replace);
            while (matcher3.find()) {
                String group2 = matcher3.group(1);
                bugHostRotate3 = group2.split(";");
                if (countRotate3 + 1 > bugHostRotate3.length) {
                    countRotate3 = 0;
                }
                str3 = replace;
                replace = str3.replace(new StringBuffer().append("[rotate=").append(group2).append("]").toString(), bugHostRotate3[countRotate3]);
            }
            replace = d(replace);
            String[] split3;
            int i2;
            if (replace.contains("[split]")) {
                split3 = replace.split("\\[split\\]");
                for (i2 = 0; i2 < split3.length; i2++) {
                    outputStream.write(split3[i2].getBytes());
                    outputStream.flush();
                }
            } else if (replace.contains("[splitNoDelay]")) {
                split3 = replace.split("\\[splitNoDelay\\]");
                for (i2 = 0; i2 < split3.length; i2++) {
                    outputStream.write(split3[i2].getBytes());
                    outputStream.flush();
                }
            } else if (replace.contains("[instant_split]")) {
                split3 = replace.split("\\[instant_split\\]");
                for (i2 = 0; i2 < split3.length; i2++) {
                    outputStream.write(split3[i2].getBytes());
                    outputStream.flush();
                }
            } else if (replace.contains("[delay]")) {
                split3 = replace.split("\\[delay\\]");
                for (i2 = 0; i2 < split3.length; i2++) {
                    outputStream.write(split3[i2].getBytes());
                    outputStream.flush();
                    if (i2 != split3.length - 1) {
                        Thread.sleep((long) 1000);
                    }
                }
            } else if (replace.contains("[delay_split]")) {
                split3 = replace.split("\\[delay_split\\]");
                for (i2 = 0; i2 < split3.length; i2++) {
                    outputStream.write(split3[i2].getBytes());
                    outputStream.flush();
                    if (i2 != split3.length - 1) {
                        Thread.sleep((long) 1000);
                    }
                }
            } else if (replace.contains("[split_delay]")) {
                split3 = replace.split("\\[split_delay\\]");
                for (i2 = 0; i2 < split3.length; i2++) {
                    outputStream.write(split3[i2].getBytes());
                    outputStream.flush();
                    if (i2 != split3.length - 1) {
                        Thread.sleep((long) 1000);
                    }
                }
            } else {
                //addLog(replace.replace("\r", "\\r").replace("\n", "\\n"));
                outputStream.write(replace.getBytes());
                outputStream.flush();
            }
        } catch (final Exception e2) {
			Handler h = new Handler(Looper.getMainLooper());
			h.post(new Runnable() {
					public void run() {
						//do your thing here
					}
				});
        }
        countRotate++;
        countRotate2++;
        countRotate3++;
        return socket;
    }

	private String d(String str) {
        String str2 = str;
        String str3 = str2;
        if (str2.contains("[cr*")) {
            str3 = a(str2, "[cr*", "\r");
        }
        String str4 = str3;
        if (str3.contains("[lf*")) {
            str4 = a(str3, "[lf*", "\n");
        }
        str2 = str4;
        if (str4.contains("[crlf*")) {
            str2 = a(str4, "[crlf*", "\r\n");
        }
        String str5 = str2;
        if (str2.contains("[lfcr*")) {
            str5 = a(str2, "[lfcr*", "\n\r");
        }
        return str5;
    }

    private String a(String str, String str2, String str3) {
        while (str.contains(str2)) {
            Matcher matcher = Pattern.compile("\\[.*?\\*(.*?[0-9])\\]").matcher(str);
            if (matcher.find()) {
                int intValue = Integer.valueOf(matcher.group(1)).intValue();
                String str7 = "";
                for (int i = 0; i < intValue; i++) {
                    str7 = new StringBuffer().append(str7).append(str3).toString();
                }
                String str8 = str;
                str = str8.replace(new StringBuffer().append(str2).append(String.valueOf(intValue)).append("]").toString(), str7);
            }
        }
        return str;
    }

    private String auth() {
        String str = "";
        try {
			/* if (!http.getUser().isEmpty() && !http.getPass().isEmpty()) {
			 byte[] encode = Base64.encode(new StringBuffer().append(http.getUser()).append(":").append(http.getPass()).toString().getBytes("ISO-8859-1"), Base64.DEFAULT);
			 str = new StringBuffer().append("Proxy-Authorization: Basic ").append(new String(encode)).toString();
			 }*/
        } catch (final Exception e) {
			Handler h = new Handler(Looper.getMainLooper());
			h.post(new Runnable() {
					public void run() {
						//do your thing here
					}
				});
        }
        return str;
    }

	public String ua() {
        String property = System.getProperty("http.agent");
        return property == null ? "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.130 Safari/537.36" : property;
    }
	
	public Socket inject() {
        //String str;
        try {
            String readLine;
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.incoming.getInputStream()));
            StringBuilder stringBuilder = new StringBuilder();
            while (true) {
                readLine = bufferedReader.readLine();
                if (readLine != null && readLine.length() > 0) {
                    stringBuilder.append(readLine);
                    stringBuilder.append("\r\n");
                }
				if (stringBuilder.toString().equals("")) {
					//h.a("Get Request", "Get request data failed, empty requestline");
					return null;
				}
				/*if (App.e().indexOf("@") > 0) {
				 readLine = "Proxy-Authorization: Basic ";
				 str = a.a(App.h());
				 if (stringBuilder.indexOf(readLine) <= 0) {
				 stringBuilder.append(readLine);
				 stringBuilder.append(Arrays.toString(str.getBytes("ISO-8859-1")));
				 stringBuilder.append("\r\n");
				 }
				 }
				 stringBuilder.append("\r\n");
				 if (!str.equals("")) {
				 this.j = "Basic " + str;
				 }*/
				String c = c(stringBuilder.toString());
				if (c != null) {

					//h.a("Socket Server", "Connecting to " + str);
					Socket socket = new Socket();
					socket.connect(new InetSocketAddress(util.getProxyHost(), Integer.valueOf(util.getProxyPort()).intValue()));
					/*if (Boolean.valueOf(d()[0]).booleanValue()) {
					 if (!c.equals("")) {
					 a(c, socket);
					 }
					 OutputStream outputStream = this.incoming.getOutputStream();
					 outputStream.write("HTTP/1.0 200 Connection Established\r\n\r\n".getBytes());
					 outputStream.flush();
					 return socket;
					 }*/
					a(c, socket);
					return socket;
				}
				return null;
            }
        } catch (Exception e) {
            /*str = e.getMessage();
			 if (App.t() || App.s() || App.u()) {
			 str = "There was problem during connect to remote server ";
			 }
			 h.a("Socket Server", str);*/
			return null;
        }
    }

	private String c(String str) {
        String str2 = null;
		String f = null;
		String i;
        if (str != null) {
            try {
                if (!str.equals("")) {
                    String charSequence = str.split("\r\n")[0];
                    String[] split = charSequence.split(" ");
                    String[] split2 = split[1].split(":");
                    f = split2[0];
                    i = split2[1];
                    str2 = d(util.getPayload().replace("[real_raw]", str).replace("[raw]", charSequence).replace("[method]", split[0]).replace("[host_port]", split[1]).replace("[host]", f).replace("[port]", i).replace("[protocol]", split[2])/*.replace("[auth]", this.j)*/.replace("[ua]", ua()).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr]", "\n\r").replace("\\r", "\r").replace("\\n", "\n"));
                    return str2;
                }
            } catch (Exception e) {
                //h.a("Payload Error", e.getMessage());
            }
        }
        //h.a("Payload Error", "Payload is null or empty");
        return str2;
    }

	private void a(String str, Socket socket) throws Exception{
        int i = 0;
		String[] split;
        OutputStream outputStream = socket.getOutputStream();
        if (str.contains("[random]")) {
            Random g = new Random();
            split = str.split(Pattern.quote("[random]"));
            str = split[g.nextInt(split.length)];
        }
        if (str.contains("[repeat]")) {
            split = str.split(Pattern.quote("[repeat]"));
            str = split[this.h];
            this.h++;
            if (this.h > split.length - 1) {
                this.h = 0;
            }
        }
        if (str.contains("[split_delay]")) {
            split = str.split(Pattern.quote("[split_delay]"));
            int length = split.length;
            while (i < length) {
                String str2 = split[i];
                if (a(str2, socket, outputStream)) {
                    outputStream.write(str2.getBytes());
                    outputStream.flush();
                    //b(str2, socket);
                    //sleep(1500);
                }
                i++;
            }
        } else if (a(str, socket, outputStream)) {
            outputStream.write(str.getBytes());
            outputStream.flush();
            //b(str, socket);
        }
    }

	private boolean a(String str, Socket socket, OutputStream outputStream) throws Exception{
        if (!str.contains("[split]")) {
            return true;
        }
        for (String str2 : str.split(Pattern.quote("[split]"))) {
            outputStream.write(str2.getBytes());
            outputStream.flush();
            //b(str2, socket);
        }
        return false;
    }

	public String b(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        int length = str.length();
        for (int i = 0; i < length; i++) {
            stringBuilder.append("*");
        }
        return stringBuilder.toString();
    }
}