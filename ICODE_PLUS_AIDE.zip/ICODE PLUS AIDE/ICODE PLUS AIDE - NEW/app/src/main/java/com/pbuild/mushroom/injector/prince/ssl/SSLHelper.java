package com.pbuild.mushroom.injector.prince.ssl;

import android.content.*;

import android.view.KeyEvent.*;
import android.os.*;
import java.util.*;
import android.util.*;
import javax.net.ssl.*;

public class SSLHelper
{
	private static TcpSSLThreadv2 server;

	public static void runSSL(Context c,int lp,String host,int sp,String sni){
		//c.startService(new Intent(c, SSLDroid.class));
		server = new TcpSSLThreadv2("any", lp,  host,
								  sp,sni, null, null, null);
		server.start();
		//c.startService(new Intent(c, ForegroundService.class));

	}
	
	public static void stopSSL(Context c){
		//c.stopService(new Intent(c, SSLDroid.class));
		try {
			//close the server socket and interrupt the server thread
			if(server.ss != null){
				server.ss.close();
				server.ss = null;
			}
			if(server.sc != null){
			  server.sc.close();
			  server.sc = null;
			}
			if(server.st != null){
			  server.st.close();
			  server.st = null;
			}
			server.stopSSL();
			server.interrupt();
			//server.stop();
			
		} catch (Exception e) {
			Log.d("SSLDroid", "Interrupt failure: " + e.toString());
		}

		//c.stopService(new Intent(c, ForegroundService.class));
		//Utility.stop();
	}
}