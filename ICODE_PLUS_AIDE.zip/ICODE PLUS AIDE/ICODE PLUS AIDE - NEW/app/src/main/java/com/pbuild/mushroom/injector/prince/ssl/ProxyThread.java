package com.pbuild.mushroom.injector.prince.ssl;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import com.pbuild.mushroom.injector.*;

public class ProxyThread extends Thread
{
    boolean LoopingThread = true;
    boolean autoReplace;
    String buffReq = "1024";
    String buffRes = "4096";
    boolean clientToServer;
    Socket incoming;
    Socket outgoing;

	private static InjectorService mService;

    ProxyThread(Socket in, Socket out, boolean clientToServer, String buffReq, String buffRes, boolean autoReplace)
    {
        this.incoming = in;
        this.outgoing = out;
        this.clientToServer = clientToServer;
        this.buffReq = buffReq;
        this.buffRes = buffRes;
        this.autoReplace = autoReplace;
    }

    public final void run()
	{
        byte[] buffer;
        if (this.clientToServer)
        {
            buffer = new byte[Integer.parseInt(this.buffReq)];
        }
        else
        {
            buffer = new byte[Integer.parseInt(this.buffRes)];
        }
        try
        {
            InputStream inputStream = this.incoming.getInputStream();
            OutputStream outputStream = this.outgoing.getOutputStream();
            while (true)
            {
                int read = inputStream.read(buffer);
                if (read == -1)
                {
                    break;
                }
                else
                {
                    try
                    {
                        String str = new String(buffer, 0, read);
                        if (this.clientToServer)
                        {
                            outputStream.write(buffer, 0, read);
                            outputStream.flush();
                        }
                        else
                        {
                            String[] split = str.split("\r\n");
                            if (split[0].startsWith("HTTP/"))
                            {
                                String substring = split[0].substring(9, 12);
                                String substring2 = split[0].substring(13);                   
                                if (substring.equals("101"))
                                {
									outputStream.write("HTTP/1.1 200 OK\r\n\r\n".getBytes());
									outputStream.flush();
                                }
                                else
                                {
                                    outputStream.write(new StringBuilder(String.valueOf(split[0].split(" ")[0])).append(" 200 Connection established\r\n\r\n").toString().getBytes());
                                    outputStream.flush();
                                }
                            }
                            else
                            {
                                outputStream.write(buffer, 0, read);
                                outputStream.flush();
                            }
                        }
                    }
                    catch (Exception e2)
                    {
                        try
                        {
                            if (this.incoming != null)
                            {
                                this.incoming.close();
                            }
                            if (this.outgoing != null)
                            {
                                this.outgoing.close();
                                return;
                            }
                            return;
                        }
                        catch (IOException e3)
                        {
                            return;
                        }
                    }
                    catch (Throwable th)
                    {
                        try
                        {
                            if (this.incoming != null)
                            {
                                this.incoming.close();
                            }
                            if (this.outgoing != null)
                            {
                                this.outgoing.close();
                            }
                        }
                        catch (IOException e4)
                        {
                        }
                    }
                }
            }
            inputStream.close();
            outputStream.close();
            try
            {
                if (this.incoming != null)
                {
                    this.incoming.close();
                }
                if (this.outgoing != null)
                {
                    this.outgoing.close();
                }
            }
            catch (IOException e5)
            {
            }
        }
        catch (Exception e6)
        {
        }
    }

    public static void connect(InjectorService service, Socket first, Socket second, String buffReq, String buffRes, boolean autoReplace) 
	{
		mService = service;
        new ProxyThread(first, second, true, buffReq, buffRes, autoReplace).start();
        new ProxyThread(second, first, false, buffReq, buffRes, autoReplace).start();
    }
}
