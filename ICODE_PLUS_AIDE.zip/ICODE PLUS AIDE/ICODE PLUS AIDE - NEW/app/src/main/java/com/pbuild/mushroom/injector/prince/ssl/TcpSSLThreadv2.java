package com.pbuild.mushroom.injector.prince.ssl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import android.util.Log;
import java.io.*;
import java.security.cert.*;
import javax.net.ssl.*;
import android.annotation.*;
import java.net.*;
import android.content.*;
import java.util.*;
import android.os.*;
import com.pbuild.mushroom.injector.prince.*;
import android.view.InputQueue.*;
import net.openvpn.openvpn.*;
import java.nio.channels.*;

public class TcpSSLThreadv2 extends Thread
{
    public static String mL = "";
	
	public Thread fromBrowserToServer = null;
	public Thread fromServerToBrowser = null;

    String tunnelName;
    int listenPort;
    String tunnelHost;
    int tunnelPort;
    String keyFile, keyPass, caFile;
    TcpRelay inRelay, outRelay;
    public static ServerSocket ss = null;
    int sessionid = 0;
    private SSLSocketFactory sslSocketFactory;
    private X509Certificate caCert;

    private String[] TLS13_CIPHER_SUITES = new String[]{
		"TLS_AES_128_GCM_SHA256",
		"TLS_AES_256_GCM_SHA384",
	    "TLS_CHACHA20_POLY1305_SHA256",
		"TLS_AES_128_CCM_SHA256",
		"TLS_AES_256_CCM_8_SHA256"
	};

	private String sni;

	public static Socket sc;

	public static Socket st;

	private HTTPThread sc1;

	private HTTPThread sc2;

	private ServerSocket listen_socket;
	
    public TcpSSLThreadv2(String tunnelName, int listenPort, String tunnelHost, int tunnelPort, String nsni,String keyFile, String keyPass, String caFile) {
        this.tunnelName = tunnelName ;
        this.listenPort = listenPort;
        this.tunnelHost = tunnelHost;
        this.tunnelPort = tunnelPort;
		this.sni = nsni;
        this.keyFile = keyFile;
        this.keyPass = keyPass;
        this.caFile = caFile;

        // Loading the CA cert
        if (caFile != null && !caFile.isEmpty()) {
            InputStream inStream = null;
            try {
                inStream = new FileInputStream(this.caFile);
                CertificateFactory cf = CertificateFactory.getInstance("X.509");
                caCert = (X509Certificate) cf.generateCertificate(inStream);

            } catch (Exception ex) {
                //FIXME
            } finally {
                try {
                    if (inStream != null)
                        inStream.close();
                } catch (IOException ex) { }
            }
        }
    }

	TrustManager[] trustCaCert = new TrustManager[] {
		new X509TrustManager() {
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}
			public void checkClientTrusted(
                java.security.cert.X509Certificate[] certs, String authType) {
			}
			public void checkServerTrusted(
                java.security.cert.X509Certificate[] certs, String authType) throws CertificateException {

				if (caFile == null || caFile.isEmpty()) //No CA file - trust all
					return;

				if (certs == null || certs.length == 0) {
					throw new IllegalArgumentException("null or zero-length certificate chain");
				}

				if (authType == null || authType.length() == 0) {
					throw new IllegalArgumentException("null or zero-length authentication type");
				}

				if (caCert == null) { //CA file specified, but no CA cert loaded
					throw new CertificateException("Invalid CA cert");
				}

				//Check if top-most cert is our CA's
				if(!certs[0].equals(caCert)){
					try
					{   //Not our CA's. Check if it has been signed by our CA
						certs[0].verify(caCert.getPublicKey());
					}
					catch(Exception e){
						throw new CertificateException("Certificate not trusted",e);
					}
				}

				//If we end here certificate is trusted. Check if any cert in the chain has expired.
				try{
					for (X509Certificate cert : certs) {
						cert.checkValidity();
					}
				}
				catch(Exception e){
					throw new CertificateException("Certificate not trusted. It has expired",e);
				}
			}
		}
    };

    public final SSLSocketFactory getSocketFactory(String pkcsFile,
												   String pwd, int sessionid) {
        if (sslSocketFactory == null) {
            try {
                KeyManagerFactory keyManagerFactory;
                if (pkcsFile != null && !pkcsFile.isEmpty()) {
                    keyManagerFactory = KeyManagerFactory.getInstance("X509");
                    KeyStore keyStore = KeyStore.getInstance("PKCS12");
                    keyStore.load(new FileInputStream(pkcsFile), pwd.toCharArray());
                    keyManagerFactory.init(keyStore, pwd.toCharArray());
                } else {
                    keyManagerFactory = null;
                }
                SSLContext context = SSLContext.getInstance("TLS");
                context.init(keyManagerFactory == null ? null : keyManagerFactory.getKeyManagers(), trustCaCert,
                             new SecureRandom());
                sslSocketFactory = context.getSocketFactory();
            } catch (FileNotFoundException e) {
            } catch (KeyManagementException e) {
            } catch (NoSuchAlgorithmException e) {
            } catch (KeyStoreException e) {
            } catch (java.security.cert.CertificateException e) {
            } catch (IOException e) {
            } catch (UnrecoverableKeyException e) {
            }
        }

        return sslSocketFactory;
    }

    public void run() {
        try {
			if (listen_socket == null){
              listen_socket = new ServerSocket(listenPort);
			  listen_socket.setReuseAddress(true);
			}
        	//log("SSL service is running");
			//log("Listening to port: "+ listenPort);
        while (true) {
            try {

                if (isInterrupted()){
					listen_socket.close();
                    return;
                }

                    sc = listen_socket.accept();
					sc.setSoTimeout(0);
					//SocketProtect.isProtected(sc);
                    sessionid++;
         
				//st = new SSLSupport(sc,sni,tunnelHost,tunnelPort,listenPort).socket();
				//sendForwardSuccess(sc);
				
				st = SocketChannel.open().socket();
				st.connect(new InetSocketAddress(tunnelHost, tunnelPort));
				
				if(st.isConnected()){
				   st = doSSLHandshakeOld(this.tunnelHost,this.sni,this.tunnelPort);
				}else{
					return;
				}
				
				//try {
				if (sc != null)
				{
					sc.setKeepAlive(true);
				}
				if (st != null)
				{
					st.setKeepAlive(true);
				}
				if (st == null)
				{
					st.close();
				}
				else if (st.isConnected())
				{ 
					sc1 = new HTTPThread(sc, st, true);
					sc2 = new HTTPThread(st, sc, false);
					sc1.setDaemon(true);
					sc1.start();
					sc2.setDaemon(true);
					sc2.start();
				}
					// final SSLSocketFactory sf = getSocketFactory(this.keyFile, this.keyPass, this.sessionid);

					//

					//st = (SSLSocket) sf.createSocket(this.tunnelHost, this.tunnelPort);

					// setSNIHost(sf,st,this.sni.replace("core.mushroom.test","viber.com"));
					/*st.addHandshakeCompletedListener(new HandshakeCompletedListener(){

					 @Override
					 public void handshakeCompleted(HandshakeCompletedEvent p1)
					 {

					 String ci = p1.getCipherSuite();
					 String tls = p1.getSession().getProtocol();
					 String ph = p1.getSession().getPeerHost();
					 int pp = p1.getSession().getPeerPort();

					 String l = "<b>Established "+tls+" "+"connection with "+"(private host)"+":"+pp+" "+"using "+ci;
					 //log(l);
					 mL = l;
					 if(ph != null){
					 //log(l);
					 try
					 {
					 String pr = p1.getPeerPrincipal().toString();
					 //log(pr);
					 //log("Peer Principal: "+pr);
					 }
					 catch (SSLPeerUnverifiedException e)
					 {}
					 }
					 }

					 });
					 st.setKeepAlive(true);
					 ((SSLSocket) st).startHandshake();*/
					SocketProtect.isProtected(st);

					//SSL Payload
					/*String mHost = cc.getSSHHost();
					 String pload = cc.getPayload().replace("[crlf]","\r\n")
					 .replace("[host_port]",mHost+":"+cc.getSSLPort())
					 .replace("[crlf*2]","\r\n\r\n")
					 .replace("[host]",mHost)
					 .replace("[port]",String.valueOf(cc.getSSLPort()))
					 .replace("[protocol]","HTTP/1.0")
					 .replace("[raw]", "CONNECT "+mHost+":"+cc.getSSLPort()+" "+"HTTP/1.0\r\n")
					 .replace("[real_raw]", "CONNECT "+mHost+":"+cc.getSSLPort()+" "+"HTTP/1.0\r\n\r\n")
					 .replace("[netData]", "CONNECT "+mHost+":"+cc.getSSLPort()+" "+"HTTP/1.0\r\n\r\n")
					 .replace("[realData]", "CONNECT "+mHost+":"+cc.getSSLPort()+" "+"HTTP/1.0\r\n\r\n")
					 .replace("[ua]","Mozilla/7.0+ (compatible; MSIE 4.01; windows NT 5.0)");
					 OutputStream ost = st.getOutputStream();
					 ost.write(pload.getBytes());
					 ost.flush();*/
              /*  } catch (IOException e) {
					return;
                }
                catch (Exception e) {
					if (sc != null)
					{
                        sc.close();
					}
                    return;
                }*/

              /*  if(sc==null||st==null){
					return;
				}*/

              /*  fromBrowserToServer = new TcpRelayv2(
                    this, sc.getInputStream(), st.getOutputStream(), "client", sessionid,tunnelHost,String.valueOf(tunnelPort),sni);
                fromServerToBrowser = new TcpRelayv2(
                    this, st.getInputStream(), sc.getOutputStream(), "server", sessionid,tunnelHost,String.valueOf(tunnelPort),sni);

                fromBrowserToServer.start();
                fromServerToBrowser.start();*/
            } catch (IOException ee) {
            }
        }     
		} catch (Exception e) {
		//log("SSL service is failed to run");
		  return;
		// interrupt();
	    }
    }
	
	private Socket doSSLHandshakeOld(String host, String sni, int port) throws IOException
	{
        TrustManager[] trustAllCerts = new TrustManager[] {
			new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers()
				{
					return null;
				}
				public void checkClientTrusted(
					java.security.cert.X509Certificate[] certs, String authType)
				{
				}
				public void checkServerTrusted(
					java.security.cert.X509Certificate[] certs, String authType)
				{
				}
			}
		};
        try
		{
            SSLContext sSLContext = SSLContext.getInstance("TLS");
            KeyManager[] keyManagerArr = (KeyManager[]) null;
            sSLContext.init(keyManagerArr, trustAllCerts, new SecureRandom());
            SSLSocket socket = (SSLSocket) sSLContext.getSocketFactory().createSocket(host, port);
            setSNIHost(sSLContext.getSocketFactory(), socket, sni);
			socket.setEnabledProtocols(socket.getEnabledProtocols());
			socket.addHandshakeCompletedListener(new HandshakeCompletedListener(){

					@Override
					public void handshakeCompleted(HandshakeCompletedEvent p1)
					{
						String ci = p1.getCipherSuite();
						String tls = p1.getSession().getProtocol();
						String ph = p1.getSession().getPeerHost();
						int pp = p1.getSession().getPeerPort();

						String l = "Established "+tls+" "+"connection with "+"(private host)"+":"+pp+" "+"using "+ci;
						mL = l;

						// TODO: Implement this method
					}


				});
			/*SSLEngine se = sSLContext.createSSLEngine();
			 se.setUseClientMode(true);
			 se.setEnableSessionCreation(true);
			 se.setWantClientAuth(true);
			 SSLParameters sslParams = se.getSSLParameters();
			 sslParams.setEndpointIdentificationAlgorithm("HTTPS");
			 se.setSSLParameters(sslParams);
			 se.beginHandshake();*/
			socket.startHandshake();
            return socket;
        }
		catch (Exception e)
		{
            IOException iOException = new IOException(new StringBuffer().append("Could not do SSL handshake: ").append(e).toString());
            throw iOException;
        }
    }

	public void stopSSL(){
		if(fromBrowserToServer != null && fromServerToBrowser != null){
			if(fromBrowserToServer.isAlive()){
				fromBrowserToServer.stop();

			}
			if(fromServerToBrowser.isAlive()){
				fromServerToBrowser.stop();
			}
		}
		if(sc1 != null && sc2 != null){
			if(sc1.isAlive()){
				sc1.stop();

			}
			if(sc2.isAlive()){
				sc2.stop();
			}
		}
		mL="";
		this.stop();
	}

    private void setSNIHost(final SSLSocketFactory factory, final SSLSocket socket, final String hostname) {
        if (factory instanceof android.net.SSLCertificateSocketFactory && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR1) {
            ((android.net.SSLCertificateSocketFactory)factory).setHostname(socket, hostname);
        } else {
            try {
                socket.getClass().getMethod("setHostname", String.class).invoke(socket, hostname);
            } catch (Throwable e) {
                // ignore any error, we just can't set the hostname...
            }
        }
    }
	
	private void sendForwardSuccess(Socket socket) throws IOException
	{
        String respond = "HTTP/1.1 200 OK\r\n\r\n";
        socket.getOutputStream().write(respond.getBytes());
        socket.getOutputStream().flush();
    }

	private String parseServer(InputStream stream) throws IOException
	{
		BufferedReader in = new BufferedReader(new InputStreamReader(stream));
		String inputLine;
		int cnt = 0;
		String url = null;

		while ((inputLine = in.readLine()) != null) {
			try {
				StringTokenizer tok = new StringTokenizer(inputLine);
				tok.nextToken();
			} catch (Exception e) {
				break;
			}
			if (cnt == 0) {
				String[] tokens = inputLine.split(" ");
				url = tokens[1];

			}
			cnt++;
		}
		return url;
	}
	
	private void send200Status(OutputStream output) throws Exception
	{
		output.write("HTTP/1.0 200 Connection established\r\n\r\n".getBytes());
		output.flush();
	}
};