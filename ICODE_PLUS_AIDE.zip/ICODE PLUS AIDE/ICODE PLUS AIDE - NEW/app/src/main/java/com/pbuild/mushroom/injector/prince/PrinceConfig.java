package com.pbuild.mushroom.injector.prince;

import java.util.*;

public interface PrinceConfig
{
	public String getPayload();
	public String getProxyHost();
	public String getProxyPort();
	public String getLocalPort();
}