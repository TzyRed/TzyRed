package com.pbuild.mushroom.injector.prince;

import java.util.*;
import android.net.*;
import java.net.*;
import org.apache.http.conn.*;
import java.net.*;
import java.io.*;

public class SocketProtect
{
	private static SocketProtect.IProtectSocket mlistener;

	public interface IProtectSocket
	{

		boolean protectSocket(Socket socket);
		boolean protectSocket(DatagramSocket socket);

		void remoteProxy(String ip);

	}
	public static void setIProtectSocket(Object object)
	{
		if (object instanceof IProtectSocket) {
			mlistener = (IProtectSocket)object;
		}
	}
	public static void setRemoteProxy(String ip)
	{
		if (mlistener != null) {
			mlistener.remoteProxy(ip);
		}
	}
	public static boolean isProtected(Socket socket)
	{
		return mlistener != null ? mlistener.protectSocket(socket) : false;
	}
	public static boolean isProtected(DatagramSocket socket)
	{
		return mlistener != null ? mlistener.protectSocket(socket) : false;
	}
	public static boolean isPortAvailable(int port)
    {
        Socket socket = new Socket();
        SocketAddress sockaddr = new InetSocketAddress("127.0.0.1", port);

        try 
        {
            socket.connect(sockaddr, 1000);
            // The connect succeeded, so there is already something running on that port
            return false;
        }
        catch (SocketTimeoutException e)
        {
            // The socket is in use, but the server didn't respond quickly enough
            return false;
        }
        catch (IOException e)
        {
            // The connect failed, so the port is available
            return true;
        }
        finally
        {
            if (socket != null)
            {
                try 
                {
                    socket.close();
                } 
                catch (IOException e) 
                {
                    /* should not be thrown */
                }
            }
        }
    }

    public static int findAvailablePort(int start_port, int max_increment)
    {
        for(int port = start_port; port < (start_port + max_increment); port++)
        {
            if (isPortAvailable(port))
            {
                return port;
            }
        }

        return 0;
    }
}

