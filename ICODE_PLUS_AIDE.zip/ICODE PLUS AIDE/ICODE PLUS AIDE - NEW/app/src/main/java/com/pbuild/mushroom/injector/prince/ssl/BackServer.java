package com.pbuild.mushroom.injector.prince.ssl;

import java.net.*;
import java.io.*;

public class BackServer extends Thread
{
    private ServerSocket ss;
    private Socket client;

    private boolean isAlive = true;
    public BackServer()
    {
        //mHttpRequest = HttpRequest;
    }
    @Override
    public void run()
    {
        try {
            ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(0));
            while (isAlive) {
                try {
                    client = ss.accept();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        OutputStream outputStream = client.getOutputStream();
                        outputStream.write("HTTP/1.1 200 CONNECTED\r\n\r\n".getBytes());
                        outputStream.flush();
                        if (!client.isClosed()) {
                            client.close();
                        }
                    }
                } catch (Exception e) {
                    try {
                        OutputStream outputStream = client.getOutputStream();
                        outputStream.write("HTTP/1.1 200 CONNECTED\r\n\r\n".getBytes());
                        outputStream.flush();
                        if (!client.isClosed()) {
                            client.close();
                        }
                    } catch (Exception e2) {
                        // do something
                    }
                }
            }
        } catch (Exception e) {
            // do something
        }
        super.run();
    }
    public SocketAddress getLocalSocketAddr()
    {
        return ss.getLocalSocketAddress();
    }
    public void Stop() throws Exception
    {
        if (ss != null) {
            ss.close();
        }
        if (client != null) {
            client.close();
        }
        isAlive = false;
        interrupt();
    }
}