package com.pbuild.mushroom.injector.prince.ssl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;

public class SSLAddress extends Thread {
    private ServerSocket a;
    private volatile boolean b = true;
    private Socket c;

    public SSLAddress() {
    }

    /* Access modifiers changed, original: 0000 */
    public SocketAddress a() {
        return this.a.getLocalSocketAddress();
    }

    /* Access modifiers changed, original: declared_synchronized */
    public synchronized void b() {
        this.b = false;
        try {
            this.c.close();
        } catch (Exception e) {
        }
        try {
            this.a.close();
        } catch (Exception e2) {
        }
    }

    public void run() {
        try {
            this.a = new ServerSocket();
            this.a.setReuseAddress(true);
            this.a.bind(new InetSocketAddress(0));
            //e.a(2131558473, Integer.valueOf(this.a.getLocalPort()));
            while (this.b) {
                this.c = this.a.accept();
                OutputStream outputStream;
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.c.getInputStream()));
                    String readLine;
                    do {
                        readLine = bufferedReader.readLine();
                        if (readLine != null) {
                        }
                        break;
                    } while (readLine.length() > 0);
                    outputStream = this.c.getOutputStream();
                    outputStream.write("HTTP/1.1 200 CONNECTED\r\n\r\n".getBytes());
                    outputStream.flush();
                    //e.a(2131558472, "localhost", Integer.valueOf(this.c.getPort()));
                    if (!this.c.isClosed()) {
                        this.c.close();
                    }
                } catch (Exception e) {
                    //e.a(2131558471, e.toString());
                    outputStream = this.c.getOutputStream();
                    outputStream.write("HTTP/1.1 200 CONNECTED\r\n\r\n".getBytes());
                    outputStream.flush();
                    //e.a(2131558472, "localhost", Integer.valueOf(this.c.getPort()));
                    if (!this.c.isClosed()) {
                        this.c.close();
                    }
                } catch (Throwable th) {
                    OutputStream outputStream2 = this.c.getOutputStream();
                    outputStream2.write("HTTP/1.1 200 CONNECTED\r\n\r\n".getBytes());
                    outputStream2.flush();
                    //e.a(2131558472, "localhost", Integer.valueOf(this.c.getPort()));
                    if (!this.c.isClosed()) {
                        this.c.close();
                    }
                }
            }
        } catch (Exception e2) {
            Exception exception = e2;
            String localizedMessage = exception.getLocalizedMessage();
            if (localizedMessage == null) {
                localizedMessage = exception.toString();
            }
        }
    }
}