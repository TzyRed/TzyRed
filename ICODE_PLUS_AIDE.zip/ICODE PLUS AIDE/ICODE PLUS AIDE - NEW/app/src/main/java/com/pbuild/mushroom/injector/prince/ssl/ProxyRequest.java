package com.pbuild.mushroom.injector.prince.ssl;

import android.annotation.*;
import android.content.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;
import javax.net.ssl.*;
import net.openvpn.openvpn.*;
import net.openvpn.openvpn.tools.PayloadHelper;

import com.pbuild.mushroom.injector.*;
import com.pbuild.mushroom.injector.prince.IProtect;
import com.pbuild.mushroom.injector.prince.PrinceConfig;
import com.pbuild.mushroom.injector.prince.PrinceBase;

public class ProxyRequest extends Thread implements IProtect.b
{
    @Override
    public void c()
    {
        b();
    }

    public boolean isAlive = true;
    public static final String SEND_BUFF = "16384";
    public static final String RECV_BUFF = "32768";

    private PrinceConfig util;

    private ServerSocket p;

    private SSLAddress v;

    private Socket j;

    private InjectorService service;
    private SharedPreferences sp;
    private String k;

    private int l;

    public volatile Socket a;
    public volatile SSLSocket b;
    private final Random q = new Random();
    private int r = 0;
    private int s = 0;
    private String m;
    private String n;
    private int o;

    private HttpsURLConnection u;

    public ProxyRequest(InjectorService service)
    {
        this.service = service;
        sp = PrinceBase.getSharedPreferences();
        IProtect.b = this;
    }

    @Override
    public void run()
    {
        try
        {
            p = new ServerSocket(Integer.parseInt(sp.getString("wsLocalPort", "8989")));
        }
        catch (Exception e)
        {
            //do something
        }
        try
        {
            int mode = 0;
            mode = 3;

            if (this.v != null)
            {
                this.v.b();
            }
            this.v = new SSLAddress();
            this.v.start();
            while (isAlive)
            {
                j = p.accept();
                if (j != null && !j.isClosed() && a(mode))
                {
                    this.j.setKeepAlive(true);
                    if (this.b != null && this.b.isConnected())
                    {
                        this.a.setKeepAlive(true);
                        this.b.setKeepAlive(true);
                        try
                        {
                            ProxyThread.connect(service, j, b, SEND_BUFF, RECV_BUFF, false);
                        }
                        catch (Exception e)
                        {
                            // do something
                        }
                    }
                    else if (this.a != null && this.a.isConnected())
                    {
                        this.a.setKeepAlive(true);
                        try
                        {
                            ProxyThread.connect(service, j, a, SEND_BUFF, RECV_BUFF, false);
                        }
                        catch (Exception e)
                        {
                            // do something
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {
            // do something
        }
        super.run();
    }

    public void e()
    {
        isAlive = false;
        if (this.v != null)
        {
            this.v.b();
            this.v = null;
        }
        b();
        try
        {
            this.p.close();
        }
        catch (Exception e)
        {
        }
    }

    public void b()
    {

        try
        {
            this.a.close();
        }
        catch (Exception e)
        {
        }
        try
        {
            this.b.close();
        }
        catch (Exception e2)
        {
        }
        try
        {
            this.u.disconnect();
        }
        catch (Exception e3)
        {
        }
        try
        {
            this.j.close();
        }
        catch (Exception e4)
        {
        }

        this.b = null;
        this.u = null;
        this.a = null;
        this.k = null;
        this.l = 0;
        this.m = null;
        this.n = null;
        this.o = 0;
    }

    private boolean a(int n) throws Exception
    {
        boolean bl;
        boolean bl2;
        StringBuilder stringBuilder;
        bl = true;
        try
        {
            BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(this.j.getInputStream()));
            stringBuilder = new StringBuilder();
            do {
                String string;
                if ((string = bufferedReader.readLine()) == null || string.length() <= 0)
                {
                    if (string == null) throw new Exception("Prince d");
                    if (stringBuilder.toString().isEmpty())
                    {
                        throw new Exception("Prince D");
                    }
                    break;
                }
                if (this.k == null)
                {
                    String[] arrstring = string.split(" ");
                    String[] arrstring2 = this.a(arrstring[0], arrstring[1]);
                    this.k = arrstring2[0];
                    this.l = Integer.valueOf((String)arrstring2[1]);
                }
                stringBuilder.append(string);
                stringBuilder.append("\r\n");
            } while (true);
        }
        catch (Exception exception)
        {
            String string = exception.getLocalizedMessage();

            return false;
        }
        if (n == 2 || n == 4 || n == 3)
        {
            String string = sp.getString("proxyHost", "") + ":" + sp.getString("proxyPort", "");
            if (string.contains((CharSequence)"@"))
            {
                String[] arrstring = string.split("@");
                string = arrstring[0];
                this.m = arrstring[1];
            }
            String[] arrstring = string.split(":");
            this.n = arrstring[0];
            this.o = Integer.valueOf((String)arrstring[1]);
        }
        String string = this.m;
        String string2 = null;
        if (string != null)
        {
            String string3 = ego(this.m.getBytes());
            string2 = "Basic " + string3;
            if (!stringBuilder.toString().contains((CharSequence)"Proxy-Authorization: Basic "))
            {
                stringBuilder.append("Proxy-Authorization: Basic ");
                stringBuilder.append(string3);
                stringBuilder.append("\r\n");
            }
        }
        stringBuilder.append("\r\n");
        String string4 = stringBuilder.toString();
        boolean bl3 = false; // force establish
        if (this.n != null)
        {
            this.proxy(this.n, this.o);
        }
        else
        {
            this.proxy(this.k, this.l);
        }

        String parsePayload = PayloadHelper.formatCustomPayload(sp.getString("wsRemoteHost", ""), Integer.valueOf(sp.getString("wsRemotePort","")), sp.getString("payloadHost", "")).split("~")[0];

        String payload = parsePayload;
        String ssl_payload = parsePayload;

        switch (n)
        {
            default: {
                throw new Exception("Unknown Flags Proxy Type");
            }
            case 0: {
                this.a(string4, payload, this.k, this.l, string2, this.a.getOutputStream());
                bl2 = bl;
                break;
            }
            case 2: {
                this.a(string4, payload, this.k, this.l, string2, this.a.getOutputStream());
                bl2 = bl3;
                break;
            }
            case 1: {
                this.ssl(this.k, this.l);
                this.a(string4, ssl_payload, this.k, this.l, string2, this.b.getOutputStream());
                bl2 = bl;
                break;
            }
            case 3: {
                this.ssl(this.n, this.o);
                this.a(string4, ssl_payload, this.k, this.l, string2, this.b.getOutputStream());
                bl2 = bl3;
                break;
            }
            case 4: {
                this.a(string4, payload, this.k, this.l, string2, this.a.getOutputStream());
                this.a(this.a.getInputStream(), 1);
                this.ssl(this.k, this.l);
                this.a(string4, ssl_payload, this.k, this.l, string2, this.b.getOutputStream());
                bl2 = bl;
            }
        }
        if (bl2)
        {
            OutputStream outputStream = this.j.getOutputStream();
            outputStream.write("HTTP/1.0 200 Connection established\r\n\r\n".getBytes());
            outputStream.flush();
        }
        if (this.b != null)
        {
            if (this.j.isClosed()) return false;
            if (!this.a.isConnected()) return false;
            if (!this.b.isConnected()) return false;
            return bl;
        }
        if (this.j.isClosed()) return false;
        boolean bl4 = this.a.isConnected();
        if (!bl4) return false;
        return bl;
    }

    private String[] a(String str, String str2) throws Exception
    {
        String str3;
        boolean equalsIgnoreCase = str.equalsIgnoreCase("connect");
        if (str2.contains("://"))
        {
            str2 = str2.split("://")[1];
        }
        if (str2.contains("/"))
        {
            str2 = str2.split("/")[0];
        }
        if (str2.contains("?"))
        {
            str2 = str2.split(Pattern.quote("?"))[0];
        }
        if (str2.contains(":"))
        {
            String[] split = str2.split(":");
            str3 = split[1];
            str2 = split[0];
            if (str3.isEmpty())
            {
                str3 = equalsIgnoreCase ? "443" : "80";
            }
        }
        else
        {
            str3 = equalsIgnoreCase ? "443" : "80";
        }
        if (str2 == null)
        {
            throw new Exception("");
        }
        return new String[]{str2, str3};
    }

    private void a(String string2, String string3, String string4, int n, String string5, OutputStream outputStream) throws Exception
    {
        String string6 = this.a(string2, string3, string4, n, string5);
        if (string6.isEmpty()) return;
        {
            if (string6.contains((CharSequence)"[random]"))
            {
                String[] arrstring = string6.split(Pattern.quote((String)"[random]"));
                string6 = arrstring[this.q.nextInt(arrstring.length)];
            }
            else if (string6.contains((CharSequence)"[repeat]"))
            {
                String[] arrstring = string6.split(Pattern.quote((String)"[repeat]"));
                if (this.s > -1 + arrstring.length)
                {
                    this.s = 0;
                }
                string6 = arrstring[this.s];
                this.s = 1 + this.s;
            }
            if (string6.contains((CharSequence)"[rotate="))
            {
                Matcher matcher = Pattern.compile((String)".*?\\[rotate=(.*?)\\].*?").matcher((CharSequence)string6);
                while (matcher.find())
                {
                    String string7 = matcher.group(1);
                    String[] arrstring = string7.split(";");
                    if (1 + this.r > arrstring.length)
                    {
                        this.r = 0;
                    }
                    string6 = string6.replace((CharSequence)("[rotate=" + string7 + "]"), (CharSequence)arrstring[this.r]);
                }
                this.r = 1 + this.r;
            }
            if (string6.contains((CharSequence)"[random="))
            {
                Matcher matcher = Pattern.compile((String)".*?\\[random=(.*?)\\].*?").matcher((CharSequence)string6);
                while (matcher.find())
                {
                    String string8 = matcher.group(1);
                    String[] arrstring = string8.split(";");
                    string6 = string6.replace((CharSequence)("[random=" + string8 + "]"), (CharSequence)arrstring[this.q.nextInt(arrstring.length)]);
                }
            }
            do {
                int n2;
                String string9 = this.a(string6, "[split]", "[split_delay]", "[split_delay=");
                if (this.j.isClosed())
                {
                    throw new Exception("Connection Lost");
                }
                if (string9 == null)
                {
                    String string10 = string6.replace((CharSequence)"\r", (CharSequence)"\\r").replace((CharSequence)"\n", (CharSequence)"\\n");

                    outputStream.write(string6.getBytes());
                    outputStream.flush();
                    return;
                }
                int n3 = -1;
                switch (string9.hashCode())
                {
                    case -1737402210: {
                        if (!string9.equals((Object)"[split]")) break;
                        n3 = 0;
                        break;
                    }
                    case -1537550374: {
                        if (!string9.equals((Object)"[split_delay]")) break;
                        n3 = 1;
                        break;
                    }
                }
                switch (n3)
                {
                    default: {
                        Matcher matcher = Pattern.compile((String)(".*?" + Pattern.quote((String)"[split_delay=") + "(.*?[0-9])\\].*?")).matcher((CharSequence)string6);
                        boolean bl = matcher.find();
                        n2 = 0;
                        if (!bl) break;
                        String string11 = matcher.group(1);
                        n2 = 1000 * Integer.valueOf((String)string11);
                        string9 = "[split_delay=" + string11 + "]";
                        break;
                    }
                    case 0: {
                        n2 = 0;
                        break;
                    }
                    case 1: {
                        n2 = 1000;
                    }
                }
                String[] arrstring = string6.split(Pattern.quote((String)string9), 2);
                String string12 = arrstring[0].replace((CharSequence)"\r", (CharSequence)"\\r").replace((CharSequence)"\n", (CharSequence)"\\n");

                outputStream.write(arrstring[0].getBytes());
                outputStream.flush();
                if (n2 > 0)
                {
                    Object[] arrobject = new Object[]{String.valueOf((int)(n2 / 1000))};
                    Thread.sleep((long)n2);
                }
                string6 = arrstring[1];
            } while (true);
        }
    }

    private void proxy(String string2, int n) throws Exception
    {

        if (this.a != null && this.a.isConnected())
        {
            try
            {
                this.a.close();
            }
            catch (Exception exception)
            {}
        }
        this.a = new Socket();
        String string3 = string2 + ":" + n;

        boolean injector = true;
        if (injector)
        {
            try
            {
                this.a.bind(new InetSocketAddress(0));

                if (IProtect.a(this.a))
                {
                    // do something
                }
                else
                {
                    throw new Exception("Protect Socket Fail");
                }
            }
            catch (Exception e2)
            {
                // do something
            }

        }
        this.a.connect(new InetSocketAddress(string2, n));
    }

    private String a(String str, String str2, String str3, int i, String str4)
    {
        String str42 = null;
        if (str42 == null)
        {
            str42 = "";
        }
        String str5 = str.split("\r\n")[0];
        String[] split = str5.split(" ");
        if (str2.isEmpty())
        {
            return str2;
        }
        str5 = str2.replace("[real_raw]", str).replace("[raw]", str5).replace("[netData]", str5).replace("[realData]", str).replace("[method]", split[0]).replace("[host_port]", split[1]).replace("[protocol]", split[2]).replace("[host]", str3).replace("[port]", String.valueOf(i)).replace("[crlf]", "\r\n").replace("[cr]", "\r").replace("[lf]", "\n").replace("[lfcr]", "\n\r").replace("[ua]", au()).replace("[auth]", str42).replace("\\r", "\r").replace("\\n", "\n");
        Matcher matcher = Pattern.compile("\\[(cr|lf|lfcr|crlf)\\*(.*?[0-9])\\]").matcher(str5);
        while (matcher.find())
        {
            String group = matcher.group(1);
            String group2 = matcher.group(2);
            StringBuilder stringBuilder = new StringBuilder();
            for (int i2 = 0; i2 < Integer.valueOf(group2).intValue(); i2++)
            {
                stringBuilder.append(group.replace("cr", "\r").replace("lf", "\n"));
            }
            str5 = str5.replace("[" + group + "*" + group2 + "]", stringBuilder.toString());
        }
        return str5;
    }

    private String a(String str, String... strArr)
    {
        while (!this.j.isClosed())
        {
            int indexOf = str.indexOf("[");
            int indexOf2 = str.indexOf("]");
            if (indexOf < 0 || indexOf2 < 0)
            {
                break;
            }
            int i = indexOf2 + 1;
            String substring = str.substring(indexOf, i);
            for (String obj : strArr)
            {
                if (substring.equals(obj) || Pattern.compile(Pattern.quote(obj) + "+[0-9]+\\]").matcher(substring).matches())
                {
                    return obj;
                }
            }
            str = str.substring(i);
            if (str.length() <= 0)
            {
                break;
            }
        }
        return null;
    }

    private void a(InputStream inputStream, int i) throws Exception
    {
        if (i > 0)
        {
            StringBuilder stringBuilder = new StringBuilder();
            int i2 = i;
            while (i2 > 0 && !this.j.isClosed())
            {
                int read = inputStream.read();
                if (read < 0)
                {
                    break;
                }
                stringBuilder.append((char) read);
                if (inputStream.available() < 1)
                {
                    stringBuilder.setLength(0);
                    i2--;
                    if (i2 > 0)
                    {
                        // do something
                    }
                }
            }
        }
    }

    private void ssl(String str, int i) throws Exception
    {
        String d = sp.getString("payloadHost", "");
        String splits[] = d.split("~");
        d = splits[1];

        SocketFactory dVar = new SocketFactory(this);
        if (d.isEmpty())
        {
            ((SSLSocket) dVar.createSocket(str, i)).startHandshake();
        }
        else
        {
            URL url = new URL("https://" + d);
            d = url.getHost();
            if (url.getPort() > 0)
            {
                d = d + ":" + url.getPort();
            }
            if (!url.getPath().equals("/"))
            {
                d = d + url.getPath();
            }

            boolean fuck = true;
            if (fuck)
            {
                this.u = (HttpsURLConnection) url.openConnection(new Proxy(Proxy.Type.HTTP, this.v.a()));
            }
            else
            {
                this.u = (HttpsURLConnection) url.openConnection();
            }
            this.u.setHostnameVerifier(new HostnameVerifier() {
                @SuppressLint({"BadHostnameVerifier"})
                public boolean verify(String str, SSLSession sSLSession)
                {
                    return true;
                }
            });

            this.u.setSSLSocketFactory(dVar);
            this.u.connect();
        }
    }

    public static String ego(byte[] bArr)
    {
        int i = 0;
        if (bArr == null)
        {
            return null;
        }
        byte[] bArr2 = new byte[(bArr.length + 2)];
        System.arraycopy(bArr, 0, bArr2, 0, bArr.length);
        byte[] bArr3 = new byte[((bArr2.length / 3) * 4)];
        int i2 = 0;
        int i3 = 0;
        while (i3 < bArr.length)
        {
            bArr3[i2] = (byte) ((bArr2[i3] >>> 2) & 63);
            bArr3[i2 + 1] = (byte) (((bArr2[i3 + 1] >>> 4) & 15) | ((bArr2[i3] << 4) & 63));
            bArr3[i2 + 2] = (byte) (((bArr2[i3 + 2] >>> 6) & 3) | ((bArr2[i3 + 1] << 2) & 63));
            bArr3[i2 + 3] = (byte) (bArr2[i3 + 2] & 63);
            i3 += 3;
            i2 += 4;
        }
        while (i < bArr3.length)
        {
            if (bArr3[i] < (byte) 26)
            {
                bArr3[i] = (byte) (bArr3[i] + 65);
            }
            else if (bArr3[i] < (byte) 52)
            {
                bArr3[i] = (byte) ((bArr3[i] + 97) - 26);
            }
            else if (bArr3[i] < (byte) 62)
            {
                bArr3[i] = (byte) ((bArr3[i] + 48) - 52);
            }
            else if (bArr3[i] < (byte) 63)
            {
                bArr3[i] = (byte) 43;
            }
            else
            {
                bArr3[i] = (byte) 47;
            }
            i++;
        }
        i2 = bArr3.length;
        while (true)
        {
            i2--;
            if (i2 <= (bArr.length * 4) / 3)
            {
                return new String(bArr3);
            }
            bArr3[i2] = (byte) 61;
        }
    }

    public static String au()
    {
        String property = System.getProperty("http.agent");
        return (property == null || property.isEmpty()) ? "Prince Dastan" : property;
    }
}