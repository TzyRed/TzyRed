package com.qingmei2.library;

/**
 * Created by QingMei on 2017/8/28.
 * desc:
 */

public interface ShortSlideListener {

    void onShortSlide(float eventY);
	//void onCloseOpenListener(Boolean a);
}
