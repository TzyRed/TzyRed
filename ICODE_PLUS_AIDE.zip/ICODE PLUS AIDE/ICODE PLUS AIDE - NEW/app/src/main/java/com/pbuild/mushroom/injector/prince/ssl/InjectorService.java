package com.pbuild.mushroom.injector.prince.ssl;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import java.lang.ref.WeakReference;
import java.net.ServerSocket;
import java.net.Socket;
import android.app.PendingIntent;
import android.support.v4.app.NotificationCompat;
import android.app.Notification;
import com.icodeplus.httpssl.*;

public class InjectorService extends Service implements Handler.Callback
{
	public static final String ACTION_START = "START_INJECTOR";
    public static final String ACTION_STOP = "STOP_INJECTOR";
    public static final String ACTION_RESTART = "RESTART_INJECTOR";
	public static boolean isRunning = false;
	public Handler handler;
	private ProxyRequest proxyThread;
	private static WeakReference<InjectorService> d;
	private static Socket output;
	private ServerSocket listen_socket;
	private final String CHANNEL_ID = "InjectorService";

	public void createNotificationChannel(){
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

			NotificationChannel serviceChanel =new NotificationChannel(
                CHANNEL_ID,
                "WS Injector FG Service"
                , NotificationManager.IMPORTANCE_DEFAULT
			);
			NotificationManager manager = getSystemService(NotificationManager.class);
			manager.createNotificationChannel(serviceChanel);
		}
	}
	
	@Override
	public IBinder onBind(Intent p1)
	{
		// TODO: Implement this method
		return new MyBinder();
	}

	@Override
	public void onCreate()
	{
		// TODO: Implement this method
		super.onCreate();
		handler = new Handler(this);
		
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			createNotificationChannel();
			
			Intent notificationIntent = new Intent(this, InjectorService.class);
			PendingIntent pendingIntent =PendingIntent.getActivity(this,0,notificationIntent,0);
			Notification notification = new NotificationCompat.Builder(this,CHANNEL_ID)
                .setContentTitle("WS Injector")
                .setContentText("Running...")
                .setSmallIcon(R.drawable.inject)
                .setContentIntent(pendingIntent)
                .build();
			startForeground(1,notification);
		}
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{
		String action = intent.getAction();
		if (action.equals(ACTION_START))
        {
			d = new WeakReference(this);
            start();
		}
        else if (action.equals(ACTION_STOP))
        {
            stop();
        }
        else if (action.equals(ACTION_RESTART))
        {
            restart();
        }
		// TODO: Implement this method
		return 1;
	}

	public class MyBinder extends Binder
	{
		public InjectorService getService()
		{
			return InjectorService.this;
		}
	}

	public InjectorService getService()
	{
		return InjectorService.this;
	}

    public void restart()
    {
		new Thread(new Runnable() {
				@Override
				public void run()
				{
					stop1();

					proxyThread = new ProxyRequest(InjectorService.this);
					isRunning = true;
					proxyThread.isAlive = true;
					proxyThread.start();
				}

			}).start();
	}

	public void start()
    {
		proxyThread = new ProxyRequest(this);
        isRunning = true;
        proxyThread.isAlive = true;
        proxyThread.start();
    }

	public void stop()
	{
		new Thread(new Runnable() {
			@Override
			public void run()
			{
				if (listen_socket != null)
					{
						try
						{
							listen_socket.close();
							listen_socket = null;
						}
						catch (Exception e)
						{}
						}
						if (output != null)
						{
							try
							{
								output.close();
								output = null;
							}
							catch (Exception e)
							{}
						}
                        if (proxyThread != null)
                        {
                            try
                            {                             
								proxyThread.e();
                                proxyThread.interrupt();
                                proxyThread = null;
                            }
							catch (Exception e)
                            {
                                //Thread.currentThread().interrupt();
                            }
                        }
                    }
                }).start();
				
		d = null;
		isRunning = false;
		stopForeground(true);
        stopSelf();
	}

	public void stop1()
	{
		new Thread(new Runnable() {
				@Override
				public void run()
				{
					if (listen_socket != null)
					{
						try
						{
							listen_socket.close();
							listen_socket = null;
						}
						catch (Exception e)
						{}
					}
					if (output != null)
					{
						try
						{
							output.close();
							output = null;
						}
						catch (Exception e)
						{}
					}
					if (proxyThread != null)
					{
						try
						{                             
							proxyThread.e();
							proxyThread.interrupt();
							proxyThread = null;
						}
						catch (Exception e)
						{
							//Thread.currentThread().interrupt();
						}
					}
				}
			}).start();

		d = null;
		isRunning = false;
	}

	@Override
	public boolean handleMessage(Message p1)
	{
		switch (p1.what)
        {
            case 0:
                // startService(new Intent(this, SSHTunnelService.class).setAction(SSHTunnelService.STOP_SSH));
				break;
			case 1:
				//Intent intent = new Intent(this, SSHTunnelService.class);
				//intent.setAction(SSHTunnelService.START_SSH);
				/*if (Build.VERSION.SDK_INT >= 26) {
				 this.startForegroundService(intent);
				 return true;
				 }*/
				//this.startService(intent);
				break;
		}
		// TODO: Implement this method
		return true;
	}

	public static boolean isServiceStarted()
	{
        if (d == null)
		{
            return false;
        }
        if (d.get() != null)
		{
            return true;
        }
        d = null;
        return false;
    }

	public boolean isInjectorRunning()
	{
		return isRunning;
	}
}
