package com.pbuild.mushroom.injector.prince.ssl;

import android.annotation.SuppressLint;
import java.net.InetAddress;
import java.net.Socket;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.LinkedHashSet;
import javax.net.ssl.HandshakeCompletedEvent;
import javax.net.ssl.HandshakeCompletedListener;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.util.Arrays;
import org.conscrypt.Conscrypt;

public class SocketFactory extends SSLSocketFactory {    String h = "TLS, ";
	static {
        try {
            Security.insertProviderAt(Conscrypt.newProvider(), 1);

        } catch (NoClassDefFoundError e) {
            e.printStackTrace();
        }}

	private SSLContext b;

	private ProxyRequest proxyRequest;

	public class e implements X509TrustManager {
		@SuppressLint({"TrustAllX509TrustManager"})
		public void checkClientTrusted(X509Certificate[] x509CertificateArr, String str) {
		}

		@SuppressLint({"TrustAllX509TrustManager"})
		public void checkServerTrusted(X509Certificate[] x509CertificateArr, String str) {
		}

		public X509Certificate[] getAcceptedIssuers() {
			return null;
		}}

    public SocketFactory(ProxyRequest proxyRequest) throws Exception{
		this.proxyRequest = proxyRequest;
		boolean secureRandom = true;

		X509TrustManager tm = Conscrypt.getDefaultX509TrustManager();
		//SSLContext sslContext = SSLContext.getInstance("TLS", "Conscrypt");
		//this.b.init(null, new TrustManager[] { tm }, null);

		this.b = SSLContext.getInstance("TLS","Conscrypt" );
        this.b.init(null, new TrustManager[]{tm}, secureRandom ? new SecureRandom() : null);
    }

    private void a(String str, int i, boolean z) throws Exception{
        this.proxyRequest.b = (SSLSocket) this.b.getSocketFactory().createSocket(proxyRequest.a, str, i, z);
        LinkedHashSet linkedHashSet = new LinkedHashSet();

        if (h.equals("SSL") || h.equals("TLS")) {
			//Collections.addAll(linkedHashSet, this.proxyRequest.b.getEnabledProtocols());
			this.proxyRequest.b.setEnabledProtocols(new String[] {"TLSv1", "TLSv1.1", "TLSv1.2", "TLSv1.3"});
		}

		else {
            linkedHashSet.add(h);
        }

		this.proxyRequest.b.setEnabledProtocols(new String[] {"TLSv1", "TLSv1.1", "TLSv1.2","TLSv1.3"});
		//this.proxyRequest.b.setEnabledProtocols(proxyRequest.b.getEnabledProtocols());
		//e.a(2131558477, TextUtils.join(", ", this.a.b.getEnabledProtocols()));
        //e.a(2131558479);

        this.proxyRequest.b.addHandshakeCompletedListener(new HandshakeCompletedListener() {
				public void handshakeCompleted(HandshakeCompletedEvent handshakeCompletedEvent) {
					//e.a(2131558476);
				}
			});
    }

    public Socket createSocket(String str, int i) {
        try
		{
			a(str, i, true);
		}
		catch (Exception e)
		{
			//
		}
        return this.proxyRequest.b;
    }

    public Socket createSocket(String str, int i, InetAddress inetAddress, int i2) {
        return null;
    }

    public Socket createSocket(InetAddress inetAddress, int i) {
        return null;
    }

    public Socket createSocket(InetAddress inetAddress, int i, InetAddress inetAddress2, int i2) {
        return null;
    }

    public Socket createSocket(Socket socket, String str, int i, boolean z) {
        try {
            socket.close();
        } catch (Exception e) {
        }
        try
		{
			a(str, i, z);
		}
		catch (Exception e)
		{
			//
		}
        return this.proxyRequest.b;
    }

	private Socket enableTLSOnSocket(Socket socket) {

		if(socket instanceof SSLSocket) ((SSLSocket) socket).setEnabledProtocols(new String[] {"TLSv1"});
		return socket; }

	public String[] getDefaultCipherSuites() {
        return this.b.getSocketFactory().getDefaultCipherSuites();
    }

    public String[] getSupportedCipherSuites() {
        return this.b.getSocketFactory().getSupportedCipherSuites();
    }
    /*public String[] getDefaultCipherSuites() {
	 return new String[0];
	 }

	 public String[] getSupportedCipherSuites() {
	 return new String[0];
	 }*/
}