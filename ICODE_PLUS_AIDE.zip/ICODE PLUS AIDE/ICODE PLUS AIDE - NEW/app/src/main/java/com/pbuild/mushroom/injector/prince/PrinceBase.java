package com.pbuild.mushroom.injector.prince;

import android.content.*;
import android.os.*;
import android.preference.*;

public class PrinceBase
{
	private static PrinceUtil utils;
	private static SharedPreferences sharedPreferences;
	private static SharedPreferences sharedPreference;

	public void init(Context c)
	{
		// TODO: Implement this method
		//if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
		//createNotificationChannels();
		//if (BuildConfig.DEBUG)
		//     enableStrictModes();

		/* if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
		 AppRestrictions.getInstance(this).checkRestrictions(this);
		 }*/
		sharedPreferences = new SecurePreferences(c);
		sharedPreference = PreferenceManager.getDefaultSharedPreferences(c);
		utils = new PrinceUtil();
	}

	private void enableStrictModes() {
        StrictMode.VmPolicy policy = new StrictMode.VmPolicy.Builder()
			.detectAll()
			.penaltyLog()
			.penaltyDeath()
			.build();
        StrictMode.setVmPolicy(policy);

    }

	/* @TargetApi(Build.VERSION_CODES.O)
	 private void createNotificationChannels() {
	 NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
	 NotificationChannel notificationChannel = new NotificationChannel(OreoService.NOTIFICATION_CHANNEL_BG_ID, getString(R.string.channel_name_background), 1);
	 notificationChannel.setDescription(getString(R.string.channel_description_background));
	 notificationChannel.enableLights(false);
	 notificationChannel.setLightColor(Color.DKGRAY);
	 notificationChannel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
	 notificationManager.createNotificationChannel(notificationChannel);
	 NotificationChannel notificationChannel2 = new NotificationChannel(OreoService.NOTIFICATION_CHANNEL_NEWSTATUS_ID, getString(R.string.channel_name_status), 3);
	 notificationChannel2.setDescription(getString(R.string.channel_description_status));
	 notificationChannel2.enableLights(true);
	 notificationChannel2.setLightColor(Color.BLUE);
	 notificationChannel2.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
	 notificationManager.createNotificationChannel(notificationChannel2);
	 }*/

	public static PrinceConfig getUtils()
    {
        return utils;
    }

	public static SharedPreferences getSharedPreferences()
    {
        return sharedPreferences;
    }

	public static SharedPreferences getDefSharedPreferences()
    {
        return sharedPreference;
    }
}