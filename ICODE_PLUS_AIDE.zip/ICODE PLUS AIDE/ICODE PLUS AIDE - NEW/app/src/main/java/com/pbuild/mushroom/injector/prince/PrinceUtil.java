package com.pbuild.mushroom.injector.prince;
import android.content.Context;
import android.content.SharedPreferences;
import net.openvpn.openvpn.myinterface.PayloadItem;

public class PrinceUtil implements PrinceConfig {
    @Override
	public String getPayload() {
		return sp.getString("payloadHost", "");
	}
	
	@Override
	public String getProxyHost() {
		return sp.getString("proxyHost", "");
	}
	
	@Override
	public String getLocalPort() {
		return sp.getString("wsLocalPort", "");
	}
	
	@Override
	public String getProxyPort() {
		return sp.getString("proxyPort", "");
	}
	
	public void setPayload(String payload) {
		sp.edit().putString("payloadHost", payload);
	}

	public void setProxyHost(String remote) {
		sp.edit().putString("proxyHost", remote);
	}

	public void setProxyPort(String port) {
		sp.edit().putString("proxyPort", port);
	}
	
	public void setLocalPort(String port) {
		sp.edit().putString("wsLocalPort", port);
	}
	
	private SharedPreferences sp;
	public PrinceUtil()
	{
		sp = PrinceBase.getSharedPreferences();
	}
}