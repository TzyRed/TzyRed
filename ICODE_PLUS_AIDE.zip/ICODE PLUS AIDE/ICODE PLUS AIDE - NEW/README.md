# ICODE TUNNEL
for professionals purposes only

Features:
1. OVPN BASE (http, ssl/tls, direct) 
2. WebSocket Supported
3. 2 Spinner (server & networks)
4. VPN STATUS & CUSTOM TWEAKS
5. Account Expiry

Credits:
1. openvpn.net
2. Jan Reil Romero Daguil
3. Prince Dastan
4. Alliance Team
5. Raksss

Special Thanks to the fallowing tools 

1. apktool
2. dex2jar
3. DJ Java Decompiler
4. eclipse 
5. Android Studio
6. APK Studio
7. Smali2JavaUI
8. jd-gui 
9. AndroChef Java Decompiler
10. My Brain 



Website
https://icode-xcv.ml/

Facebook 
https://www.facebook.com/jhanz.tech

Facebook Page
https://www.facebook.com/icodexcv/
